# JBoss As a Service - Tech Design, Build and Implementation (via Azure DevOps) to Akeso Unix hosts

Created by: Gary Marshall

Last updated: October 21, 2022

[[_TOC_]] 

# Design Objectives:
To deliver a Lightweight and secure JBoss environment that is scalable and simple to manage.

To provide a high quality, secure JBoss platform onto which  (FINEOS) applications can be deployed by isolating application components from the underlying platform.

# Logical design
The Akeso environment will include 3 web applications:
- Front Office (**frontoffice**),
- Services (**services**), and
- FINEOS Analytics (**analytics**)

The following diagrams are based on a production-like environment that is a superset of DEV.

Users interact with the FINEOS “Front Office” web application (green in the diagrams).  The “Fineos Services” web application exposes web service endpoints that are accessed via Load Balanced URLs.  The diagram below shows how FINEOS components interact via the Load Balancer, after user interaction with the Front Office application.

# Folder layout
| Directory | Content |
| --------- | ------- |
| /distribution | Repository (shared folder) holding all software to be installed on the host |
| /distribution/azagent | Azure Self-Hosted Agent distro |
| /distribution/fineos/ | FINEOS Software versions \n **NOTE**: This folder and its sub-folders are created and populated manually |
| /distribution/fineos/fineos89 | Software releases (mainly .zip and .war files) for FINEOS 8.9 |
| /distribution/microsoft | Contains distribution(s) of the SQL Server JDBC driver |
| /distribution/oracle | Contains distribution(s) of the Oracle JDK8 (for use by Batch apps) <br/> **NOTE**: This JDK is no longer being used. |
| /distribution/redhat | Contains JBoss EAP and OpenJDK distribution archives from Red Hat. |
| /fineosreleases | Base folder for FINEOS |
| /fineosreleases/web-apps | Home folder for external directories required by FINEOS Web Applications (frontoffice, services, analytics). |
| /fineosreleases/java-apps | Home folder for external directories required by FINEOS Java (Batch) Applications (claimsbatches, workperformer, unpacker etc.). |
| /jboss | Root folder for JBoss installation |
| /jboss/pki | Base folder for PKI assets required by JBoss versions. |
| /jboss/pki/jboss-eap-7.3 | Contains PKI assets including the Java Keystore(s) required by JBoss EAP 7.3.x. <br/> **NOTE**: This folder may also contain assets such as CSR or self-signed certificate files. <br/> **NOTE**: Keystores in this folder are directly referenced by all JBoss EAP instances of the corresponding version. |
| /jboss/jboss-eap-7.3 | Home folder for the JBoss EAP 7.3.x  installation. |
| /jboss/jboss-eap-7.3/secure_profile | This folder is created during execution of the “2. Provision JBoss Platform“ pipeline.  The folder is created temporarily from a copy of the “standalone” folder when creating the TAL-secure-profile.zip. <br/>While not required post-provisioning, the folder may exist temporarily \n During execution of the “3. Provision AKESO JBoss Instances” pipeline, the folder is created as the TAL-secure-profile.zip is de-compressed.  However the folder is immediately renamed to reflect the name of the instance being provisioned (e.g. ‘frontoffice’, ‘services’ or ‘analytics’).
| /jboss/jboss-eap-7.3/TAL-secure-profile.zip | An archive of the security hardened standalone configuration profile folder generated during the JBoss provisioning process.  <br/>This archive is used by the “3. Provision AKESO JBoss Instances” pipeline as a template for creating JBoss instances. |
| /jboss/jboss-eap-7.3/standalone_backup | Backup of the standalone configuration profile folder created during execution of the “2. Provision JBoss Platform“ pipeline.  This folder contains the original “as shipped” contents of its sibling “standalone” folder. |
| /jboss/instances | Base folder for JBoss instances. |
| /jboss/instances/jboss-eap-7.3 | Home folder for instances of JBoss EAP 7.3.x |
| /jboss/instances/jboss-eap-7.3/frontoffice | Front office instance (based on secure_profile) |
| /jboss/instances/jboss-eap-7.3/fineosservices | FINEOS Services instance (based on secure_profile) |
| /jboss/instances/jboss-eap-7.3/analytics | FINEOS Analytics instance (based on secure_profie) |

# DevOps integration
## AKESO Pipelines in Azure DevOps
A set of Pipelines has been created to automate the Provisioning and Deployment processes end-to-end.

The following are direct links to the AKESO Provisioning pipelines (full descriptions in  JBoss Operations):
1. Generate PKI Assets
2. Provision JBoss Platform
3. Provision AKESO JBoss Instances
4. Deploy AKESO Web Applications
5. Deploy AKESO Java (Batch) Applications [place-holder]
6. Start AKESO JBoss Instance(s)
7. Stop AKESO JBoss Instance(s)

**NOTE**: The above are processes are implemented as YAML Pipelines in accordance with Microsoft’s preference for YAML Pipelines over ‘Classic’ UI-based pipelines.

## Selecting the Target Environment when running Pipelines
In the Azure Pipelines, the Target Environment is selectable as a runtime parameter.

The following code (should be present in every pipeline) loads the appropriate variables file based on the parameter selection:
```YAML
variables: 
  - template: variables/${{ parameters.TARGET_ENV }}.yml 
```

The pipeline loads variables from a variables file based on the selected value, for example:
```YAML
variables/akeso-dev.yml
variables/akeso-sys1.yml
variables/akeso-sys2.yml
variables/akeso-uat.yml
variables/akeso-prd.yml
```

Variable files are in fact YAML templates.  The following example is taken from a draft akeso-dev.yml file:
```YAML
variables:
  TARGET_ENV: akeso-dev
  TARGET_HOST: dc1dev356

# CORE VARIABLES"
# 
# Software distributions folder
  DISTRIBUTIONS_HOME: /distribution
#
# JBoss related
  JBOSS_BASE: /jboss
  JBOSS_VERSION: jboss-eap-7.3
  RUN_AS_SERVICE: false
#
# FINEOS related
  FINEOS_BASE: /opt/fineos
#
# Users that will be created to own the top-level installation folders and run the Java processes
  JBOSS_ADMIN_USER: admin
  JBOSS_USER: jboss
  FINEOS_USER: fineos
  AD_GROUP_FINEOS_ACCESS_ROLE: .uappFineos_dev
#
  SECURE_PROFILE: secure_profile
#
# Port Offsets forJBoss Instances
  PORT_OFFSET_FRONTOFFICE: 100
  PORT_OFFSET_SERVICES: 250
  PORT_OFFSET_ANALYTICS: 300
#
# Management Ports forJBoss Instances (i.e. defult port (9993) + PORT_OFFSET)
  MGMT_PORT_FRONTOFFICE: 10093
  MGMT_PORT_SERVICES: 10243
  MGMT_PORT_ANALYTICS: 10293
#
# FINEOS Version
  FINEOS_VERSION: 8.9
#
# DERIVED VARIABLES"
#
# Required Archives
  JBOSS_DISTRO: ${{ variables.DISTRIBUTIONS_HOME }}/redhat/jboss-eap-7.3.0.zip
  JBOSS_PATCH: ${{ variables.DISTRIBUTIONS_HOME }}/redhat/jboss-eap-7.3.10-patch.zip
  MSSQL_JDBC_DRIVER_JAR: ${{ variables.DISTRIBUTIONS_HOME }}/microsoft/mssql-jdbc-6.4.0.jre8.jar
  # MSSQL_JDBC_DRIVER_JAR: ${{ variables.DISTRIBUTIONS_HOME }}/microsoft/mssql-jdbc-11.2.0.jre8.jar
  FRONTOFFICE_DISTRO: ${{ variables.DISTRIBUTIONS_HOME }}/fineos/fineos89/frontoffice-sso-89.1.1.war
  # FRONTOFFICE_DISTRO: ${{ variables.DISTRIBUTIONS_HOME }}/fineos/fineos89/frontoffice-89.1.1.war
  SERVICES_DISTRO: ${{ variables.DISTRIBUTIONS_HOME }}/fineos/fineos89/fineos-services-89.1.1.war
  # ANALYTICS_DISTRO: ${{ variables.DISTRIBUTIONS_HOME }}/fineos/fineos89/fineos-analytics-sso-89.1.1.war
  ANALYTICS_DISTRO: ${{ variables.DISTRIBUTIONS_HOME }}/fineos/fineos89/fineos-analytics-89.1.1.war
#
# JBoss Installation folder
  JBOSS_HOME: "${{ variables.JBOSS_BASE }}/${{ variables.JBOSS_VERSION }}"
#
# JBoss Instances folder
  INSTANCES_HOME: "${{ variables.JBOSS_BASE }}/instances/${{ variables.JBOSS_VERSION }}"
#
# Deployment Overlay resources folder
  OVERLAYS_HOME: "${{ variables.INSTANCES_HOME }}/deployment_overlays"
#
# DATA SOURCE CONNECTIONS
  CREATE_EXAMPLE_DATASOURCES: ${{ variables.CREATE_EXAMPLE_DATASOURCES }}"
# SQL Server
  DB_USER_NAME: sa_akeso_app_sql_dev
  # DB_USER_PASS: SEE_RUNTIME_VARIABLES
  DB_SERVER: DC1DEV355.tower.lan
  DB_SERVER_PORT: 1433
  TEST_DB_NAME: TestDB
  APP_DB_NAME: GEMINISVP1APP
  SEC_DB_NAME: GEMINISVP1sec
  ANA_APP_DB_NAME: GEMINISVP1ANAAPP
  ANA_SEC_DB_NAME: GEMINISVP1ANAsec
#
#############################
# IDP             #
#############################
# 
  IDP_HOST: dc1uat460.tower.lan
  IDP_PORT_HTTPS: 8543
#
#############################
# PKI VARIABLES             #
#############################
#
# PKI Folders
  PKI_BASE: "${{ variables.JBOSS_BASE }}/pki"
  PKI_HOME: "${{ variables.PKI_BASE }}/${{ variables.JBOSS_VERSION }}"
#
# PKI Assets
  KEYALG: RSA
  STORETYPE: jks
  MGMT_KEYSTORE: identity.jks
  KEYSTORE: applications.jks
  # KEYPASS:  SEE_RUNTIME_VARIABLES
  # STOREPASS:  SEE_RUNTIME_VARIABLES
  KEYSIZE: 2048
#
# CSR / Certificate identity
  ALIAS: "apps.${{ variables.TARGET_ENV }}"
  DNAME_CN: "${{ variables.ALIAS }}.internal.tal.com.au"
  DNAME_OU: IT
  DNAME_O: TAL
  DNAME_L: Sydney
  DNAME_ST: NSW
  DNAME_C: AU
#
# CSR File in time-stamped folder
  APPS_CSR_FILE: "apps.${{ variables.DNAME_CN }}.csr"
  MGMT_CSR_FILE: "mgmt.${{ variables.DNAME_CN }}.csr"
#
# ROOT_CA_CERT_FILE in base folder
  ROOT_CA_CERT_FILE: 'RootCA.cer'
#
# INTERMEDIATE_CA_CERT_FILE in base folder
  INTERMEDIATE_CA_CERT_FILE: 'IntermediateCA.cer'
#
# CERT_FILE in base folder
  APPS_CERT_FILE: "apps.${{ variables.DNAME_CN }}.crt"
  MGMT_CERT_FILE: "mgmt.${{ variables.DNAME_CN }}.crt"
```

Currently, all pipeline variables are defined in the single file.  It may be desirable to avoid duplication by refactoring so that global, pki-specific or host-specific variables are contained in their own files.

These could be picked up simply by adding a couple of lines to each pipeline, for example:
```YAML
variables: 
  - template: variables/global.yml 
  - template: variables/pki.yml
  - template: variables/${{ parameters.JBOSS_VERSION }}.yml
  - template: variables/${{ parameters.TARGET_ENV }}.yml
 ```
> **TO-DO**: Create a global variables file and add a line to each pipeline to include it.

## Single host vs. Multi-host execution
Currently, each JBoss Pipelines only executes on a single host.  Multi-host execution is possible but would require some structural changes in the pipelines. 

==As a temporary work-around, HOST_NAME is added to each variable file and a dedicated variables file is created for each host.==

###**TO-DO**: Multi-host Execution
For multi-host environments, the host-specific variables files should be identical EXCEPT for the “HOST_NAME” variable.

Multi-host execution would involve the introduction of more advanced YAML pipeline techniques including the implementation of parameters as “complex objects”, looping through those objects and advanced templating.  
- [x] Write the press release
- [ ] Update the website
- [ ] Contact the media

## Self-Hosted Linux Agent Pool
A custom agent pool “AzureJBossProvisioning” has been established with Self-Hosted Linux Agents to execute pipelines locally on the target (RHEL8) host.

### Host Targeting
Host Targeting is controlled by a set of “demands” based on a combination of hostname and custom Agent Capabilities:

### Agent Capability: TARGET_ENV
The ‘TARGET_ENV’ capability is set the name of the target environment.

Valid values:
```BASH
akeso-dev
akeso-sys1
akeso-sys2
```
Akeso pipelines typically require a match with the TARGET_ENV selected in the Pipeline.

### Agent Capability: WEB
The ‘WEB’ capability is set to true for agents located on JBoss hosts.  For other hosts, this capability should be absent.

Valid values:
```YAML
true
false (or absent)
```
Akeso JBoss-related pipelines typically require a match on WEB=true in order to execute.

### Agent Capability: JAVA
The ‘JAVA’ capability is set to true for agents located on designated ‘Batch’ hosts.  For other hosts, this capability should be absent.

Valid values:
```YAML
true
false (or absent)
```
Akeso pipelines for JAVA (i.e. Batch) applications typically require a match on JAVA=true in order to execute.

 

 

 

 

 

 
JBoss Operations

Created by: Gary Marshall
Last updated: October 21, 2022

# DRAFT CONTENT

_This document is being actively editied.  

It should be regarded strictly as a DRAFT until this notice is removed._

# Introduction
This page describes how to provision an entire JBoss EAP environment in support of the following FINEOS Web Applications:
- frontoffice
- sevices
- analytics

# AKESO Pipelines in Azure DevOps
A set of Pipelines has been created to automate the Provisioning and Deployment processes end-to-end.

Links to the actual AKESO Provisioning pipelines:

1. Generate PKI Assets

2. Provision JBoss Platform

3. Provision AKESO JBoss Instances

4. Deploy AKESO Web Applications

5. Deploy AKESO Java (Batch) Applications [place-holder]

6. Start AKESO JBoss Instance(s)

7. Stop AKESO JBoss Instance(s)

# Environment status
| Environment | Host name(s) | Status |
| akeso-dev | dc1dev356 | JBoss Provisioned, PKI completed. |
| akeso-sys | dc1sys174, dc2sys174 | |
 
# Process overview - Azure Devops Pipelines
The following Azure DevOps Pipelines represent an automated, end-to-end provisioning process:

 1. Generate PKI Assets
This pipeline generates self-signed certificates to establish the PKI assets required to install JBoss.  This is not recommended but does provide an interim solution while trusted certificates are being obtained.

## How to generate PKI Assets using certificates that have been signed by the TAL Certifying Authority:
The process of obtaining trusted (TAL-signed) certificates and using these to generate and install PKI Assets for JBoss (replacing self-signed PKI assets) is described in the page: Establish Java Keystores for the Akeso environments.

JBoss references two java keystores and they must be in JKS (Java Keystore) format:
The Java keystore identity.jks is used to secure the Management Interfaces including the Web Console and JBoss Management CLI.
The Java keystore applications.jks is used to secure the Application Realm.

JBoss expects the keystores to be present the PKI_HOME folder:
```BASH
/jboss/pki/jboss-eap-7.3/applications.jks
/jboss/pki/jboss-eap-7.3/akeso-dev.internal.tal.com.au.CSR
```
Currently, both keystores are using the same alias and private key.  For this reason, each of the keystores is created from a copy of the same keystore.

NOTE: Keystores are to be shared across AKESO hosts within the given environment.

### TO-DO: Should testing reveal that a single keystore can be referenced by both Management and Application realms, such consolidation would be recommended.

2. Provision JBoss Platform
This pipeline installs JBoss EAP 7.3.0, patches it to v7.3.10 and creates a security hardened profile for re-use as the basis for each JBoss Instance (one per FINEOS web application):
- Installs Java and any other software prerequisites (if not already installed).
- Installs JBoss version into the JBOSS_BASE folder: /jboss
- Copies JBoss EAP (v7.3.0) archive and the latest patch (v7.3.10) archive from the distribution folder.
- Intalls and patches JBoss from the distribution archives.
- Installs Microsoft SQL Server JDBC driver
- Creates an example Non-XA data-source to establish connection with “TestDB” (Optional step)
- Creates an example XA data-source to establish connection with “TestDB” (Optional step)
- Configures SSO by integrating with TAL Identity Provider (IdP) services
- Creates a security hardened configuration profile and compresses to “TAL-security-profile.zip”
- Publishes the TAL security profile archive for re-use when provisioning JBoss instances.

 3. Provision AKESO JBoss Instances
This pipeline creates a secure JBoss Instance for each FINEOS web application, applies any instance-specific configuration and opens firewall ports at the OS level:
- Create JBoss instances
- Creates each required JBoss instance (based on the TAL-security-profile.zip ) with a specified PORT_OFFSET
- Opens ports required by each JBoss instance in the host firewall
  NOTE: Ports must also be made accessible at the network level.
- Configures SystemD services to allow JBoss to be managed as RHEL8 system services. A configuration variable “RUN_AS_SERVICE" is available to control whether or not JBoss is started as a systemd service.  If this variable is not set to true than alternative Start/Stop mechanisms are utilised.
### TO-DO: Troubleshoot systemd service configuration
NOTE: The setup of systemd services has been completed, however troubleshooting is required as the services are failing to start.  This was de-prioritized but is desirable.

 4. Deploy AKESO Web Applications
This pipeline deploys each AKESO web application to its respective JBoss instance in a two-step process followed for each FINEOS web application (.WAR file).  The steps are:
- Prepare a TAL release from the FINEOS release artefact
- Deploy the TAL release

STEP 1 - Prepare a TAL release from the FINEOS release artefact
The pipeline will prepare a TAL release archive by packaging FINEOS release archive, after removing a number of unwanted files:
- weblogic.xml
- web.xml.gemini
- jboss-web.xml
- jboss-deployment-structure.xml

Depending on the choice of packaging option, environment-specific configuration files may be copied into specific locations before the archive is re-compressed.

Refer to the guide https://taldelivery.atlassian.net/wiki/spaces/NPA/pages/2933522535 for guidance.

STEP 2 - Deploy the Archive
The pipeline will:
- Deploy the application in ‘disabled’ mode, then 
- Register a deployment-overlay referencing the deployment, and
- Redeploying the application by ‘enabling’ it.  

 5. Un-deploy AKESO Web Applications  [NOT IMPLEMENTED]
This pipeline issues a JBoss CLI command to shutdown and undeploy the selected application(s).
NOTE: This pipeline is not yet implemented

 6. Start AKESO JBoss Instance(s)
This pipeline issues CLI commands to start the respective JBoss instances for each selected application.

 7. Stop AKESO JBoss Instance(s)
This pipeline issues CLI commands to stop the respective JBoss instances for each selected application.

 
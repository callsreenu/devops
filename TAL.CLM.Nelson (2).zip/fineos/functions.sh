#!/bin/bash

function updateFineosOwnership {
    echo -e "Updating file ownership for FINEOS directory '${FINEOS_BASE}' to '${FINEOS_USER-fineos}:${FINEOS_USER-fineos}'"
    sudo id -u ${FINEOS_USER:-fineos} &>/dev/null \
    && [[ -d "${FINEOS_BASE}" ]] && sudo chown ${FINEOS_USER-fineos}:${FINEOS_USER-fineos} "${FINEOS_BASE}" \
    && [[ -d "${FINEOS_BASE}/java-apps" ]] && sudo chown -R ${FINEOS_USER-fineos}:${FINEOS_USER-fineos} "${FINEOS_BASE}/java-apps" \
    && [[ -d "${FINEOS_BASE}/keystores" ]] && sudo chown -R ${FINEOS_USER-fineos}:${FINEOS_USER-fineos} "${FINEOS_BASE}/keystores"
    
    sudo id -u ${JBOSS_USER-jboss} &>/dev/null \
    && [[ -d "${FINEOS_BASE}/web-apps" ]] && sudo chown -R ${JBOSS_USER-jboss}:${JBOSS_USER-jboss} "${FINEOS_BASE}/web-apps"
}

function createDirectoriesForKeystores(){
       [[ ! -d "${FINEOS_BASE}/keystores" ]] && sudo mkdir -p ${FINEOS_BASE}/keystores
}

function replaceVendorFilesInDistro(){
	local DISTRO="$1"
	local TARGET_DIRECTORY="$2"
    local SOURCE_DIRECTORY="$(dirname ${DISTRO})"
    local DISTRO_FILE_NAME="${DISTRO##*/}"

	[[ -z "${DISTRO}" ]] && { echo "${FUNCNAME}(): DISTRO not specified"; exit 1; }
	[[ -z "${TARGET_DIRECTORY}" ]] && { echo "${FUNCNAME}(): TARGET_DIRECTORY not specified"; exit 1; }
	[[ "${TARGET_DIRECTORY}" == "${SOURCE_DIRECTORY}" ]] && { echo "${FUNCNAME}(): TARGET_DIRECTORY cannot be the same as SOURCE_DIRECTORY."; exit 1; }


    echo 
    echo "------------------------------------------------------------------------------"
    echo "REMEDIATION - Replace INVALID jboss-deployment-structure.xml (from vendor)"
    echo "NB: This file remains constant across environments"
    echo "------------------------------------------------------------------------------"
    echo "DISTRO=${DISTRO}"
    echo "TARGET_DIRECTORY=${TARGET_DIRECTORY}"
    echo "SOURCE_DIRECTORY=${SOURCE_DIRECTORY}"
    echo "DISTRO_FILE_NAME=${DISTRO_FILE_NAME}"

    echo "------------------------------------------------------------------------------"
    echo "Decompress (unzip) the Application Archive to a temporary location"
    echo "------------------------------------------------------------------------------"
    TEMP_FOLDER=`uuidgen`
    echo "Extracting to temporary folder: '${TARGET_DIRECTORY}/${TEMP_FOLDER}'"
    sudo mkdir -p "${TARGET_DIRECTORY}/${TEMP_FOLDER}" 
    sudo unzip -q "${APPLICATION_DISTRO}" -d "${TARGET_DIRECTORY}/${TEMP_FOLDER}" 
    updateJBossOwnership

    echo
    echo "------------------------------------------------------------------------------"
    echo "Remove files"
    echo "------------------------------------------------------------------------------"
    echo "REMOVE: 'WEB-INF/web.xml.gemini'"
    sudo rm -f "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/web.xml.gemini" 
    
    echo "REMOVE: 'WEB-INF/weblogic.xml'"
    sudo rm -f "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/weblogic.xml" 
    
    echo "REMOVE: 'WEB-INF/jboss-web.xml'"
    sudo rm -f "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/jboss-web.xml" 

    echo "REMOVE: 'WEB-INF/jboss-deployment-structure.xml'"
    sudo rm -f "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/jboss-deployment-structure.xml" 

    echo "REMOVE: 'WEB-INF/classes/fineos.properties'"
    sudo rm -f "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/classes/fineos.properties" 

    echo "REMOVE: 'WEB-INF/classes/log4j.properties'"
    sudo rm -f "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/classes/log4j.properties" 

    echo
    echo "------------------------------------------------------------------------------"
    echo "Replace files"
    echo "------------------------------------------------------------------------------"
    sudo mkdir -p "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/classes/"

    echo "REPLACE: 'WEB-INF/jboss-web.xml'"
    sudo cp "fineos/files/${TARGET_ENV}/web-apps/${APPLICATION_NAME}/jboss-web.xml" "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/" 

    echo "REPLACE: 'WEB-INF/jboss-deployment-structure.xml'"
    sudo cp "fineos/files/${TARGET_ENV}/web-apps/${APPLICATION_NAME}/jboss-deployment-structure.xml" "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/" 
    
    echo "REPLACE: 'WEB-INF/classes/fineos.properties'"
    sudo cp "fineos/files/${TARGET_ENV}/web-apps/${APPLICATION_NAME}/fineos.properties" "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/classes/" 
 
    echo "REPLACE: 'WEB-INF/classes/log4j.properties'"
    sudo cp "fineos/files/${TARGET_ENV}/web-apps/${APPLICATION_NAME}/log4j.properties" "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF/classes/" 
 
 
    updateJBossOwnership

    echo
    echo "Updated contents of '${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF':"
    sudo ls -l "${TARGET_DIRECTORY}/${TEMP_FOLDER}/WEB-INF"

    echo
    echo "------------------------------------------------------------------------------"
    echo "Re-Compress (zip) the Application Archive"
    echo "NB: Compress file from within the directory to get the correct path names"
    echo "------------------------------------------------------------------------------"
    pushd "${TARGET_DIRECTORY}/${TEMP_FOLDER}"
    sudo zip -q -r "${TARGET_DIRECTORY}/${DISTRO_FILE_NAME}" . 
    ls -l
    popd
    updateJBossOwnership

}

function updateFilesForJavaApps(){
    local PATH1="$1"
    local PATH2="$2"
    local APP_NAME="$3"

    #local PASSWORD="$3"
    echo "PATH1=${PATH1}"
    echo "PATH2=${PATH2}"
    echo "APP_NAME=${APP_NAME}"
    #echo "PASSWORD=${PASSWORD}"
    #=================================================
    # TARGETS:
    #=================================================
    # <URL>@SecSchemaURL@</URL>
    # <Driver>@DatabaseDriver@</Driver>
    # <User>@SecUsername@</User>
    # <Password>@SecPassword@</Password>
    #=================================================
   
    #=================================================
    # VARIABLES
    #=================================================
    APP_URL="jdbc:sqlserver://${DB_SERVER}:${DB_SERVER_PORT};DatabaseName=${APP_DB_NAME};encrypt=true;trustServerCertificate=true;"
    SEC_URL="jdbc:sqlserver://${DB_SERVER}:${DB_SERVER_PORT};DatabaseName=${SEC_DB_NAME};encrypt=true;trustServerCertificate=true;"
    #DRIVER=com.microsoft.sqlserver.jdbc.SQLServerDriver
    #USER=sa_akeso_app_sql_dev
    echo "DB_USER_NAME: ${DB_USER_NAME}"
    echo "DB_USER_PASS: ${DB_USER_PASS}"
    echo "DB_SERVER: ${DB_SERVER}"
    echo "DB_SERVER_PORT: ${DB_SERVER_PORT}"
    echo "DB_DRIVER: ${DB_DRIVER}"
    echo "JAVA_PATH: ${JAVA_PATH}"
    echo "JAVA_PATH_NEW: ${JAVA_PATH_NEW}"
    echo "APP_DB_NAME: ${APP_DB_NAME}"
    echo "SEC_DB_NAME: ${SEC_DB_NAME}"
    echo "APP_URL: ${APP_URL}"
    echo "SEC_URL: ${SEC_URL}"
    
    #PASSWORD="Admin@1234567"
    #HOME_EXISTING=/usr/bin/java/j2sdk1.4.2_06
    #HOME_NEW=/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.345.b01-1.el8_6.x86_64/
     echo "Persistence path: ${PATH1}"
     #echo "PASSWORD: $PASSWORD"
     #echo "PASSWORD: ${PASSWORD}"
    #

    if [[ "$APP_NAME" = "workperformer" ]]
    then
        #=================================================
        # UPDATE Persistence.xml
        #=================================================
        sudo sed -i "s|@DatabaseDriver@|${DB_DRIVER}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@AppSchemaURL@|${APP_URL}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@AppUsername@|${DB_USER_NAME}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@AppPassword@|${DB_USER_PASS}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@SecSchemaURL@|${SEC_URL}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@SecUsername@|${DB_USER_NAME}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@SecPassword@|${DB_USER_PASS}|g" ${PATH1}/Persistence.xml  ;
        echo
        echo
        #=================================================
        # UPDATE workperformer_start.sh
        #=================================================
        echo "workperformer start path: ${PATH2}"
        sudo sed -i "s|${JAVA_PATH}|${JAVA_PATH_NEW}|g" ${PATH2}/workperformer_start.sh  ;
        sudo sed -i "s|${JAVA_PATH}|${JAVA_PATH_NEW}|g" ${PATH2}/workperformer_stop.sh  ;
        sudo cat ${PATH1}/Persistence.xml | grep SchemaURL -B 2 -A 2
    elif [[ "$APP_NAME" = "claimsbatches" ]]
    then
        #=================================================
        # UPDATE Persistence.xml
        #=================================================
        sudo sed -i "s|@DatabaseDriver@|${DB_DRIVER}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@AppSchemaURL@|${APP_URL}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@AppUsername@|${DB_USER_NAME}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@AppPassword@|${DB_USER_PASS}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@SecSchemaURL@|${SEC_URL}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@SecUsername@|${DB_USER_NAME}|g" ${PATH1}/Persistence.xml  ;
        sudo sed -i "s|@SecPassword@|${DB_USER_PASS}|g" ${PATH1}/Persistence.xml  ;
        echo
        echo
        #=================================================
        # UPDATE workperformer_start.sh
        #=================================================
        echo "claimsbatches start path: ${PATH2}"
        sudo sed -i "s|${JAVA_PATH}|${JAVA_PATH_NEW}|g" ${PATH2}/custombatchprocesses.sh  ;
        #sudo sed -i "s|${JAVA_PATH}|${JAVA_PATH_NEW}|g" ${PATH2}/workperformer_stop.sh  ;
        sudo cat ${PATH1}/Persistence.xml | grep SchemaURL -B 2 -A 2
    elif [[ "$APP_NAME" = "unpacker" ]]
    then
        #=================================================
        # UPDATE unpacker.properties
        #=================================================
        echo "unpacker.properties path: ${PATH1}"
        sudo sed -i "s|@DatabaseDriver@|${DB_DRIVER}|g" ${PATH1}/unpacker.properties  ;
        sudo sed -i "s|@AppSchemaURL@|${APP_URL}|g" ${PATH1}/unpacker.properties  ;
        sudo sed -i "s|@AppUsername@|${DB_USER_NAME}|g" ${PATH1}/unpacker.properties  ;
        sudo sed -i "s|@AppPassword@|${DB_USER_PASS}|g" ${PATH1}/unpacker.properties  ;

        echo "unpacker start path: ${PATH2}"
        sudo sed -i "s|${JAVA_PATH}|${JAVA_PATH_NEW}|g" ${PATH2}/unpacker.sh  ;
        #sudo sed -i "s|${JAVA_PATH}|${JAVA_PATH_NEW}|g" ${PATH2}/Unpacker_STOP.sh  ;
        #sudo cat ${PATH1}/Persistence.xml | grep SchemaURL -B 2 -A 2
    else
        echo "Invalid APP NAME"
        exit 1
    fi


}

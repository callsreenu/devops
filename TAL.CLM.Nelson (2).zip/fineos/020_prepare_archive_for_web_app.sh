#!/usr/bin/env bash
echo ""
echo "------------------------------------------------------------------------------"
echo "TASK: Prepare Web Application Release"
echo "------------------------------------------------------------------------------"
source fineos/functions.sh
source jboss/functions.sh

APPLICATION_DISTRO="${APPLICATION_DISTRO}"
APPLICATION_NAME="${APPLICATION_NAME}"
MGMT_PORT="${MGMT_PORT}"
APP_HOME="web-apps/${TARGET_ENV}/${APPLICATION_NAME}"

echo "APPLICATION_DISTRO=${APPLICATION_DISTRO}"
echo "APPLICATION_NAME=${APPLICATION_NAME}"
echo "MGMT_PORT=${MGMT_PORT}"
echo "APP_HOME=${APP_HOME}"

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Place overlay files in OVERLAYS_HOME"
echo "------------------------------------------------------------------------------"
sudo mkdir -p ${OVERLAYS_HOME}/${APPLICATION_NAME}
sudo cp ${BUILD_SOURCESDIRECTORY}/fineos/files/${TARGET_ENV}/web-apps/${APPLICATION_NAME}/* ${OVERLAYS_HOME}/${APPLICATION_NAME}/
updateJBossOwnership

echo 
echo "------------------------------------------------------------------------------"
echo "REMEDIATION - Replace INVALID jboss-deployment-structure.xml (from vendor)"
echo "NB: This file remains constant across environments"
echo "------------------------------------------------------------------------------"
DISTRO_FILE_NAME="${APPLICATION_DISTRO##*/}"
TARGET_DIRECTORY="${JBOSS_BASE}/temp/${APP_HOME}"

echo "replaceVendorFilesInDistro \"${APPLICATION_DISTRO}\" \"${TARGET_DIRECTORY}\""
replaceVendorFilesInDistro "${APPLICATION_DISTRO}" "${TARGET_DIRECTORY}"
echo
echo "Updated archive:"
ls -l "${TARGET_DIRECTORY}/${DISTRO_FILE_NAME}"

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Place ENV-specific properties files in Overlays directory"
echo "------------------------------------------------------------------------------"
#
# The following files are different per environment, hence will be overridden with overlays at deploy time
sudo cp "fineos/files/${TARGET_ENV}/web-apps/${APPLICATION_NAME}/fineos.properties" "${OVERLAYS_HOME}/${APPLICATION_NAME}/fineos.properties"
sudo cp "fineos/files/${TARGET_ENV}/web-apps/${APPLICATION_NAME}/log4j.properties" "${OVERLAYS_HOME}/${APPLICATION_NAME}/log4j.properties"
sudo cp "fineos/files/${TARGET_ENV}/web-apps/${APPLICATION_NAME}/jboss-web.xml" "${OVERLAYS_HOME}/${APPLICATION_NAME}/jboss-web.xml"
sudo cp "fineos/files/${TARGET_ENV}/web-apps/${APPLICATION_NAME}/jboss-deployment-structure.xml" "${OVERLAYS_HOME}/${APPLICATION_NAME}/jboss-deployment-structure.xml"

echo "OVERLAYS_HOME path: ${OVERLAYS_HOME}/${APPLICATION_NAME}"
echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Register Deployment Overlays"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    # jboss web xml overlay
    if (outcome == success) of /deployment-overlay=${APPLICATION_NAME}-overlay:read-resource 
        echo "Removing old overlay for ${TARGET_DIRECTORY}/${APPLICATION_NAME}"
        deployment-overlay remove --name=${APPLICATION_NAME}-overlay
        reload --admin-only=true
        echo "Reloading..."
    end-if

    # Deploy in 'disabled' state to prevent failure as a result of missing overlays / invalid configuration details
    deployment deploy-file ${TARGET_DIRECTORY}/${DISTRO_FILE_NAME} --name=${APPLICATION_NAME} --runtime-name=${APPLICATION_NAME}.war --replace --disabled

    echo "Adding overlays for ${APPLICATION_NAME}-89.1.1.war..."
    deployment-overlay add \
    --name=${APPLICATION_NAME}-overlay \
    --content=/WEB-INF/classes/fineos.properties=${OVERLAYS_HOME}/${APPLICATION_NAME}/fineos.properties,/WEB-INF/classes/log4j.properties=${OVERLAYS_HOME}/${APPLICATION_NAME}/log4j.properties \
    --deployments="${APPLICATION_NAME}" \
    --redeploy-affected

    # echo "Reloading..."
    # reload

    # Deploy (enable)
    # deployment deploy-file ${TARGET_DIRECTORY}/${DISTRO_FILE_NAME} --name=${APPLICATION_NAME} --runtime-name=${APPLICATION_NAME}.war
    deployment enable ${APPLICATION_NAME}

    # echo "Reloading..."
    # reload

    deployment info ${APPLICATION_NAME}

END_OF_SCRIPT
) && executeInstanceCLI "${APPLICATION_NAME}" "${MGMT_PORT}" "${SCRIPT}" 

echo
echo "FINISHED"

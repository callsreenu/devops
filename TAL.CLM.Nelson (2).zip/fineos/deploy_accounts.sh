#!/usr/bin/env bash

echo "------------------------------------------------------------------------------"
echo "TARGET_ENV: ${TARGET_ENV}"
echo "------------------------------------------------------------------------------"

sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u UAT-CLM-ADMIN1 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/frontoffice/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u UAT-CLM-ADMIN1 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/analytics/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u UAT-CLM-ADMIN2 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/frontoffice/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u UAT-CLM-ADMIN2 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/analytics/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u UAT-CLM-ADMIN3 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/frontoffice/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u UAT-CLM-ADMIN3 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/analytics/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u UAT-CLM-ADMIN4 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/frontoffice/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u UAT-CLM-ADMIN4 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/analytics/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u mkennedy3 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/frontoffice/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u mkennedy3 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/analytics/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u belliott -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/frontoffice/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u belliott -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/analytics/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u Zmwangi2 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/frontoffice/configuration" jboss
sudo su -c "/jboss/jboss-eap-7.3/bin/add-user.sh -a -u Zmwangi2 -p 3cdbf1c4 -g fineosaccessrole -sc /jboss/instances/jboss-eap-7.3/analytics/configuration" jboss

echo "------------------------------------------------------------------------------"
echo "User Accounts successfully created."
echo "------------------------------------------------------------------------------"
#!/usr/bin/env bash
source fineos/functions.sh
echo "------------------------------------------------------------------------------"
echo "TASK: Application Server Setup - FINEOS 8.9"
echo "------------------------------------------------------------------------------"

[[ -z "${TARGET_ENV}" ]]  && echo -e "TARGET_ENV is blank. Setting to 'akeso-dev'." && TARGET_ENV=akeso-dev
echo "TARGET_ENV='${TARGET_ENV}'"

[[ -z "${TARGET_ENV}" ]]  && echo -e "TARGET_ENV is blank. Setting to 'akeso-dev2'." && TARGET_ENV=akeso-dev2
echo "TARGET_ENV='${TARGET_ENV}'"

[[ -z "${FINEOS_USER}" ]]  && echo -e "FINEOS_USER is blank. Setting to '${JBOSS_USER}'."
echo "FINEOS_USER='${FINEOS_USER}'"

[[ -z "${FINEOS_USER_GROUP}" ]]  && echo -e "FINEOS_USER_GROUP is blank. Setting to '${JBOSS_USER}'."
echo "FINEOS_USER_GROUP='${FINEOS_USER_GROUP}'"


echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Create Java App Directories if they don't already exist"
echo "Target Env: $TARGET_ENV"
echo "------------------------------------------------------------------------------"
#sudo mkdir -p /opt/fineos/java-apps/$TARGET_ENV/claimsbatches

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Set Directory Permissions"
echo "Update permissions if not running FINEOS applications under the root account"
echo "------------------------------------------------------------------------------"
sudo chown -R $FINEOS_USER:$FINEOS_USER_GROUP /opt/fineos
sudo chmod -R 755 /opt/fineos
sudo chmod -R g+s /opt/fineos
sudo setfacl -R -d -m g:$FINEOS_USER_GROUP:rwx /opt/fineos

APPLICATION_DISTRO="${CLAIMSBATCHES_DISTRO}"
APPLICATION_NAME=claimsbatches
APP_HOME="java-apps/${TARGET_ENV}/${APPLICATION_NAME}"
echo -e "APP_HOME=${APP_HOME}"

echo "------------------------------------------------------------------------------"
echo "Decompress (unzip) the Application Archive to a APP location"
echo "------------------------------------------------------------------------------"
[[ -d "${FINEOS_BASE}/${APP_HOME}" ]] && sudo rm -Rf "${FINEOS_BASE}/${APP_HOME}"
sudo mkdir -p "${FINEOS_BASE}/${APP_HOME}" 
sudo unzip -q "${APPLICATION_DISTRO}" -d "${FINEOS_BASE}/${APP_HOME}" 
sudo cd "${FINEOS_BASE}/${APP_HOME}"
find ./ -type f -name "*.sh" -exec chmod ug+x '{}' \; > /dev/null 2>&1
sudo ls -lrt
sudo cp ${BUILD_SOURCESDIRECTORY}/fineos/files/${TARGET_ENV}/java-apps/${APPLICATION_NAME}/fineos.properties ${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/classes/
sudo cp ${BUILD_SOURCESDIRECTORY}/fineos/files/${TARGET_ENV}/java-apps/${APPLICATION_NAME}/Persistence.xml ${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/config/envs/fineosenv/
#sudo cp ${BUILD_SOURCESDIRECTORY}/fineos/files/${TARGET_ENV}/java-apps/${APPLICATION_NAME}/WorkPerformer_config.xml ${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/config/envs/fineosenv/
#RUNNING_ON_PORT=8090
#sudo sed -i 's/RUNNING_ON_PORT=8090/RUNNING_ON_PORT=8090/g' ${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/bin/WorkPerformer_STOP.bat
#${FINEOS_BASE}/${APP_HOME}/config/envs/fineosenv/workperformer_start_wrapper.conf 
sudo cd ${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/bin/
sudo chmod 755 ${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/bin/utils/*
sudo cd ${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/bin/ && pwd
DB_PASS="${DB_USER_PASS}"
echo "DB_USER_PASS******: ${DB_PASS}"
echo "DB_USER_PASS******: ${DB_USER_PASS}"
echo "sudo updateFilesForJavaApps '${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/bin/utils' '${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/config/envs/fineosenv'"
updateFilesForJavaApps "${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/config/envs/fineosenv" "${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/bin/utils" "${APPLICATION_NAME}"

echo "------------------------------------------------------------------------------"
echo "Creating JBoss non-login user '${FINEOS_USER}' with no home folder."
echo "------------------------------------------------------------------------------"
sudo id -u fineos &>/dev/null || sudo useradd -M fineos
sudo usermod -L fineos
#sudo chown fineos:fineos /opt/fineos/ 
sudo chown -R fineos:fineos /opt/fineos/java-apps
#sudo chown -R fineos:fineos /opt/fineos/temp
pwd
sudo cd ${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/bin/
pwd
#sudo echo "FINEOS_USER=${​​FINEOS_USER}​​"
#sudo su -c "./WorkPerformer_START.sh" "${FINEOS_USER}"
sudo su -c "cd ${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/bin/ && ls -l && nohup ./custombatch.sh &" "fineos"
#sudo cd ${FINEOS_BASE}/${APP_HOME}/fineos-claimsbatches-${CLAIMSBATCHES_VERSION}/bin/
sudo pwd
#sudo ./WorkPerformer_START.sh
#sudo pwd
echo "FINISHED"
#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "Creating JBoss non-login user '${FINEOS_USER}' with no home folder."
echo "------------------------------------------------------------------------------"
sudo id -u ${FINEOS_USER:-fineos} &>/dev/null || sudo useradd -M ${FINEOS_USER:-fineos}
echo "sudo usermod -L ${FINEOS_USER:-fineos}"
sudo usermod -L ${FINEOS_USER:-fineos}
# Add current user to FINEOS group
echo "sudo gpasswd -a $USER ${FINEOS_USER:-fineos}"
sudo gpasswd -a $USER ${FINEOS_USER:-fineos}

echo
echo "FINISHED"

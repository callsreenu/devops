#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Setup FINEOS Trust Store"
echo "------------------------------------------------------------------------------"

[[ -z "${TARGET_ENV}" ]]  && echo -e "TARGET_ENV is blank. Setting to 'akeso-dev'." && TARGET_ENV=akeso-dev
echo "TARGET_ENV='${TARGET_ENV}"

[[ -z "${JBOSS_USER}" ]]  && echo -e "JBOSS_USER is blank. Setting to 'jboss'." && JBOSS_USER=jboss
echo "JBOSS_USER='${JBOSS_USER}"

[[ -z "${FINEOS_USER}" ]]  && echo -e "FINEOS_USER is blank. Setting to '${JBOSS_USER}'." && FINEOS_USER=$JBOSS_USER
echo "FINEOS_USER='${FINEOS_USER}"

[[ -z "${FINEOS_USER_GROUP}" ]]  && echo -e "FINEOS_USER_GROUP is blank. Setting to '${JBOSS_USER}'." && FINEOS_USER_GROUP=$JBOSS_USER
echo "FINEOS_USER_GROUP='${FINEOS_USER_GROUP}"


echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Copy required CA Certs to the Server:"
echo "------------------------------------------------------------------------------"
/tmp/MyCertCA1_2030.pem

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Take a copy of the Java Truststore:"
echo "------------------------------------------------------------------------------"
cp $JAVA_HOME/jre/lib/security/cacerts /opt/fineos/keystores

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Add CA Cert:"
echo "------------------------------------------------------------------------------"
$JAVA_HOME/bin/keytool -keystore /opt/fineos/keystores/cacerts -storepass changeit -import -noprompt -file /tmp/MyCertCA1_2030.pem -alias MyCertCA1_2030

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Confirm the certs within the new Truststore:"
echo "------------------------------------------------------------------------------"
$JAVA_HOME/bin/keytool -keystore /opt/fineos/keystores/cacerts -storepass changeit -list

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Apply secure Linux permissions to the Truststore:"
echo "------------------------------------------------------------------------------"
chmod 640 /opt/fineos/keystores/*

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Update Owner of the Truststore (if required):"
echo "------------------------------------------------------------------------------"
sudo chown -R $FINEOS_USER:$FINEOS_USER_GROUP /opt/fineos/keystores/*

echo "FINISHED"

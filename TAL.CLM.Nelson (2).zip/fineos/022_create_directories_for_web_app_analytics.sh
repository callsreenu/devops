#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Prepare Web Application Release"
echo "------------------------------------------------------------------------------"
source fineos/functions.sh
source jboss/functions.sh

APP_HOME="web-apps/${TARGET_ENV}/analytics"

echo 
echo "------------------------------------------------------------------------------"
echo "Create ENV+APP-specific FINEOS folders exist..."
echo "------------------------------------------------------------------------------"
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/export
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/import
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/logs
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/rulesclasses
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/savedselection
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/gc-logs
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/heap-dumps
updateFineosOwnership

echo
echo "FINISHED"

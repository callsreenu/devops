#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Download vendor artifacts"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

tempdir=$(mktemp -d) &&
mkfifo "$tempdir/fifo" &&
exec 3<> "$tempdir/fifo" || exit 1

FINEOS_DOWNLOAD_USER=${FINEOS_DOWNLOAD_USER}
FINEOS_DOWNLOAD_PASSWORD=${FINEOS_DOWNLOAD_PASSWORD}

echo "FINEOS_DOWNLOAD_USER='${FINEOS_DOWNLOAD_USER}'"
echo "FINEOS_DOWNLOAD_PASSWORD='${FINEOS_DOWNLOAD_PASSWORD}'"

[[ -z "${FINEOS_DOWNLOAD_USER}" ]]     && echo "ERROR: No user."     && exit 1;
[[ -z "${FINEOS_DOWNLOAD_PASSWORD}" ]] && echo "ERROR: No password." && exit 1;

external_links=(
    https://nexus-apac.fineos.com/nexus/repository/tal/com/fineos/akeso/fineos-claimsbatches/89.1.1/fineos-claimsbatches-89.1.1.zip
)
#     https://nexus-apac.fineos.com/nexus/repository/tal/com/fineos/akeso/fineos-analytics-sso/89.1.1/fineos-analytics-sso-89.1.1.war
#     https://nexus-apac.fineos.com/nexus/repository/tal/com/fineos/akeso/fineos-analytics/89.1.1/fineos-analytics-89.1.1.war
#     https://nexus-apac.fineos.com/nexus/repository/tal/com/fineos/akeso/fineos-services/89.1.1/fineos-services-89.1.1.war
#     https://nexus-apac.fineos.com/nexus/repository/tal/com/fineos/akeso/frontoffice/89.1.1/frontoffice-89.1.1.war
#     https://nexus-apac.fineos.com/nexus/repository/tal/com/fineos/akeso/frontoffice-sso/89.1.1/frontoffice-sso-89.1.1.war
#     https://nexus-apac.fineos.com/nexus/repository/tal/com/fineos/akeso/fineos-workperformer/89.1.1/fineos-workperformer-89.1.1.zip
#     https://nexus-apac.fineos.com/nexus/repository/tal/com/fineos/akeso/environmentcreator_analytics/89.1.1/environmentcreator_analytics-89.1.1.zip
#     https://nexus-apac.fineos.com/nexus/repository/tal/com/fineos/akeso/environmentcreator/89.1.1/environmentcreator-89.1.1.zip
#     https://nexus-apac.fineos.com/nexus/repository/tal/com/fineos/akeso/unpacker/89.1.1/unpacker-89.1.1.zip
# )

for url in "${external_links[@]}"
do
    {
        # wget -v --debug --user='tal-akeso-support' --password='G8!OqX&2uy' --secure-protocol=TLSv1_2 --no-check-certificate "$url"
        # wget --user='tal-akeso-support' --password='G8!OqX&2uy' "$url"
        # curl -4sLI -o /dev/null -w '%{http_code}' --max-time 60 --connect-timeout 30 --retry 2 --tlsv1.2 -u 'tal-akeso-support:G8!OqX&2uy' "$url"
        curl -4 --max-time 60 --connect-timeout 30 --retry 2 --tlsv1.2 -u 'tal-akeso-support:G8!OqX&2uy' "$url"

curl -4sLI -w '%{http_code}' --max-time 60 --connect-timeout 30 --retry 2 --tlsv1.2 -u 'tal-akeso-support:G8!OqX&2uy' 


        echo "/$CMD"
        echo
    } #>&3 &
done

invalid_links=()

for (( i = ${#external_links[@]}; i > 0; i-- ))
do
    IFS='/' read -u 3 -r http_code url
    echo -e "wget '$url'"
    echo -e "http_code: '$http_code'"
    (( 200 <= http_code && http_code <= 299 )) || invalid_links+=( "$http_code $url" )
done

echo "Found ${#invalid_links[@]} invalid links:"
(( ${#invalid_links[@]} > 0 )) && printf '%s\n' "${invalid_links[@]}"

# Confirm downloads
echo
echo "ls -alt:"
ls -alt

echo
echo "FINISHED..."
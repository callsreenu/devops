#!/usr/bin/env bash
echo
echo "-----------------------------------------------------------------------------*"
echo "* FINEOS: Create Web App Directories if they don't already exist"
echo "-----------------------------------------------------------------------------*"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/docstore/temp"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/export/environmentmigration"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/import/environmentmigration"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/import/bank"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/import/medical"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/import/occupation"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/logs"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/rulesclasses"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/savedselection"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/templates"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/gc-logs"
sudo mkdir -p "/opt/fineos/web-apps/akeso-dev/frontoffice/heap-dumps"
sudo ls -l /opt/fineos/
sudo ls -l /opt/fineos
sudo ls -l /opt

echo 
echo "-----------------------------------------------------------------------------*"
echo "* FINEOS: Set Directory Permissions"
echo "* Update permission if not running FINEOS applications under the root account"
echo "-----------------------------------------------------------------------------*"
echo "sudo chown -R ${FINEOS_USER}:${FINEOS_USER_GROUP} /opt/fineos"
sudo chown -R jboss:jboss /opt/fineos
sudo chmod -R 755 /opt/fineos
sudo chmod -R g+s /opt/fineos
echo "sudo setfacl -R -d -m g:\"${FINEOS_USER_GROUP}\":rwx /opt/fineos"
sudo setfacl -R -d -m g:jboss:rwx /opt/fineos


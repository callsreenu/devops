# step 11 (DEV), run user permission sql scripts for fineosapp and fineossec dbs - this is an output generated from step 2
# for all non-dev environments, we will perform this step once we restore uplifted database


$script_folder = "G:\Akeso\Talscripts"
$fineosapp_output = "test.sql"
echo "Performing activity on ${env:COMPUTERNAME}"
. "C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\130\Tools\Binn\SQLCMD.EXE" -S "${env:COMPUTERNAME}" -U "sa_akeso_app_sql_dev" -P "Admin@1234567" -i "$script_folder\$fineosapp_output"
if ($LastExitCode -eq 16)
{
    echo $LastExitCode
    # exit 0
}

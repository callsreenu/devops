- ==============================
-- Recreate views in APP database
-- ==============================

-- ==============================
-- Required Environment Variables
-- ==============================

-- FINEOS_SEC_DB: FINEOS SEC Database 


print '';
print N' ===================================';
print N' Recreate views in APP database';
print N' Timestamp: ' + convert(nvarchar,getdate(),113)
print N' ===================================';

ALTER VIEW [dbo].[vosgroup] AS
SELECT c, i, flags, C_OSUSER_UPDATEDBY, I_OSUSER_UPDATEDBY, LASTUPDATEDATE, Name
FROM GEMINISVP1sec.dbo.VOSGroup
GO

ALTER VIEW [dbo].[vosprivilegeholderLink] AS
SELECT c, i, flags, C_OSUSER_UPDATEDBY, I_OSUSER_UPDATEDBY, LASTUPDATEDATE, AltKey, RelType, C_OSPVHOLD_From, I_OSPVHOLD_From, C_OSPVHOLD_To, I_OSPVHOLD_To
FROM GEMINISVP1sec.dbo.VOSPrivilegeHolderLink
GO

ALTER VIEW [dbo].[vosuser] AS
SELECT c, i, flags, C_OSUSER_UPDATEDBY, I_OSUSER_UPDATEDBY, LASTUPDATEDATE, UserID, UserEnabled, Name
FROM GEMINISVP1sec.dbo.VOSUser
GO

- ==============================
-- Truncate TSTAT tables
-- ==============================

print '';
print N' ===================================';
print N' Truncate TSTAT tables';
print N' Timestamp: ' + convert(nvarchar,getdate(),113)
print N' ===================================';

DECLARE @SQL NVARCHAR(MAX) = '';

-- create the SQL statement

SELECT @SQL += 'TRUNCATE TABLE ' + QUOTENAME(name) + ';' + CHAR(10)

FROM sys.tables

WHERE name LIKE 'TSTAT%';

-- execute the SQL statement

EXEC sp_executesql @SQL;


-- ==============================
-- Truncate TOSEVENT table
-- ==============================

print '';
print N' ===================================';
print N' Truncate TOSEVENT table';
print N' Timestamp: ' + convert(nvarchar,getdate(),113)
print N' ===================================';

TRUNCATE TABLE TOSEVENT;

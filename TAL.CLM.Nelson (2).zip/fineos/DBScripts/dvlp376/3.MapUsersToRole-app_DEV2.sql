-- This script is generated from the Map Users to Roles spreadsheet.
-- DO NOT EDIT THIS SCRIPT MANUALLY!
-- Last generated on 19/11/2020 15:44:21

CREATE OR ALTER PROCEDURE MapUserToRole
 @userId nvarchar(50),   
 @deptName nvarchar(80),
 @role nvarchar(50)
AS   
 DECLARE @userI int = (select I from vosuser where userid = @userId),
 @roleI int = (select I from TOCRole where name= @role and I_Department in 
     (select i from vosgroup where name = @deptName));  

If @userI is not null AND @roleI is not null AND
 NOT Exists (select I from TOCRoleholderLink where I_HOLDER in 
 (select I from vosuser where userid = @userId ) 
  and  I_OCROLE_HOLDERLINKS in (select i from TOCRole where name = @role 
  and I_Department in (select I from vosgroup where name= @deptName)))
 Begin
   DECLARE @roleLinkI  int;
   INSERT INTO SOCROLEHOLDERLINK DEFAULT VALUES SET @roleLinkI = (SELECT @@IDENTITY AS 'I');
   INSERT into TOCROLEHOLDERLINK (C, I, FLAGS,LASTUPDATEDATE, BOEVERSION, C_OSUSER_UPDATEDBY, I_OSUSER_UPDATEDBY, 
                     C_HOLDER, I_HOLDER, C_OCROLE_HOLDERLINKS, I_OCROLE_HOLDERLINKS)
    VALUES(11204, @roleLinkI, 'PE', GETDATE(), 0, 1000, 1, 1000, @userI, 11202, @roleI);
 end;
ELSE
 IF @userI is null
     PRINT N'User "' + @userId + '" does not exist!'
 IF @roleI is null
     PRINT N'Role "' + @role + '" does not exist in department "' + @deptName + '"!'
GO

--Removing existing links between roles and existing test users.
If Exists (SELECT I From TOCROLEHOLDERLINK WHERE C_HOLDER = 1000 AND I_HOLDER >= 20000)
Begin
  DELETE From TOCROLEHOLDERLINK WHERE C_HOLDER = 1000 AND I_HOLDER >= 20000 ;
End;
GO

--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Technical Services Team', @role = N'Claims Technical Specialist';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Technical Services Team', @role = N'Forensic Accountant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Technical Services Team', @role = N'Principal Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Technical Services Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Technical Services Team', @role = N'Chief Medical Officer';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Group Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Lump Sum Team 4', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Offshore Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Health Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Retail Super Team 3', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Retail Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Triage', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Team Support', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-TM1', @deptName = N'Triage', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-SCA1', @deptName = N'Technical Services Team', @role = N'Principal Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC5', @deptName = N'Technical Services Team', @role = N'Forensic Accountant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC6', @deptName = N'Technical Services Team', @role = N'Chief Medical Officer';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-SCM', @deptName = N'Concierge', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-SCM', @deptName = N'Concierge', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-SCM', @deptName = N'Concierge', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC2', @deptName = N'Concierge', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC2', @deptName = N'Concierge', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC3', @deptName = N'Concierge', @role = N'Claims Consultant';
EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN1', @deptName = N'Group Team 1', @role = N'Claims Consultant';
EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN1', @deptName = N'Retail Team 1', @role = N'Claims Consultant';
EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN2', @deptName = N'Retail Super Team 3', @role = N'Claims Consultant';
EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN3', @deptName = N'Lump Sum Team 4', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Group Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Group Team 2', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Group Team 5', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Group Team 6', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Group Team 7', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Retail Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Retail Team 2', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Retail Super Team 3', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Lump Sum Team 4', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Triage', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Triage', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Concierge', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Health Support Team', @role = N'Health Support Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Concierge', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Concierge', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Concierge', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Death or Terminal Illness', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Disputes Resolution Team', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Expenses', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Group Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Group Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Group Team 5', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Group Team 6', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Group Team 7', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Health Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Lump Sum Team 4', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Offshore Support Team', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Retail Super Team 3', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Retail Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Triage', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Team Support', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Technical Services Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Triage', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Archived Claim Team', @role = N'Archived Claim Team';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ADMIN4', @deptName = N'Executives', @role = N'Executive';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ATS2', @deptName = N'Triage', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ATS2', @deptName = N'Triage', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ATS2', @deptName = N'Triage', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ATS1', @deptName = N'Triage', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ATS1', @deptName = N'Triage', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC1', @deptName = N'Triage', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-C1', @deptName = N'Group Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-C2', @deptName = N'Group Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-C3', @deptName = N'Group Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-CTS', @deptName = N'Technical Services Team', @role = N'Claims Technical Specialist';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-DM', @deptName = N'Disputes Resolution Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-DM', @deptName = N'Disputes Resolution Team', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ECM1', @deptName = N'CSD - ECM Death A Team', @role = N'Case Managers';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ECM2', @deptName = N'CSD - ECM Death B Team', @role = N'Case Managers';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ECM3', @deptName = N'CSD - ECM FH and SCI Team', @role = N'Case Managers';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-ECM4', @deptName = N'CSD - ECM TPD, TI and PI Team', @role = N'Case Managers';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC32', @deptName = N'CSD - ECM Death A Team', @role = N'Case Managers';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC32', @deptName = N'CSD - ECM Death A Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC32', @deptName = N'CSD - ECM Death B Team', @role = N'Case Managers';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC32', @deptName = N'CSD - ECM Death B Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC32', @deptName = N'CSD - ECM FH and SCI Team', @role = N'Case Managers';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC32', @deptName = N'CSD - ECM FH and SCI Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC32', @deptName = N'CSD - ECM TPD, TI and PI Team', @role = N'Case Managers';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC32', @deptName = N'CSD - ECM TPD, TI and PI Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-FA', @deptName = N'Health Support Team', @role = N'Health Support Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-FA', @deptName = N'Health Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Health Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'CIA Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Concierge', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Group Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Group Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Group Team 5', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Group Team 6', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Group Team 7', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Lump Sum Team 4', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Offshore Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Retail Super Team 3', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Retail Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Retail Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Triage', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Team Support', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Technical Services Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Disputes Resolution Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Executives', @role = N'Executive';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Death or Terminal Illness', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Expenses', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Income Protection', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-GM', @deptName = N'Offshore Support Team', @role = N'Authorising';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-HS', @deptName = N'Health Support Team', @role = N'Health Support Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Archived Claim Team', @role = N'Archived Claim Team';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Group Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Group Team 2', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Group Team 5', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Group Team 6', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Group Team 7', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Retail Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Retail Team 2', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Retail Super Team 3', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Lump Sum Team 4', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Triage', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Triage', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Concierge', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Health Support Team', @role = N'Health Support Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Archived Claim Team', @role = N'Archived Claim Team';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-NTCM', @deptName = N'Archived Claim Team', @role = N'Archived Claim Team';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Health Support Team', @role = N'Health Support Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Health Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'CIA Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Concierge', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Group Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Group Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Group Team 5', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Group Team 6', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Group Team 7', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Lump Sum Team 4', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Offshore Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Retail Super Team 3', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Retail Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Retail Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Triage', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Team Support', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Technical Services Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Disputes Resolution Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Executives', @role = N'Executive';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Death or Terminal Illness', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Expenses', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Income Protection', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-PC', @deptName = N'Offshore Support Team', @role = N'Authorising';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-SC1', @deptName = N'Group Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-SC1', @deptName = N'Group Team 1', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-SCA', @deptName = N'Group Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-SCA', @deptName = N'Group Team 1', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-SCA', @deptName = N'Group Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-DRC', @deptName = N'Disputes Resolution Team', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC7', @deptName = N'CIA Team', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC8', @deptName = N'CIA Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC8', @deptName = N'CIA Team', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC9', @deptName = N'Team Support', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC9', @deptName = N'Team Support - Assessment and Financial', @role = N'Senior Claims Administrator';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC9', @deptName = N'Team Support - Assessment and Financial', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC9', @deptName = N'Team Support - Milestones', @role = N'Senior Claims Administrator';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC9', @deptName = N'Team Support - Milestones', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC9', @deptName = N'Team Support - Pilot Ops and KAT', @role = N'Senior Claims Administrator';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC9', @deptName = N'Team Support - Pilot Ops and KAT', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC9', @deptName = N'Team Support - Support and Collaboration', @role = N'Senior Claims Administrator';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC9', @deptName = N'Team Support - Support and Collaboration', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC10', @deptName = N'Team Support - Milestones', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC11', @deptName = N'Expenses', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Health Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'CIA Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Concierge', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Group Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Group Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Group Team 5', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Group Team 6', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Group Team 7', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Lump Sum Team 4', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Offshore Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Retail Super Team 3', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Retail Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Retail Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Triage', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Team Support', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Technical Services Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Disputes Resolution Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Executives', @role = N'Executive';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Death or Terminal Illness', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Expenses', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Income Protection', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC12', @deptName = N'Offshore Support Team', @role = N'Authorising';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC13', @deptName = N'Offshore Support Team', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC14', @deptName = N'Offshore Support Team', @role = N'Pilot Ops and KAT';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC15', @deptName = N'Offshore Support Team', @role = N'Authorising';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC16', @deptName = N'Offshore Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC16', @deptName = N'Offshore Support Team', @role = N'Team Member';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC16', @deptName = N'Offshore Support Team', @role = N'Pilot Ops and KAT';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC16', @deptName = N'Offshore Support Team', @role = N'Authorising';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC17', @deptName = N'Retail Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC18', @deptName = N'Retail Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC19', @deptName = N'Retail Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC21', @deptName = N'Retail Team 1', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC21', @deptName = N'Retail Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC22', @deptName = N'Retail Team 1', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC22', @deptName = N'Retail Team 1', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC22', @deptName = N'Retail Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC23', @deptName = N'Lump Sum Team 4', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC24', @deptName = N'Lump Sum Team 4', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC24', @deptName = N'Lump Sum Team 4', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC25', @deptName = N'Lump Sum Team 4', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC25', @deptName = N'Lump Sum Team 4', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC25', @deptName = N'Lump Sum Team 4', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC26', @deptName = N'Retail Super Team 3', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC27', @deptName = N'Retail Super Team 3', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC28', @deptName = N'Retail Super Team 3', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC29', @deptName = N'Retail Super Team 3', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC30', @deptName = N'Retail Super Team 3', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC30', @deptName = N'Retail Super Team 3', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC4', @deptName = N'Retail Super Team 3', @role = N'Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC4', @deptName = N'Retail Super Team 3', @role = N'Senior Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC4', @deptName = N'Retail Super Team 3', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC31', @deptName = N'Technical Services Team', @role = N'Principal Claims Consultant';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Health Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'CIA Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Concierge', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Group Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Group Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Group Team 5', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Group Team 6', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Group Team 7', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Lump Sum Team 4', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Offshore Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Retail Super Team 3', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Retail Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Retail Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Triage', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Team Support', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Technical Services Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Disputes Resolution Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Death or Terminal Illness', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Expenses', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Income Protection', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Offshore Support Team', @role = N'Authorising';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC38', @deptName = N'Archived Claim Team', @role = N'Archived Claim Team';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Health Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'CIA Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Concierge', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Group Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Group Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Group Team 5', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Group Team 6', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Group Team 7', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Lump Sum Team 4', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Offshore Support Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Retail Super Team 3', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Retail Team 1', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Retail Team 2', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Triage', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Team Support', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Technical Services Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Disputes Resolution Team', @role = N'Team Manager';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Death or Terminal Illness', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Expenses', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Income Protection', @role = N'Delegated Authority';
--EXECUTE MapUserToRole @userId = N'UAT-CLM-RC39', @deptName = N'Offshore Support Team', @role = N'Authorising';
GO

drop Procedure MapUserToRole;
GO

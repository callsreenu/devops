USE [GEMINISVP1sec]
GO

ALTER VIEW [dbo].[vosgroup] AS
SELECT c, i, flags, C_OSUSER_UPDATEDBY, I_OSUSER_UPDATEDBY, LASTUPDATEDATE, Name
FROM GEMINISVP1sec.dbo.VOSGroup
GO

ALTER VIEW [dbo].[vosprivilegeholderLink] AS
SELECT c, i, flags, C_OSUSER_UPDATEDBY, I_OSUSER_UPDATEDBY, LASTUPDATEDATE, AltKey, RelType, C_OSPVHOLD_From, I_OSPVHOLD_From, C_OSPVHOLD_To, I_OSPVHOLD_To
FROM GEMINISVP1sec.dbo.VOSPrivilegeHolderLink
GO

ALTER VIEW [dbo].[vosuser] AS
SELECT c, i, flags, C_OSUSER_UPDATEDBY, I_OSUSER_UPDATEDBY, LASTUPDATEDATE, UserID, UserEnabled, Name
FROM GEMINISVP1sec.dbo.VOSUser
GO

print '';
print N' ===================================';
print N' Recreate views in APP database';
print N' Timestamp: ' + convert(nvarchar,getdate(),113)
print N' ===================================';
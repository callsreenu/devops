-- ==============================
-- Truncate TSTAT tables
-- ==============================

USE [GEMINISVP1sec]
GO

DECLARE @SQL NVARCHAR(MAX) = '';

-- create the SQL statement

SELECT @SQL += 'TRUNCATE TABLE ' + QUOTENAME(name) + ';' + CHAR(10)

FROM sys.tables

WHERE name LIKE 'TSTAT%';

-- execute the SQL statement

EXEC sp_executesql @SQL;

print '';
print N' ===================================';
print N' Truncate TSTAT tables';
print N' Timestamp: ' + convert(nvarchar,getdate(),113)
print N' ===================================';

-- ==============================
-- Truncate TOSEVENT table
-- ==============================

TRUNCATE TABLE TOSEVENT;

print '';
print N' ===================================';
print N' Truncate TOSEVENT table';
print N' Timestamp: ' + convert(nvarchar,getdate(),113)
print N' ===================================';
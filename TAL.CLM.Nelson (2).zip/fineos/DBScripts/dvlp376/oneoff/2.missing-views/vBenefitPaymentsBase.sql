USE [GEMINISVP1VIEWS]
GO

/****** Object:  View [dbo].[vBenefitPaymentsBase]    Script Date: 28/09/2022 9:45:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vBenefitPaymentsBase] AS (
--
-- Insert the SQL here
--
SELECT    CASE TOLPaymentEventInterface.EventType
            WHEN 'PaymentOut' THEN
               CASE TOLPaymentEventInterface.PayeeCustomer
                  WHEN 'ATO' THEN
                     '03'
                  ELSE
                     CASE WHEN vPayment_Line_Split.AMOUNT_SPLT LIKE '%Main Payment Line%' THEN
                           '01'
                           WHEN vPayment_Line_Split.AMOUNT_SPLT LIKE '%Partial Disability Amount%' THEN
                           '01'
                           WHEN  vPayment_Line_Split.AMOUNT_SPLT LIKE '%Total Disability Amount%' THEN
                           '01'
                        ELSE '02'
                     END
                  END
            WHEN 'PaymentOut Cancellation' THEN
            CASE SUBSTRING(vPayment_Line_Split.AMOUNT_SPLT,1,34)
               WHEN 'Superannuation Redirection to Fund' THEN
                  '05'
               ELSE
                 CASE SUBSTRING(vPayment_Line_Split.AMOUNT_SPLT,1,27) 
                  WHEN 'SIS Act Redirection To Fund' THEN
                  '05'
                 ELSE '04'
                 END
            END
          END                                                              AS Transaction_Type              -- FSD-20 - transaction type
         ,TOLClaimDetailsForInt.ClaimNumber                                AS Claim_Number                  -- FSD-21 - claim number
         ,BenCase.CaseNumber                                               AS Sub_Case_Number               -- FSD-22 - sub case number
         ,BenCaseType.Name                                                 AS Sub_Case_Type
         ,vPayment_Line_Split.AMOUNT_SPLT                                  AS Payment_Amount_Split          -- FSD-23 - payment adjustments / payment amount split
         ,MAX( CASE WHEN TOLPaymentEventInterface.PaymentType = 'Adhoc'
                                                            THEN
                                                              Due_desc.NAME 
                                                            ELSE
                                                              TOLAllocationInstruction.Category
                                                            END  )                                                                                                                         AS Type_Of_Benefit_Payment       -- FSD-24 - type of benefit payment
         ,MAX(COALESCE(CreateUser.Name,
                       ParentCreateUser.Name))                             AS Payment_Creator               -- FSD-25 - payment creator
         ,MAX(AuthUser.Name)                                               AS Payment_Authoriser            -- FSD-26 - payment authoriser
         ,MAX(TOLAllocationInstruction.LASTUPDATEDATE)                     AS Payment_Authorised_Date       -- FSD-27 - payment authorisation date
         ,CASE WHEN MAX(TOLDueEvent.LASTUPDATEDATE) IS NULL AND MAX(parentDueEvent.LASTUPDATEDATE) IS NULL
              THEN MAX(TOLAllocationInstruction.LASTUPDATEDATE)
                                               
                                               ELSE MAX(COALESCE(TOLDueEvent.LASTUPDATEDATE,
                       parentDueEvent.LASTUPDATEDATE))
                                                                              END
                              AS Payment_Creation_Date      -- FSD-28 - payment creation date
         ,MIN(TOLPaymentDetailsForInt.PaymentStartP)                       AS Payment_Period_From_Date      -- FSD-29 - payment period from date
         ,CASE WHEN TOLPaymentEventInterface.PaymentType = 'Adhoc' THEN
                  NULL
               ELSE
                  MAX(TOLPaymentDetailsForInt.PaymentEndPer)
          END                                                              AS Payment_Period_To_Date        -- FSD-30 - payment period to date
         ,TOLPaymentEventInterface.EventType                               AS Event_Type                    --        - not defined as an extracted column
         ,TOLPaymentEventInterface.TransStatusDa                           AS Date_Of_Payment               -- FSD-31 - Date of payment
         ,PayFreq.Name                                                     AS Payment_Frequency             -- FSD-32 - Payment frequency
         ,TOLPaymentEventInterface.PaymentMethod                           AS Payment_Method                -- FSD-33 - Payment method
         ,TOLPaymentEventInterface.Amount_MonAmt                           AS Payment_Amount                -- FSD-34 - Payment amount
         ,TOLPaymentEventInterface.PayeeFullName                           AS Payee_Name                    -- FSD-35 - Payee name
         ,TOLExternalInvestmentAccount.AccountName                         AS Payee_Bank_Account_Name       -- FSD-36 - Payee bank account name
         ,TOLPaymentEventInterface.PayeeBankSort                           AS Payee_BSB                     -- FSD-37 - Payee BSB
         ,TOLPaymentEventInterface.PayeeAccountN                           AS Payee_Bank_Account_Number     -- FSD-38 - Payee bank account number
         ,TOLPaymentEventInterface.PayeeBankCode                           AS Payee_Bank_Code               -- FSD-39 - Payee bank code
         ,TOLPaymentEventInterface.PayeeBankInst                           AS Payee_Bank_Institution_Name   -- FSD-40 - Payee bank institution name
         ,CASE WHEN 
                              TOLPaymentEventInterface.PayeeCustomer = 'ATO'
             OR TOLPaymentEventInterface.PayeeFullName = 'CLOAS Manual Payment' 
              THEN
               'Extracted'
            ELSE
               TOLPaymentEventInterface.TransactionSt
          END                                                              AS Transaction_Status            -- FSD-41 - Transaction status
         ,TOLPaymentEventInterface.TransStatusDa                           AS Transaction_Status_Date       -- FSD-42 - Transaction status date
         ,TOLPaymentEventInterface.TransactionNo                           AS Payment_Reference             -- FSD-43 - Payment reference / transaction number
         ,TOLPaymentOutEvent.I                                             AS Payment_Event_Id              -- FSD-44 - Payment event id - unique identifier from POE table
         ,TOLPaymentEventInterface.I                                       AS Payment_Transaction_Id        -- FSD-45 - Payment transaction id - unique identifier from POI table
         ,TOLPaymentEventInterface.Status                                  AS Payment_Status                -- FSD-46 - Payment status
         ,TOLPaymentEventInterface.StatusEffecti                           AS Payment_Status_Date           --        - not defined as an extracted column
         ,CASE WHEN TOLPaymentEventInterface.TransactionSt LIKE '%FAIL%' THEN
               TOLPaymentEventInterface.StatusReason
            ELSE
               NULL
          END                                                              AS Payment_Status_Reason         -- FSD-47 - Payment status reason
         ,POEStatus.Name                                                   AS Payment_Out_Event_Status      --        - not defined as an extracted column
        ,(CASE When TOLPaymentEventInterface.PayeeFullName = 'CLOAS Manual Payment'
                                             Then 'Y'
                                             Else 'N'
                                             END )                                                                                                                                                                                                           AS Manual_Payment_Flag
                              ,CAST(NULL AS DECIMAL)                                                                                                                                                                     AS PaymentEventInterfaceLinkId
                              ,vODSContractDetails.SourceSystem                                                                                                                   AS SourceSystem
                              ,TOLPaymentEventInterface.LASTUPDATEDATE                          AS PEI_Last_Update_Date          --        - not defined as an extracted column
         ,TOLPaymentOutEvent.LASTUPDATEDATE                                AS POE_Last_Update_Date          --        - not defined as an extracted column
         ,TOLPaymentEventInterface.C                                       AS C                             --        - not defined as an extracted column
         ,TOLPaymentEventInterface.I                                       AS I                             --        - not defined as an extracted column 
         ,TOLPaymentEventInterface.ExtractionDat                           AS Extraction_Date
         ,TOLPaymentEventInterface.PayeeCustomer                           AS Payee_Customer
       ,CASE TOLPaymentEventInterface.PayeeCustomer
         WHEN 'ATO' THEN
            TOCPerson.NatInsNo
         ELSE
            'NH'
       END                                                                 AS TaxFileNumber                 -- Added for Release 2
FROM              GEMINISVP1APP.dbo.TOLPaymentEventInterface
INNER JOIN        GEMINISVP1APP.dbo.TOLPaymentLineGrpForCase             ON  TOLPaymentLineGrpForCase.I_PYMNTEIF_PaymentLineGr       = TOLPaymentEventInterface.I
                                                                        AND TOLPaymentLineGrpForCase.C_PYMNTEIF_PaymentLineGr       = TOLPaymentEventInterface.C
INNER JOIN        GEMINISVP1APP.dbo.TOLClaimDetailsForInt                ON  TOLPaymentLineGrpForCase.I_CASDTLPI_CaseDetailsFo       = TOLClaimDetailsForInt.I
                                                                        AND TOLPaymentLineGrpForCase.C_CASDTLPI_CaseDetailsFo       = TOLClaimDetailsForInt.C
INNER JOIN        GEMINISVP1APP.dbo.TOCCase BenCase                      ON  TOLPaymentLineGrpForCase.I_OCCASE_PaymentLineGr         = BenCase.I
                                                                        AND TOLPaymentLineGrpForCase.C_OCCASE_PaymentLineGr         = BenCase.C
INNER JOIN        GEMINISVP1APP.dbo.TOCCaseType BenCaseType              ON  BenCaseType.C                                           = BenCase.C_OCCASTYP_Cases
                                                                        AND BenCaseType.I                                           = BenCase.I_OCCASTYP_Cases
INNER JOIN        GEMINISVP1APP.dbo.TOLPaymentOutEvent                   ON  (TOLPaymentOutEvent.I_PYMNTEIF_PaymentEventI             = TOLPaymentEventInterface.I
                                                                        AND TOLPaymentOutEvent.C_PYMNTEIF_PaymentEventI             = TOLPaymentEventInterface.C)
                                                                        OR  (TOLPaymentOutEvent.I_PYMNTEIF_CancellationP            = TOLPaymentEventInterface.I
                                                                        AND  TOLPaymentOutEvent.C_PYMNTEIF_CancellationP            = TOLPaymentEventInterface.C)
LEFT OUTER JOIN   GEMINISVP1APP.dbo.RPYMNTVNTALLCTNINAllocationIns       ON  TOLPaymentOutEvent.C                                    = RPYMNTVNTALLCTNINAllocationIns.C_From
                                                                        AND TOLPaymentOutEvent.I                                    = RPYMNTVNTALLCTNINAllocationIns.I_from
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLAllocationInstruction             ON  TOLAllocationInstruction.C                              = RPYMNTVNTALLCTNINAllocationIns.C_To
                                                                        AND TOLAllocationInstruction.I                              = RPYMNTVNTALLCTNINAllocationIns.I_To
LEFT OUTER JOIN   GEMINISVP1APP.dbo.VOSUser CreateUser                   ON  TOLAllocationInstruction.C_OSUser_Adde                  = CreateUser.C
                                                                        AND TOLAllocationInstruction.I_OSUser_Adde                  = CreateUser.I
INNER JOIN        GEMINISVP1APP.dbo.VOSUser AuthUser                     ON  TOLAllocationInstruction.C_OSUser_Acti                  = AuthUser.C
                                                                        AND TOLAllocationInstruction.I_OSUser_Acti                  = AuthUser.I
INNER JOIN        GEMINISVP1APP.dbo.TOLBenefit                           ON  TOLBenefit.C_OCCASE_BenefitCase                         = BenCase.C
                                                                        AND TOLBenefit.I_OCCASE_BenefitCase                         = BenCase.I
LEFT OUTER JOIN   vODSContractDetails                                                                                                                                ON vODSContractDetails.BenefitNumber                                                             = BenCase.CaseNumber
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLDueEvent                          ON  TOLDueEvent.C_BNFT_BenefitDues                        = TOLBenefit.C
                                                                        AND TOLDueEvent.I_BNFT_BenefitDues                          = TOLBenefit.I
                                                                        AND TOLDueEvent.C                                           = TOLAllocationInstruction.C_ABSDE_PaymentAlloca
                                                                        AND TOLDueEvent.I                                           = TOLAllocationInstruction.I_ABSDE_PaymentAlloca
LEFT OUTER JOIN  GEMINISVP1APP.dbo.TODomainInstance due_desc                                            ON due_desc.I                                                                                                                                                                               = TOLDueEvent.Descriptor
INNER JOIN        GEMINISVP1APP.dbo.TOLPaymentLineGrpForDueEvent         ON  TOLPaymentLineGrpForDueEvent.C_PLNGRCS_PaymentLineGr    = tolpaymentlinegrpforcase.C
                                                                        AND TOLPaymentLineGrpForDueEvent.I_PLNGRCS_PaymentLineGr    = tolpaymentlinegrpforcase.I
INNER JOIN        GEMINISVP1APP.dbo.TOLPaymentDetailsForInt              ON  TOLPaymentLineGrpForDueEvent.C_PYDDTLPI_PaymentDueDet   = TOLPaymentDetailsForInt.C
                                                                        AND TOLPaymentLineGrpForDueEvent.I_PYDDTLPI_PaymentDueDet   = TOLPaymentDetailsForInt.I
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLRegularPaymentBenefitRight        ON  C_BNFT_Benefit                                          = TOLBenefit.C
                                                                        AND I_BNFT_Benefit                                          = TOLBenefit.I
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLRegularPremiumComponent           ON  TOLRegularPremiumComponent.C                            = TOLRegularPaymentBenefitRight.C_RGLPRMCP_PaymentDetail
                                                                        AND TOLRegularPremiumComponent.I                            = TOLRegularPaymentBenefitRight.I_RGLPRMCP_PaymentDetail
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLPaymentFrequencyHistory           ON  TOLPaymentFrequencyHistory.C_RGLPRMCP_PaymentFreque     = TOLRegularPremiumComponent.C
                                                                        AND TOLPaymentFrequencyHistory.I_RGLPRMCP_PaymentFreque     = TOLRegularPremiumComponent.I
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TODomainInstance PayFreq             ON  PayFreq.I                                               = TOLPaymentFrequencyHistory.PremiumPaymen
INNER JOIN        GEMINISVP1APP.dbo.TOLPaymentDetails                    ON  TOLPaymentOutEvent.C_PYMNTDTL_PaymentEvent              = TOLPaymentDetails.C
                                                                        AND TOLPaymentOutEvent.I_PYMNTDTL_PaymentEvent              = TOLPaymentDetails.I
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLExternalInvestmentAccount         ON  TOLExternalInvestmentAccount.C                          = TOLPaymentDetails.C_XTRNLNVS_PaymntsAsPaye
                                                                        AND TOLExternalInvestmentAccount.I                          = TOLPaymentDetails.I_XTRNLNVS_PaymntsAsPaye
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLPurchaseDetailsForInt             ON  TOLPurchaseDetailsForInt.GroupID                        = TOLAllocationInstruction.GroupId
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLReceiptPaymentEvent               ON  TOLReceiptPaymentEvent.C_PYMNTDTL_PaymentEvent          = TOLPaymentDetails.C
                                                                        AND TOLReceiptPaymentEvent.I_PYMNTDTL_PaymentEvent          = TOLPaymentDetails.I
INNER JOIN        GEMINISVP1APP.dbo.TODomainInstance POEStatus           ON  POEStatus.I                                             = TOLPaymentOutEvent.Status
INNER JOIN        vPayment_Line_Split                                  ON  vPayment_Line_Split.C                                   = TOLPaymentEventInterface.C
                                                                        AND vPayment_Line_Split.I                                   = TOLPaymentEventInterface.I
                                                                        AND vPayment_Line_Split.claimnumber                         = TOLClaimDetailsForInt.ClaimNumber
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLSubDueEvent                        ON TOLSubDueEvent.I = TOLAllocationInstruction.I_ABSDE_PaymentAlloca
                                                                        AND TOLSubDueEvent.C = TOLAllocationInstruction.C_ABSDE_PaymentAlloca
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLAllocationInstruction parent       ON parent.I_ABSDE_PaymentAlloca = TOLSubDueEvent.I_DEVNT_DuesToAltPaye
                                                                        AND parent.C_ABSDE_PaymentAlloca = 7087
LEFT OUTER JOIN   GEMINISVP1APP.dbo.VOSUser ParentCreateUser              ON  parent.C_OSUser_Adde                  = ParentCreateUser.C
                                                                        AND parent.I_OSUser_Adde                  = ParentCreateUser.I
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLDueEvent parentDueEvent            ON parentDueEvent.I = TOLSubDueEvent.I_DEVNT_DuesToAltPaye
                                                                        AND parentDueEvent.C = TOLSubDueEvent.C_DEVNT_DuesToAltPaye
INNER JOIN        GEMINISVP1APP.dbo.TOCPartyCaseRole                      ON  TOCPartyCaseRole.C_OCCASE_Roles = BenCase.C
                                                                        AND TOCPartyCaseRole.I_OCCASE_Roles = BenCase.I
INNER JOIN        GEMINISVP1APP.dbo.TOCCaseTypeRole                       ON  TOCCaseTypeRole.C = TOCPartyCaseRole.C_OCCASETR_ImplementedRo 
                                                                        AND TOCCaseTypeRole.I = TOCPartyCaseRole.i_OCCASETR_ImplementedRo
                                                                        AND TOCCaseTypeRole.RoleName = 'Insured'
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOCPerson                             ON  TOCPerson.C = TOCPartyCaseRole.C_OCPRTY_PartyCaseRole
                                                                        AND TOCPerson.i = TOCPartyCaseRole.I_OCPRTY_PartyCaseRole
WHERE  BenCaseType.Name                                                !=   'Expenses'
GROUP BY CASE TOLPaymentEventInterface.EventType
            WHEN 'PaymentOut' THEN
               CASE TOLPaymentEventInterface.PayeeCustomer
                  WHEN 'ATO' THEN
                     '03'
                  ELSE
                     CASE WHEN vPayment_Line_Split.AMOUNT_SPLT LIKE '%Main Payment Line%' THEN
                           '01'
                           WHEN vPayment_Line_Split.AMOUNT_SPLT LIKE '%Partial Disability Amount%' THEN
                           '01'
                           WHEN  vPayment_Line_Split.AMOUNT_SPLT LIKE '%Total Disability Amount%' THEN
                           '01'
                        ELSE '02'
                     END
                  END
            WHEN 'PaymentOut Cancellation' THEN
            CASE SUBSTRING(vPayment_Line_Split.AMOUNT_SPLT,1,34)
               WHEN 'Superannuation Redirection to Fund' THEN
                  '05'
               ELSE
                 CASE SUBSTRING(vPayment_Line_Split.AMOUNT_SPLT,1,27) 
                  WHEN 'SIS Act Redirection To Fund' THEN
                  '05'
                 ELSE '04'
                 END
            END
          END     
         ,TOLClaimDetailsForInt.ClaimNumber
         ,BenCase.CaseNumber
         ,BenCaseType.Name
         ,vPayment_Line_Split.AMOUNT_SPLT
         ,TOLPaymentEventInterface.PaymentType
         ,TOLPaymentEventInterface.EventType
         ,TOLPaymentEventInterface.TransStatusDa
         ,PayFreq.Name
         ,TOLPaymentEventInterface.PaymentMethod
         ,TOLPaymentEventInterface.Amount_MonAmt
         ,TOLPaymentEventInterface.PayeeFullName
         ,TOLExternalInvestmentAccount.AccountName
         ,TOLPaymentEventInterface.PayeeBankSort
         ,TOLPaymentEventInterface.PayeeAccountN
         ,TOLPaymentEventInterface.PayeeBankCode
         ,TOLPaymentEventInterface.PayeeBankInst
         ,TOLPaymentEventInterface.TransactionSt
         ,TOLPaymentEventInterface.TransStatusDa
         ,TOLPaymentEventInterface.TransactionNo
         ,TOLPaymentOutEvent.I
         ,TOLPaymentEventInterface.I
         ,TOLPaymentEventInterface.extDueAmtDetails
         ,TOLPaymentEventInterface.Status
         ,TOLPaymentEventInterface.StatusEffecti
         ,CASE WHEN TOLPaymentEventInterface.TransactionSt LIKE '%FAIL%' THEN
               TOLPaymentEventInterface.StatusReason
            ELSE
               NULL
          END
         ,POEStatus.Name
               ,TOLPaymentEventInterface.I 
                ,vODSContractDetails.SourceSystem 
         ,TOLPaymentEventInterface.LASTUPDATEDATE
         ,TOLPaymentOutEvent.LASTUPDATEDATE
         ,TOLPaymentEventInterface.C
         ,TOLPaymentEventInterface.I
         ,TOLPaymentEventInterface.ExtractionDat
         ,TOLPaymentEventInterface.PayeeCustomer
         ,TOCPerson.NatInsNo
                             

--
-- End SQL
--
--
);
GO



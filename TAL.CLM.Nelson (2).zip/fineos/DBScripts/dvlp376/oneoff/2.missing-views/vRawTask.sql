USE [GEMINISVP1VIEWS]
GO

/****** Object:  View [dbo].[vRawTask]    Script Date: 28/09/2022 9:48:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vRawTask] AS (
--
-- Insert the SQL here
--
SELECT TOCTask.I                                         AS Task_I
      ,TOCTask.CaseDisplayNa                             AS BenefitCase
      ,TOCTask.Party                                     AS Payee
      ,TOCTaskType.Name                                  AS TaskName
      ,vLMTaskCaseReport.ResultingFromCase               AS Case_I
      ,TOCTask.Reason                                    AS TaskReason
      ,TOCTask.Status
      ,TOCTask.I_OSUSER_PWF                              AS AssignedToUserId
      ,TOCTask.I_OSUSER_PWC                              AS CreatedByUserId
      ,TOCTask.I_indepartmen                             AS Group_I
      ,TOCRole.Name                                      AS RoleName
      ,TOCTask.TargetDate
      ,TOCTask.DateClosed                                AS ClosedDate
      ,TOCTask.CreationDate
      ,TOCTask.DatePutOnHold
      ,TOCTask.OnHoldReason
      ,TOCTask.OnHoldUntil
      ,TOCTask.I_OnHoldUser                              AS OnHoldUser_I
      ,vLMTaskCaseReport.ExceededWorkTime                AS ExceededWorkTime
      ,vLMTaskCaseReport.HandlerRole                     AS HandlerRole
      ,vLMTaskCaseReport.LatestAssignedDateForTask       AS LatestAssignedDateForTask
      ,vLMTaskCaseReport.LatestAssignedDepartmentForTask AS LatestAssignedDepartmentForTask
      ,TOCTaskType.SLAUnits
      ,TOCTaskType.DayType
      ,TOCServiceLevel.WorkUnits                         AS WorkUnits
      ,TOCTask.Description                               AS Description
      ,TOCRole.I_Department                              AS Department_I
      ,TOCTask.I_OCPRSTVT_CreatedByStep                  AS ProcessStepVisit_I
      ,TOCTask.StartDate                                 AS StartDate
      ,TOCTask.OriginalTarge                             AS OriginalTargetDate
      ,CASE
         WHEN TOCTask.LASTUPDATEDATE > TOCTaskType.LASTUPDATEDATE AND
              TOCTask.LASTUPDATEDATE > COALESCE(TOCServiceLevel.LASTUPDATEDATE,0) AND
              TOCTask.LASTUPDATEDATE > COALESCE(TOCRole.LASTUPDATEDATE,0) THEN
            TOCTask.LASTUPDATEDATE
         WHEN TOCTaskType.LASTUPDATEDATE > COALESCE(TOCServiceLevel.LASTUPDATEDATE,0) AND
              TOCTaskType.LASTUPDATEDATE > COALESCE(TOCRole.LASTUPDATEDATE,0) THEN
            TOCTaskType.LASTUPDATEDATE
         WHEN COALESCE(TOCServiceLevel.LASTUPDATEDATE,0) > COALESCE(TOCRole.LASTUPDATEDATE,0) THEN
            TOCServiceLevel.LASTUPDATEDATE
         ELSE
            TOCRole.LASTUPDATEDATE
       END                                               LastUpdateDate
  FROM           GEMINISVP1APP.dbo.TOCTask
INNER JOIN      GEMINISVP1APP.dbo.TOCTaskType                 ON  TOCTaskType.C             = TOCTask.C_OCTASKTY_Tasks
                                                            AND TOCTaskType.I             = TOCTask.I_OCTASKTY_Tasks
LEFT OUTER JOIN GEMINISVP1APP.dbo.vLMTaskCaseReport           ON  vLMTaskCaseReport.TaskId  = TOCTask.I
LEFT OUTER JOIN GEMINISVP1APP.dbo.TOCServiceLevel             ON  TOCServiceLevel.C         = TOCTaskType.C_OCSERLEV_DefaultServic
                                                            AND TOCServiceLevel.I         = TOCTaskType.I_OCSERLEV_DefaultServic
LEFT OUTER JOIN GEMINISVP1APP.dbo.TOCRole                     ON  TOCRole.C                 = TOCTask.C_OCROLE_Activities
                                                            AND TOCRole.I                 = TOCTask.I_OCROLE_Activities
--
-- End SQL
--
);
GO



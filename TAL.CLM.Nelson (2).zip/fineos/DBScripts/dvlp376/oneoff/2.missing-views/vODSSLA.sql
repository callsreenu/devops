USE [GEMINISVP1VIEWS]
GO

/****** Object:  View [dbo].[vODSSLA]    Script Date: 28/09/2022 9:41:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vODSSLA] AS (
--
-- Insert the SQL here
--
SELECT TOCTask.I                                         TaskId
      ,TOCTaskType.Name                                  TaskTypeName
      ,TStatus.Name                                      TaskStatus
      ,COALESCE(ca.CaseNumber,ca2.CaseNumber)            CaseNumber
      ,COALESCE(ct.Name,ct2.Name)                        CaseTypeName
      ,toctask.I_OSUSER_PWF                              UserId
      ,TOCTask.i_indepartmen                             InDepartment
      ,TOCRole.Name                                      RoleName
      ,TOCTask.TargetDate
      ,TOCTask.DateClosed                                ClosedDate
      ,TOCTask.CreationDate
      ,TOCTask.DatePutOnHold
      ,TOCTask.OnHoldReason
      ,TOCTask.OnHoldUntil
      ,TOCTask.I_OnHoldUser                              OnHoldUser
      ,vLMTaskCaseReport.ExceededWorkTime
      ,vLMTaskCaseReport.HandlerRole
      ,vLMTaskCaseReport.LatestAssignedDateForTask
      ,vLMTaskCaseReport.LatestAssignedDepartmentForTask
      ,SLAUnits.Name                                     SLAUnits
      ,DayType.Name                                      DayType
      ,TOCServiceLevel.WorkUnits                         WorkUnits
      ,TOCTask.LASTUPDATEDATE                            LastUpdateDate
      ,TOCTask.Reason                                    TaskReason
      ,TOCTask.I_OSUSER_PWC                              CreatedUserId
      ,TOCTask.Description                               Description
  FROM          GEMINISVP1APP.dbo.TOCTask
LEFT OUTER JOIN GEMINISVP1APP.dbo.TOCProcessInstance pi       ON  pi.I                      = TOCTask.I_OCACTVTY_ChildActiviti
LEFT OUTER JOIN GEMINISVP1APP.dbo.TOCCase            ca       ON  ca.I                      = pi.I_OCCASE_ResultingFrom
LEFT OUTER JOIN GEMINISVP1APP.dbo.TOCCaseType        ct       ON  ct.I                      = ca.I_OCCASTYP_Cases
LEFT OUTER JOIN GEMINISVP1APP.dbo.TOCProcessInstance pi2      ON  pi2.I                     = pi.I_OCACTVTY_ChildActiviti
LEFT OUTER JOIN GEMINISVP1APP.dbo.TOCCase            ca2      ON  ca2.I                     = pi2.I_OCCASE_ResultingFrom
LEFT OUTER JOIN GEMINISVP1APP.dbo.TOCCasetype        ct2      ON  ct2.I                     = ca2.I_OCCASTYP_Cases
LEFT OUTER JOIN GEMINISVP1APP.dbo.vLMTaskCaseReport           ON  vLMTaskCaseReport.TaskId  = TOCTask.I
INNER JOIN      GEMINISVP1APP.dbo.TOCTaskType                 ON  TOCTaskType.C             = TOCTask.C_OCTASKTY_Tasks
                                                            AND TOCTaskType.I             = TOCTask.I_OCTASKTY_Tasks
LEFT OUTER JOIN GEMINISVP1APP.dbo.TOCServiceLevel             ON  TOCServiceLevel.C         = TOCTaskType.C_OCSERLEV_DefaultServic
                                                            AND TOCServiceLevel.I         = TOCTaskType.I_OCSERLEV_DefaultServic
INNER JOIN      GEMINISVP1APP.dbo.TODomainInstance   TStatus  ON  TStatus.I                 = TOCTask.Status
INNER JOIN      GEMINISVP1APP.dbo.TODomainInstance   SLAUnits ON  SLAUnits.I                = TOCTaskType.SLAUnits
INNER JOIN      GEMINISVP1APP.dbo.TODomainInstance   DayType  ON  DayType.I                 = TOCTaskType.DayType
LEFT OUTER JOIN GEMINISVP1APP.dbo.TOCRole                     ON  TOCRole.C                 = TOCTask.C_OCROLE_Activities
                                                            AND TOCRole.I                 = TOCTask.I_OCROLE_Activities
--
-- End SQL
--
);
GO



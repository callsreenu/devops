USE [GEMINISVP1VIEWS]
GO

/****** Object:  View [dbo].[vBankingMaster]    Script Date: 28/09/2022 9:44:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vBankingMaster] AS (
--
-- Insert the SQL here
--
SELECT PEI.C,
       PEI.I,
       PEI.PaymentPostCo,
       PEI.Amount_MonAmt,
       PEI.Currency,
       PEI.PayeeAccountN,
       PEI.PayeeBankSort,
       PEI.PayeeFullName,
       PEI.PaymentAdd1,
       PEI.PaymentAdd2,
       PEI.PaymentAdd3,
       PEI.PaymentAdd4,
       PEI.PaymentAdd5,
       PEI.PaymentAdd6,
       PEI.PaymentPremis,      
       PEI.PaymentMethod,
       CASE WHEN PEI.PaymentType IN ('Service','Expense') THEN
            (SELECT TOP 1
                    TOLPurchaseDetailsForInt.InvoiceDate
             FROM   GEMINISVP1APP.dbo.TOLPaymentLineGrpForDueEvent
                   ,GEMINISVP1APP.dbo.TOLPurchaseDetailsForInt
             WHERE  TOLPaymentLineGrpForDueEvent.C_PLNGRCS_PaymentLineGr  = tolpaymentlinegrpforcase.C
             AND    TOLPaymentLineGrpForDueEvent.I_PLNGRCS_PaymentLineGr  = tolpaymentlinegrpforcase.I
             AND    TOLPaymentLineGrpForDueEvent.C_PYDDTLPI_PaymentDueDet = TOLPurchaseDetailsForInt.C
             AND    TOLPaymentLineGrpForDueEvent.I_PYDDTLPI_PaymentDueDet = TOLPurchaseDetailsForInt.I)
       ELSE
            PEI.PaymentDate
       END                                            AS PaymentDate,
       TOCCase.CaseNumber                             AS ClaimNumber,
       PEI.ExtractionDat,
       CASE WHEN PEI.PaymentType IN ('Service','Expense') THEN
            (SELECT TOP 1
                    TOLPurchaseDetailsForInt.ReferenceNumb
             FROM   GEMINISVP1APP.dbo.TOLPaymentLineGrpForDueEvent
                   ,GEMINISVP1APP.dbo.TOLPurchaseDetailsForInt
             WHERE  TOLPaymentLineGrpForDueEvent.C_PLNGRCS_PaymentLineGr  = tolpaymentlinegrpforcase.C
             AND    TOLPaymentLineGrpForDueEvent.I_PLNGRCS_PaymentLineGr  = tolpaymentlinegrpforcase.I
             AND    TOLPaymentLineGrpForDueEvent.C_PYDDTLPI_PaymentDueDet = TOLPurchaseDetailsForInt.C
             AND    TOLPaymentLineGrpForDueEvent.I_PYDDTLPI_PaymentDueDet = TOLPurchaseDetailsForInt.I)
       ELSE
             PEI.extDueAmtDetails
       END                                            AS extDueAmtDetails,
       PEI.NametoPrintOn,
       BenRight.Name                                  AS BenefitRightT,
       (SELECT TOP 1 I 
        FROM   GEMINISVP1APP.dbo.vosuser
        WHERE  UserID = 'WPACPAYMENTSPROCESS')      AS I_OSUSER_PWC,
       TOCProcessInstance.I_InDepartmen,
       TOCProcessInstance.I_OSUSER_PWF,
       (SELECT TOP 1 I 
        FROM   GEMINISVP1APP.dbo.TOCTaskType
        WHERE  Name = 'Missing Payment Data')       AS I_OCTASK_MISSING_DATA,
       (SELECT TOP 1 I
        FROM   GEMINISVP1APP.dbo.TOCTaskType
        WHERE  Name = 'Failed Payment Processing')  AS I_OCTASK_FAILED_DATA,
       Missing_Data.WorkUnits_Miss,
       Missing_Data.SLAUnits_Miss,
       Missing_Data.DayType_Miss,
       Failed_Payment.WorkUnits_Fail,
       Failed_Payment.SLAUnits_Fail,
       Failed_Payment.DayType_Fail,
       TOCProcessInstance.i                           AS I_OCACTVTY_ChildActiviti,
       party.C                                        AS C_OCTSKSUB_Tasks,
       party.I                                        AS I_OCTSKSUB_Tasks,
       party.partyname                                AS SubjectRefere,
       PEI.PaymentType,
       CASE WHEN vODSContractDetails.SourceSystem = 'Cloas' THEN
          CASE WHEN PEI.PaymentType IN ('Service','Expense') THEN
             'R' + LEFT(CONVERT(VARCHAR,PEI.I) + '          ',10) + LEFT(RIGHT((SELECT TOP 1 
                                                                                           TOLPurchaseDetailsForInt.ReferenceNumb
                                                                                    FROM   GEMINISVP1APP.dbo.TOLPaymentLineGrpForDueEvent
                                                                                          ,GEMINISVP1APP.dbo.TOLPurchaseDetailsForInt
                                                                                    WHERE  TOLPaymentLineGrpForDueEvent.C_PLNGRCS_PaymentLineGr  = tolpaymentlinegrpforcase.C
                                                                                    AND    TOLPaymentLineGrpForDueEvent.I_PLNGRCS_PaymentLineGr  = tolpaymentlinegrpforcase.I
                                                                                    AND    TOLPaymentLineGrpForDueEvent.C_PYDDTLPI_PaymentDueDet = TOLPurchaseDetailsForInt.C
                                                                                    AND    TOLPaymentLineGrpForDueEvent.I_PYDDTLPI_PaymentDueDet = TOLPurchaseDetailsForInt.I
                                                                                    ),8)+'        ',8)
          ELSE
             CASE WHEN PEI.PayeeFullName IN (SELECT Org.OrganisationName
                                             FROM   GEMINISVP1VIEWS.dbo.vODSClaimPartyRole    CPR
                                                   ,GEMINISVP1VIEWS.dbo.vODSOrganisation      Org
                                             WHERE  1                     = 1
                                             AND    CPR.Role              IN ('Policy Owner')
                                             AND    CPR.Type              = 'ORGANISATION'
                                             AND    Org.I                 = CPR.I
                                             UNION
                                             SELECT Org.OrganisationName
                                             FROM   GEMINISVP1VIEWS.dbo.vODSBenefitPartyRole  CPR
                                                   ,GEMINISVP1VIEWS.dbo.vODSOrganisation      Org
                                             WHERE  1                     = 1
                                             AND    CPR.Role              IN ('Group Payee')
                                             AND    CPR.Type              = 'ORGANISATION'
                                             AND    Org.I                 = CPR.I) THEN
                 CASE WHEN ISNULL(vODSContractDetails.extPlatformAccountNumber, '')   <> '' THEN
                    vODSContractDetails.extPlatformAccountNumber + '-R' + RIGHT(CONVERT(varchar,Pei.I),3)
                 ELSE
                    vODSContractDetails.PolicyReferenceNumber + '-R' + RIGHT(CONVERT(varchar,Pei.I),3)
                 END
             ELSE
               'CLAIM-R' + CONVERT(VARCHAR,PEI.I)
             END
          END
       ELSE
          CASE WHEN PEI.PaymentType IN ('Service','Expense') THEN
             'G' + LEFT(CONVERT(VARCHAR,PEI.I) + '          ',10) + LEFT(RIGHT((SELECT TOP 1 
                                                                                           TOLPurchaseDetailsForInt.ReferenceNumb
                                                                                    FROM   GEMINISVP1APP.dbo.TOLPaymentLineGrpForDueEvent
                                                                                          ,GEMINISVP1APP.dbo.TOLPurchaseDetailsForInt
                                                                                    WHERE  TOLPaymentLineGrpForDueEvent.C_PLNGRCS_PaymentLineGr  = tolpaymentlinegrpforcase.C
                                                                                    AND    TOLPaymentLineGrpForDueEvent.I_PLNGRCS_PaymentLineGr  = tolpaymentlinegrpforcase.I
                                                                                    AND    TOLPaymentLineGrpForDueEvent.C_PYDDTLPI_PaymentDueDet = TOLPurchaseDetailsForInt.C
                                                                                    AND    TOLPaymentLineGrpForDueEvent.I_PYDDTLPI_PaymentDueDet = TOLPurchaseDetailsForInt.I
                                                                                    ),8)+'        ',8)
          ELSE
             CASE WHEN PEI.PayeeFullName IN (SELECT Org.OrganisationName
                                             FROM   GEMINISVP1VIEWS.dbo.vODSClaimPartyRole    CPR
                                                   ,GEMINISVP1VIEWS.dbo.vODSOrganisation      Org
                                             WHERE  1                     = 1
                                             AND    CPR.Role              IN ('Policy Owner')
                                             AND    CPR.Type              = 'ORGANISATION'
                                             AND    Org.I                 = CPR.I
                                             UNION
                                             SELECT Org.OrganisationName
                                             FROM   GEMINISVP1VIEWS.dbo.vODSBenefitPartyRole  CPR
                                                   ,GEMINISVP1VIEWS.dbo.vODSOrganisation      Org
                                             WHERE  1                     = 1
                                             AND    CPR.Role              IN ('Group Payee')
                                             AND    CPR.Type              = 'ORGANISATION'
                                             AND    Org.I                 = CPR.I) THEN        
                 vODSContractDetails.PolicyReferenceNumber + '-G' + RIGHT(CONVERT(varchar,Pei.I),3)
             ELSE
               'CLAIM-G' + CONVERT(VARCHAR,PEI.I)
             END
          END
       END                                                         AS LodgementReference
  FROM       GEMINISVP1APP.dbo.TOLPaymentEventInterface              PEI
  INNER JOIN GEMINISVP1APP.dbo.TOLPaymentLineGrpForCase              ON  TOLPaymentLineGrpForCase.C_PYMNTEIF_PaymentLineGr       = PEI.C 
                                                                   AND TOLPaymentLineGrpForCase.I_PYMNTEIF_PaymentLineGr       = PEI.I
  INNER JOIN GEMINISVP1APP.dbo.TOLClaimDetailsForInt                 ON  TOLClaimDetailsForInt.C                                 = TOLPaymentLineGrpForCase.C_CASDTLPI_CaseDetailsFo 
                                                                   AND TOLClaimDetailsForInt.I                                 = TOLPaymentLineGrpForCase.I_CASDTLPI_CaseDetailsFo
  INNER JOIN GEMINISVP1APP.dbo.TOCCase                               ON  TOCCase.C                                               = TOLPaymentLineGrpForCase.C_OCCASE_PaymentLineGr 
                                                                   AND TOCCase.I                                               = TOLPaymentLineGrpForCase.I_OCCASE_PaymentLineGr
  INNER JOIN GEMINISVP1APP.dbo.TOLBenefit                            ON  TOLBenefit.C_OCCASE_BenefitCase                         = TOCCase.C 
                                                                   AND TOLBenefit.I_OCCASE_BenefitCase                         = TOCCase.I
  INNER JOIN GEMINISVP1VIEWS.dbo.vODSContractDetails                 ON  vODSContractDetails.BenefitNumber                       = TOCCase.CaseNumber
  LEFT OUTER JOIN GEMINISVP1APP.dbo.TOLRegularPaymentBenefitRight    ON  TOLRegularPaymentBenefitRight.I_BNFT_Benefit            = TOLBenefit.I
                                                                   AND TOLRegularPaymentBenefitRight.C_BNFT_Benefit            = TOLBenefit.C
  LEFT OUTER JOIN GEMINISVP1APP.dbo.TOLLumpsumBenefitRight           ON  TOLLumpsumBenefitRight.I_BNFT_Benefit                   = TOLBenefit.I
                                                                   AND TOLLumpsumBenefitRight.C_BNFT_Benefit                   = TOLBenefit.C
  INNER JOIN GEMINISVP1APP.dbo.TODomainInstance     BenRight         ON  BenRight.I                                              = COALESCE(TOLRegularPaymentBenefitRight.BenefitRightT,
                                                                                                                                          TOLLumpsumBenefitRight.BenefitRightT)
                                                                   AND BenRight.I_ODOM_Insts                                   = 2170
  INNER JOIN GEMINISVP1APP.dbo.TOCProcessInstance                    ON  TOCProcessInstance.C_OCCASE_ResultingFrom               = TOCCase.C 
                                                                   AND TOCProcessInstance.I_OCCASE_ResultingFrom               = TOCCase.I
  LEFT OUTER JOIN (SELECT TOP 1 
                          SL.Workunits      AS WorkUnits_Miss,
                          Units.Name        AS SLAUnits_Miss,
                          Daytype.Name      AS DayType_Miss
                   FROM       GEMINISVP1APP.dbo.TOCTaskType       TT
                   INNER JOIN GEMINISVP1APP.dbo.TOCServiceLevel   SL         ON  SL.C      = TT.C_OCSERLEV_DefaultServic 
                                                                           AND SL.I      = TT.I_OCSERLEV_DefaultServic
                   INNER JOIN GEMINISVP1APP.dbo.TODomainInstance  Units      ON  Units.I   = TT.SLAUnits
                   INNER JOIN GEMINISVP1APP.dbo.TODomainInstance  Daytype    ON  Daytype.I = TT.DayType
                   WHERE TT.Name                                                         = 'Missing Payment Data') Missing_Data ON 1=1
  LEFT OUTER JOIN (SELECT TOP 1 
                          SL.Workunits      AS WorkUnits_Fail,
                          Units.Name        AS SLAUnits_Fail,
                          Daytype.Name      AS DayType_Fail
                   FROM   GEMINISVP1APP.dbo.TOCTaskType           TT
                   INNER JOIN GEMINISVP1APP.dbo.TOCServiceLevel   SL         ON SL.C       = TT.C_OCSERLEV_DefaultServic 
                                                                           AND SL.I      = TT.I_OCSERLEV_DefaultServic
                   INNER JOIN GEMINISVP1APP.dbo.TODomainInstance  Units      ON Units.I    = TT.SLAUnits
                   INNER JOIN GEMINISVP1APP.dbo.TODomainInstance  Daytype    ON Daytype.I  = TT.DayType
                   WHERE TT.Name                                                         = 'Failed Payment Processing') Failed_Payment ON 1=1
  INNER JOIN      (SELECT c,i,customerno, firstnames + ' ' + lastname  AS partyname
                   FROM   GEMINISVP1APP.dbo.tocperson
                   UNION
                   SELECT c,i,customerno,name AS partyname
                   FROM   GEMINISVP1APP.dbo.tocorganisation)     party       ON party.CustomerNo = PEI.PayeeCustomer
  WHERE PEI.ExtractionDat      IS NULL
    AND PEI.Status             = 'PendingActive'
    AND PEI.EventType          = 'PaymentOut'
    AND PEI.PayeeCustomer      <> 'ATO'
    AND PEI.PayeeFullName      <> 'CLOAS Manual Payment'
    AND PEI.PayeeFullName      <> 'Australian Taxation Office'
--
-- End SQL
--
);
GO



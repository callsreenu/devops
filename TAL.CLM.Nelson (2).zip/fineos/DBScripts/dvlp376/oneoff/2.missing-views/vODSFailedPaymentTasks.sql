USE [GEMINISVP1VIEWS]
GO

/****** Object:  View [dbo].[vODSFailedPaymentTasks]    Script Date: 28/09/2022 9:43:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vODSFailedPaymentTasks] AS (
--
-- Insert the SQL here
--
SELECT    TOCTask.CaseDisplayNa                                AS Benefit_Case
         ,TOCTask.Party                                        AS Payee
         ,TOCTaskType.name                                     AS Task_Name
         ,TOCTask.Description                                  AS Payment_Error
         ,TOSGroup.Name                                        AS Department_Task_Assigned_To
         ,ass.name                                             AS User_Task_Assigned_To
         ,TOCTask.CreationDate                                 AS Creation_Date
         ,cre.name                                             AS Task_Created_By
         ,TOCTask.I
         ,TOCTASK.LASTUPDATEDATE
FROM              GEMINISVP1APP.dbo.TOCTask
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOCTaskType ON TOCTaskType.i = TOCTask.I_OCTASKTY_Tasks
LEFT OUTER JOIN   GEMINISVP1SEC.dbo.TOSGroup    ON TOSGroup.i    = TOCTask.I_InDepartmen
LEFT OUTER JOIN   GEMINISVP1SEC.dbo.TOSuser ass ON ass.i         = TOCTask.I_OSUSER_PWF
LEFT OUTER JOIN   GEMINISVP1SEC.dbo.TOSuser cre ON cre.i         = TOCTask.I_OSUSER_PWC
WHERE    TOCTask.I_OSUSER_PWC  = (  SELECT   TOP 1 vosuser.I 
                                    FROM     GEMINISVP1APP.dbo.vosuser
                                    WHERE    vosuser.UserID = 'WPACPAYMENTSPROCESS')
AND      TOCTask.status = 928000
--
-- End SQL
--
);
GO



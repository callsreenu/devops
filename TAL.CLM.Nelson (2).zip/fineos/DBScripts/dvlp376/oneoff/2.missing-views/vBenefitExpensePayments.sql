USE [GEMINISVP1VIEWS]
GO

/****** Object:  View [dbo].[vBenefitExpensePayments]    Script Date: 28/09/2022 9:45:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vBenefitExpensePayments] AS (
--
-- Insert the SQL here
-- 
SELECT   CASE tolpaymenteventinterface.EventType
            WHEN 'PaymentOut'              THEN '06'
            WHEN 'PaymentOut Cancellation' THEN '07'
         END                                          AS Transaction_Type            -- FSD-47 - transaction type
         ,TOLClaimDetailsForInt.ClaimNumber           AS Claim_Number                 -- FSD-48 - claim number
         ,(case when vODSContractDetails.SourceSystem <> 'Cloas' 
				then TOLClaimDetailsForInt.ClaimNumber
				else BenCase.CaseNumber
		   end)	   						              AS Sub_Case_Number              -- FSD-49 - sub case number
         ,BenCaseType.Name                            AS Sub_Case_Type
         ,CreateUser.Name                             AS Payment_Creator              -- FSD-50 - payment creator
         ,MAX(TOLDueEvent.LASTUPDATEDATE)             AS Payment_Creation_Date        -- FSD-51 - payment creation date
         ,AuthUser.Name                               AS Payment_Authoriser           -- FSD-52 - payment authoriser
         ,TOLAllocationInstruction.LASTUPDATEDATE     AS Payment_Authorised_Date      -- FSD-53 - payment authorisation date
         ,TOLPaymentEventInterface.TransStatusDa      AS Date_Of_Payment              -- FSD-54 - Date of payment
         ,TOLPaymentEventInterface.PaymentMethod      AS Payment_Method               -- FSD-55 - Payment method
         ,TOLPaymentEventInterface.Amount_MonAmt      AS Payment_Amount               -- FSD-56 - Payment amount
         ,TOLPaymentEventInterface.PayeeFullName      AS Payee_Name                   -- FSD-57 - Payee name
         ,TOLExternalInvestmentAccount.AccountName    AS Payee_Bank_Account_Name      -- FSD-58 - Payee bank account name
         ,TOLPaymentEventInterface.PayeeBankSort      AS Payee_BSB                    -- FSD-59 - Payee BSB
         ,TOLPaymentEventInterface.PayeeAccountN      AS Payee_Bank_Account_Number    -- FSD-60 - Payee bank account number
         ,TOLPaymentEventInterface.PayeeBankCode      AS Payee_Bank_Code              -- FSD-61 - Payee bank code
         ,TOLPaymentEventInterface.PayeeBankInst      AS Payee_Bank_Institution_Name  -- FSD-62 - Payee bank institution name
         ,TOLPaymentEventInterface.TransactionSt      AS Transaction_Status           -- FSD-63 - Transaction status
         ,TOLPaymentEventInterface.TransStatusDa      AS Transaction_Status_Date      -- FSD-64 - Transaction status date
         ,TOLPaymentEventInterface.TransactionNo      AS Payment_Reference            -- FSD-65 - Payment reference / transaction number
         ,TOLPaymentOutEvent.I                        AS Payment_Event_Id             -- FSD-66 - Payment event id - unique identifier from POE table
         ,TOLPaymentEventInterface.I                  AS Payment_Transaction_Id       -- FSD-67 - Payment transaction id - unique identifier from POI table
         ,TOLPurchaseDetailsForInt.ReferenceNumb      AS Invoice_Reference_Number     -- FSD-68 - Invoice Reference Number
         ,COALESCE(TOLPurchaseDetailsForInt.ServiceCode,TOLPaymentEventInterface.extDueAmtDetails)        AS Claim_Expense_Code           -- FSD-69 - Claim Expense Code
         ,TOLPaymentEventInterface.Status             AS Payment_Status               -- FSD-70 - Payment status
         ,TOLPaymentEventInterface.StatusEffecti      AS Payment_Status_Date          --        - not defined as an extracted column
         ,CASE WHEN TOLPaymentEventInterface.TransactionSt LIKE '%FAIL%' THEN
               TOLPaymentEventInterface.StatusReason
            ELSE
               NULL
          END                                         AS Payment_Status_Reason        -- FSD-71 - Payment status reason
         ,POEStatus.Name                              AS Payment_Out_Event_Status     --        - not defined as an extracted column
         ,vODSContractDetails.SourceSystem			  AS SourceSystem
		 ,TOLPaymentEventInterface.LASTUPDATEDATE     AS PEI_Last_Update_Date         --        - not defined as an extracted column
         ,TOLPaymentOutEvent.LASTUPDATEDATE           AS POE_Last_Update_Date         --        - not defined as an extracted column
         ,TOLPaymentEventInterface.C                  AS C                            --        - not defined as an extracted column
         ,TOLPaymentEventInterface.I                  AS I                            --        - not defined as an extracted column
 FROM              GEMINISVP1APP.dbo.TOLPaymentEventInterface
 INNER JOIN        GEMINISVP1APP.dbo.TOLPaymentLineGrpForCase          ON TOLPaymentLineGrpForCase.I_PYMNTEIF_PaymentLineGr        = TOLPaymentEventInterface.I
                                                                     AND TOLPaymentLineGrpForCase.C_PYMNTEIF_PaymentLineGr       = TOLPaymentEventInterface.C
 INNER JOIN        GEMINISVP1APP.dbo.TOLClaimDetailsForInt             ON TOLPaymentLineGrpForCase.I_CASDTLPI_CaseDetailsFo        = TOLClaimDetailsForInt.I
                                                                     AND TOLPaymentLineGrpForCase.C_CASDTLPI_CaseDetailsFo       = TOLClaimDetailsForInt.C
 INNER JOIN        GEMINISVP1APP.dbo.TOCCase BenCase                   ON TOLPaymentLineGrpForCase.I_OCCASE_PaymentLineGr          = BenCase.I
                                                                     AND TOLPaymentLineGrpForCase.C_OCCASE_PaymentLineGr         = BenCase.C
 INNER JOIN        GEMINISVP1APP.dbo.TOCCaseType BenCaseType           ON BenCaseType.C                                            = BenCase.C_OCCASTYP_Cases
                                                                     AND BenCaseType.I                                           = BenCase.I_OCCASTYP_Cases
 INNER JOIN        GEMINISVP1APP.dbo.TOLPaymentOutEvent                ON  (TOLPaymentOutEvent.I_PYMNTEIF_PaymentEventI            = TOLPaymentEventInterface.I
                                                                     AND TOLPaymentOutEvent.C_PYMNTEIF_PaymentEventI             = TOLPaymentEventInterface.C)
                                                                     OR  (TOLPaymentOutEvent.I_PYMNTEIF_CancellationP            = TOLPaymentEventInterface.I
                                                                     AND  TOLPaymentOutEvent.C_PYMNTEIF_CancellationP            = TOLPaymentEventInterface.C)
 LEFT OUTER JOIN   GEMINISVP1APP.dbo.RPYMNTVNTALLCTNINAllocationIns    ON TOLPaymentOutEvent.C                                     = RPYMNTVNTALLCTNINAllocationIns.C_From
                                                                     AND TOLPaymentOutEvent.I                                    = RPYMNTVNTALLCTNINAllocationIns.I_from
 LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLAllocationInstruction          ON TOLAllocationInstruction.C                               = RPYMNTVNTALLCTNINAllocationIns.C_To
                                                                     AND TOLAllocationInstruction.I                              = RPYMNTVNTALLCTNINAllocationIns.I_To
 LEFT OUTER JOIN   GEMINISVP1APP.dbo.VOSUser CreateUser                ON TOLAllocationInstruction.C_OSUser_Adde                   = CreateUser.C
                                                                     AND TOLAllocationInstruction.I_OSUser_Adde                  = CreateUser.I
 INNER JOIN        GEMINISVP1APP.dbo.VOSUser AuthUser                  ON TOLAllocationInstruction.C_OSUser_Acti                   = AuthUser.C
                                                                     AND TOLAllocationInstruction.I_OSUser_Acti                  = AuthUser.I
 INNER JOIN        GEMINISVP1APP.dbo.TOLBenefit                        ON TOLBenefit.C_OCCASE_BenefitCase                          = BenCase.C
                                                                     AND TOLBenefit.I_OCCASE_BenefitCase                         = BenCase.I
 LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLDueEvent                       ON TOLDueEvent.C_BNFT_BenefitDues                           = TOLBenefit.C
                                                                     AND TOLDueEvent.I_BNFT_BenefitDues                          = TOLBenefit.I
                                                                     AND TOLDueEvent.C                                           = TOLAllocationInstruction.C_ABSDE_PaymentAlloca
                                                                     AND TOLDueEvent.I                                           = TOLAllocationInstruction.I_ABSDE_PaymentAlloca
 LEFT OUTER JOIN        GEMINISVP1APP.dbo.TOLPaymentLineGrpForDueEvent      ON TOLPaymentLineGrpForDueEvent.C_PLNGRCS_PaymentLineGr     = tolpaymentlinegrpforcase.C
                                                                     AND TOLPaymentLineGrpForDueEvent.I_PLNGRCS_PaymentLineGr    = tolpaymentlinegrpforcase.I
 LEFT OUTER JOIN        GEMINISVP1APP.dbo.TOLPurchaseDetailsForInt          ON TOLPaymentLineGrpForDueEvent.C_PYDDTLPI_PaymentDueDet    = TOLPurchaseDetailsForInt.C
                                                                     AND TOLPaymentLineGrpForDueEvent.I_PYDDTLPI_PaymentDueDet   = TOLPurchaseDetailsForInt.I
 LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLRegularPaymentBenefitRight     ON C_BNFT_Benefit                                           = TOLBenefit.C
                                                                     AND I_BNFT_Benefit                                          = TOLBenefit.I
 LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLRegularPremiumComponent        ON TOLRegularPremiumComponent.C                             = TOLRegularPaymentBenefitRight.C_RGLPRMCP_PaymentDetail
                                                                     AND TOLRegularPremiumComponent.I                            = TOLRegularPaymentBenefitRight.I_RGLPRMCP_PaymentDetail
 LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLPaymentFrequencyHistory        ON TOLPaymentFrequencyHistory.C_RGLPRMCP_PaymentFreque      = TOLRegularPremiumComponent.C
                                                                     AND TOLPaymentFrequencyHistory.I_RGLPRMCP_PaymentFreque     = TOLRegularPremiumComponent.I
 INNER JOIN        GEMINISVP1APP.dbo.TOLPaymentDetails                 ON TOLPaymentOutEvent.C_PYMNTDTL_PaymentEvent               = TOLPaymentDetails.C
                                                                     AND TOLPaymentOutEvent.I_PYMNTDTL_PaymentEvent              = TOLPaymentDetails.I
 LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLExternalInvestmentAccount      ON TOLExternalInvestmentAccount.C                           = TOLPaymentDetails.C_XTRNLNVS_PaymntsAsPaye
                                                                     AND TOLExternalInvestmentAccount.I                          = TOLPaymentDetails.I_XTRNLNVS_PaymntsAsPaye
 LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOLReceiptPaymentEvent            ON TOLReceiptPaymentEvent.C_PYMNTDTL_PaymentEvent           = TOLPaymentDetails.C
                                                                     AND TOLReceiptPaymentEvent.I_PYMNTDTL_PaymentEvent          = TOLPaymentDetails.I
 INNER JOIN        GEMINISVP1APP.dbo.TODomainInstance POEStatus        ON POEStatus.I                                              = TOLPaymentOutEvent.Status
 INNER JOIN        vPayment_Line_Split                               ON vPayment_Line_Split.C                                    = TOLPaymentEventInterface.C
                                                                     AND vPayment_Line_Split.I                                   = TOLPaymentEventInterface.I
                                                                     AND vPayment_Line_Split.claimnumber                         = TOLClaimDetailsForInt.ClaimNumber
 INNER JOIN        GEMINISVP1APP.dbo.TOLClaim							ON TOLClaim.I = TOLBenefit.I_CLM_Benefits
																		AND TOLClaim.C = TOLBenefit.C_CLM_Benefits
 LEFT OUTER JOIN vODSContractDetails								  ON vODSContractDetails.BenefitNumber				         = BenCase.CaseNumber
 WHERE BenCaseType.Name                       IN ( 'Expenses' , 'Service' )
 AND   (
         (      tolpaymenteventinterface.Status        = 'ACTIVE'
               AND   tolpaymenteventinterface.EventType = 'PaymentOut'
         )
       OR
         (      tolpaymenteventinterface.Status        = 'PendingActive'
               AND   tolpaymenteventinterface.EventType = 'PaymentOut Cancellation'
         )
       )
GROUP BY CASE tolpaymenteventinterface.EventType
            WHEN 'PaymentOut'              THEN '06'
            WHEN 'PaymentOut Cancellation' THEN '07'
         END
         ,TOLClaimDetailsForInt.ClaimNumber
         ,BenCase.CaseNumber
         ,BenCaseType.Name
         ,CreateUser.Name
         ,AuthUser.Name
         ,TOLAllocationInstruction.LASTUPDATEDATE
         ,TOLPaymentEventInterface.EventType
         ,TOLPaymentEventInterface.TransStatusDa
         ,TOLPaymentEventInterface.PaymentMethod
         ,TOLPaymentEventInterface.Amount_MonAmt
         ,TOLPaymentEventInterface.PayeeFullName
         ,TOLExternalInvestmentAccount.AccountName
         ,TOLPaymentEventInterface.PayeeBankSort
         ,TOLPaymentEventInterface.PayeeAccountN
         ,TOLPaymentEventInterface.PayeeBankCode
         ,TOLPaymentEventInterface.PayeeBankInst
         ,TOLPaymentEventInterface.TransactionSt
         ,TOLPaymentEventInterface.TransStatusDa
         ,TOLPaymentEventInterface.TransactionNo
         ,TOLPaymentOutEvent.I
         ,tolpaymenteventinterface.I
         ,TOLPurchaseDetailsForInt.ReferenceNumb
         ,COALESCE(TOLPurchaseDetailsForInt.ServiceCode,TOLPaymentEventInterface.extDueAmtDetails)
         ,TOLPaymentEventInterface.Status
         ,TOLPaymentEventInterface.StatusEffecti
         ,TOLPaymentEventInterface.StatusReason
         ,POEStatus.Name
		 ,vODSContractDetails.SourceSystem
         ,TOLPaymentEventInterface.LASTUPDATEDATE
         ,TOLPaymentOutEvent.LASTUPDATEDATE
         ,TOLPaymentEventInterface.C
         ,TOLPaymentEventInterface.I

--
-- End SQL
--
);
GO



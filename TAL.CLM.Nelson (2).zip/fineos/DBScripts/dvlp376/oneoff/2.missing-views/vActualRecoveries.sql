USE [GEMINISVP1VIEWS]
GO

/****** Object:  View [dbo].[vActualRecoveries]    Script Date: 28/09/2022 9:46:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vActualRecoveries] AS (
--
-- Insert the SQL here
-- 
SELECT    DISTINCT
			(CASE WHEN src.Name = 'CLOAS' 
				THEN
				 CASE WHEN RecoveryMethod.Name IN ('Member - Cheque','Member - EFT') 
				      THEN '09'
					  WHEN RecoveryMethod.Name = 'Auto Recovery - Tax from ATO'
					  THEN '12'
					  WHEN RecoveryMethod.Name = 'Direct Recovery - Super Fund'
					  THEN '13'
				 END
				ELSE '09' 
		  END)                                         AS Transaction_Type              -- FSD-72
          ,clmCase.CaseNumber                          AS Claim_Number                  -- FSD-73
          ,CASE WHEN BenType.name = 'Expenses' AND src.Name <> 'CLOAS' THEN
               clmCase.CaseNumber
           ELSE
               benCase.CaseNumber
           END                                         AS Sub_Case_Number               -- FSD-74
          ,TOCProcessInstance.Stage                    AS Overpayment_Status            -- FSD-75
          ,CASE WHEN TOLPaymentEventInterface.PayeeCustomer = 'ATO' THEN
                     'Tax~'+convert(varchar,TOLLocalMoneyAmount.Amount_MonAmt)
                WHEN TOLPaymentEventInterface.PayeeCustomer IN
                        (SELECT TOCPerson.CustomerNo
                         FROM   GEMINISVP1APP.dbo.TOCPartyCaseRole
                         INNER JOIN  GEMINISVP1APP.dbo.TOCCaseTypeRole ON TOCCaseTypeRole.C = TOCPartyCaseRole.C_OCCASETR_ImplementedRo 
                                                                   AND TOCCaseTypeRole.I = TOCPartyCaseRole.i_OCCASETR_ImplementedRo
                         INNER JOIN  GEMINISVP1APP.dbo.TOCPerson       ON TOCPerson.I = TOCPartyCaseRole.I_OCPRTY_PartyCaseRole
                                                                   AND TOCPerson.C = TOCPartyCaseRole.C_OCPRTY_PartyCaseRole
                         WHERE (TOCCaseTypeRole.RoleName = 'Insured'
								OR (TOCCaseTypeRole.RoleName = 'Beneficiary' and Src.Name = 'CLOAS'))
                         AND TOCPartyCaseRole.I_OCCASE_Roles = benCase.I) THEN
						 CASE WHEN Src.Name = 'CLOAS' THEN
						    'Insured/Beneficiary~'+convert(varchar,TOLLocalMoneyAmount.Amount_MonAmt)
						  ELSE
                            'Member~'+convert(varchar,TOLLocalMoneyAmount.Amount_MonAmt)
						END
           ELSE
                     'Super~'+convert(varchar,TOLLocalMoneyAmount.Amount_MonAmt)
           END                                         AS Payment_Amount_Split          -- FSD-76
          ,CAST(NULL AS DECIMAL)                       AS Amount_Overpaid               -- FSD-77
          ,TOLLocalMoneyAmount.Amount_MonAmt           AS Amount_Recovered              -- FSD-78
          ,TOLReceiptPaymentEvent.CreationDate         AS Date_Of_Recovery              -- FSD-79
          ,CAST(NULL AS DATETIME)                      AS Payment_Period_From_Date      -- FSD-80
          ,CAST(NULL AS DATETIME)                      AS Payment_Period_To_Date        -- FSD-81
          ,PayMeth.Name                                AS Recovery_Payment_Method       -- FSD-82
          ,TOLPaymentDetails.CheckName                 AS Cheque_Name                   -- FSD-83
          ,TOLPaymentDetails.CheckNumber               AS Cheque_Number                 -- FSD-84
          ,CAST(NULL AS DECIMAL)                       AS Write_Off_Amount              -- FSD-85
          ,CAST(NULL AS VARCHAR)                       AS Write_Off_CreatedBy           -- FSD-86
          ,CAST(NULL AS DATETIME)                      AS Write_Off_CreatedDate         -- FSD-87
          ,CAST(NULL AS VARCHAR)                       AS Write_Off_AprovedBy           -- FSD-88
          ,CAST(NULL AS DATETIME)                      AS Write_Off_AprovedDate         -- FSD-89
          ,src.Name									   AS SourceSystem
		  ,TOLPaymentEventInterface.I                  AS ReceiptTransactionId
          ,TOLPaymentEventInterface.C                  AS C
          ,TOLPaymentEventInterface.I                  AS I
          ,TOLPaymentEventInterface.LASTUPDATEDATE     AS Last_Update_Date
FROM              GEMINISVP1APP.dbo.TOLReceiptPaymentEvent
INNER JOIN        GEMINISVP1APP.dbo.TODomainInstance RecType         ON RecType.I_ODOM_Insts                            = 2090
                                                                  AND TOLReceiptPaymentEvent.EventType                = RecType.I
INNER JOIN        GEMINISVP1APP.dbo.TOLPaymentEventInterface         ON TOLReceiptPaymentEvent.I_PYMNTEIF_PaymentEventI = TOLPaymentEventInterface.I
                                                                  AND TOLReceiptPaymentEvent.C_PYMNTEIF_PaymentEventI = TOLPaymentEventInterface.C
INNER JOIN        GEMINISVP1APP.dbo.TOLPaymentDetails                ON TOLReceiptPaymentEvent.C_PYMNTDTL_PaymentEvent  = TOLPaymentDetails.C
                                                                  AND TOLReceiptPaymentEvent.I_PYMNTDTL_PaymentEvent  = TOLPaymentDetails.I
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TODomainInstance RecoveryMethod	 ON RecoveryMethod.i							  = TOLPaymentDetails.RecoveryMetho
INNER JOIN        GEMINISVP1APP.dbo.TOLLocalMoneyAmount              ON TOLPaymentDetails.C                           = TOLLocalMoneyAmount.C_PYMNTDTL_PaymentDetail
                                                                  AND TOLPaymentDetails.I                             = TOLLocalMoneyAmount.I_PYMNTDTL_PaymentDetail
INNER JOIN        GEMINISVP1APP.dbo.TOLRequestPaymentEvent           ON TOLReceiptPaymentEvent.C_RQSTPYMN_Receipts    = TOLRequestPaymentEvent.C
                                                                  AND TOLReceiptPaymentEvent.I_RQSTPYMN_Receipts      = TOLRequestPaymentEvent.I
INNER JOIN        GEMINISVP1APP.dbo.TOLOverpaymentCase               ON TOLOverpaymentCase.C_RQSTPYMN_OverpaymentRe   = TOLRequestPaymentEvent.C
                                                                  AND TOLOverpaymentCase.I_RQSTPYMN_OverpaymentRe     = TOLRequestPaymentEvent.I
INNER JOIN        GEMINISVP1APP.dbo.TOCCase opCase                   ON TOLOverpaymentCase.C_OCCASE_TheCase           = opCase.C
                                                                  AND TOLOverpaymentCase.I_OCCASE_TheCase             = opCase.I
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOCCase benCase                  ON benCase.C                                     = opCase.C_OCCASE_ChildCases
                                                                  AND benCase.I                                       = opCase.I_OCCASE_ChildCases
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TOCCase clmCase                  ON clmCase.C                                     = benCase.C_OCCASE_ChildCases
                                                                  AND clmCase.I                                       = benCase.I_OCCASE_ChildCases
INNER JOIN        GEMINISVP1APP.dbo.TOCProcessInstance               ON TOCProcessInstance.I_OCCASE_ResultingFrom     = opCase.I
                                                                  AND TOCProcessInstance.C_OCCASE_ResultingFrom       = opCase.C
INNER JOIN        GEMINISVP1APP.dbo.vosuser CreateUser               ON CreateUser.I                                  = TOLPaymentDetails.I_OSUSER_UPDATEDBY
                                                                  AND CreateUser.C                                    = TOLPaymentDetails.C_OSUSER_UPDATEDBY
LEFT OUTER JOIN   GEMINISVP1APP.dbo.TODomainInstance PayMeth         ON PayMeth.I_ODOM_Insts                            = 2198
                                                                  AND PayMeth.I                                       = TOLPaymentDetails.RecoveryMetho
LEFT OUTER JOIN  GEMINISVP1APP.dbo.TOCCaseType  BenType              ON BenType.C                                     = BenCase.C_OCCASTYP_Cases 
                                                                  AND BenType.I                                       = BenCase.I_OCCASTYP_Cases
LEFT OUTER JOIN	 GEMINISVP1APP.dbo.TOLClaim							 ON TOLClaim.I_OCCASE_ClaimCase					  = clmCase.I
																  AND TOLClaim.C_OCCASE_ClaimCase					  = clmCase.C
LEFT OUTER JOIN  GEMINISVP1APP.dbo.TOLContract						 ON TOLClaim.I									  = TOLContract.I_CLM_Contracts
																   AND TOLClaim.C									  = TOLContract.C_CLM_Contracts 
LEFT OUTER JOIN  GEMINISVP1APP.dbo.TODomainInstance src				 ON src.i										  = TOLContract.Source
WHERE RecType.Name = 'Overpayment Actual Recovery'
AND   TOLPaymentEventInterface.Status = 'PendingActive'
--
-- End SQL
--
);
GO



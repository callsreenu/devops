USE [GEMINISVP1APP]
GO

UPDATE truleversion SET disabledfg = 0 WHERE disabledfg = 1;  
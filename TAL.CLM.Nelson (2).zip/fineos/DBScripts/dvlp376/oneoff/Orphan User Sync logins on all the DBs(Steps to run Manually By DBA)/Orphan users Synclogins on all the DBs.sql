USE <GEMINISVP1APP>


SET NOCOUNT on
DECLARE @User sysname
DECLARE @NameFound bit
DECLARE orphan_cursor CURSOR FOR



 select name as UserName,
     CASE WHEN suser_sid(name) is not null
          THEN 1
          ELSE 0
     END as NameFound
  from sysusers
          where issqluser = 1
   and (sid is not null and sid <> 0x0)
   and suser_sname(sid) is null
       order by name



OPEN orphan_cursor
FETCH NEXT FROM orphan_cursor into @User, @NameFound
WHILE @@FETCH_STATUS = 0
BEGIN
    if @NameFound = 1
    begin
              select  'Synchronizing user  '+@User+' with login '+@User
              exec sp_change_users_login 'UPDATE_ONE' ,  @User, @User
    end
    else
    begin
                  select  'No matching login found for user  '+@User
    end
    FETCH NEXT FROM orphan_cursor into @User, @NameFound
END



CLOSE orphan_cursor
DEALLOCATE orphan_cursor
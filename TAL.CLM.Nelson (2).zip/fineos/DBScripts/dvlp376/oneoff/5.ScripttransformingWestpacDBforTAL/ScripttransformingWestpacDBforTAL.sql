USE [GEMINISVP1APP]
GO
update tolpaymentmethod set description = 'Electronic Funds Transfer' where i = 1;
update tolpaymentmethod set description = 'Cheque' where i = 2;
update tolpaymentmethod set description = 'Return Cheque' where i = 3;

USE [GEMINISVP1APP]
GO
CREATE USER [sa_akeso_app_dev2_dbo] FOR LOGIN [sa_akeso_app_dev2_dbo]
GO
USE [GEMINISVP1APP]
GO
ALTER ROLE [db_datareader] ADD MEMBER [sa_akeso_app_dev2_dbo]
GO
USE [GEMINISVP1APP]
GO
ALTER ROLE [db_datawriter] ADD MEMBER [sa_akeso_app_dev2_dbo]
GO
USE [GEMINISVP1APP]
GO
ALTER ROLE [db_owner] ADD MEMBER [sa_akeso_app_dev2_dbo]
GO
USE [GEMINISVP1sec]
GO
CREATE USER [sa_akeso_app_dev2_dbo] FOR LOGIN [sa_akeso_app_dev2_dbo]
GO
USE [GEMINISVP1sec]
GO
ALTER ROLE [db_datareader] ADD MEMBER [sa_akeso_app_dev2_dbo]
GO
USE [GEMINISVP1sec]
GO
ALTER ROLE [db_datawriter] ADD MEMBER [sa_akeso_app_dev2_dbo]
GO
USE [GEMINISVP1sec]
GO
ALTER ROLE [db_owner] ADD MEMBER [sa_akeso_app_dev2_dbo]
GO

*************************************************************************************

USE [GEMINISVP1VIEWS]
GO
CREATE USER [sa_akeso_app_dev2_read] FOR LOGIN [sa_akeso_app_dev2_read]
GO
USE [GEMINISVP1VIEWS]
GO
ALTER ROLE [db_datareader] ADD MEMBER [sa_akeso_app_dev2_read]
GO

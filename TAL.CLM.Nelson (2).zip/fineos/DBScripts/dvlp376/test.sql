USE [TestDB]
GO
ALTER ROLE [db_datareader] ADD MEMBER [sa_akeso_app_sql_dev]
GO
USE [TestDB]
GO
ALTER ROLE [db_datawriter] ADD MEMBER [sa_akeso_app_sql_dev]
GO
USE [TestDB]
GO
ALTER ROLE [db_owner] ADD MEMBER [sa_akeso_app_sql_dev]
GO
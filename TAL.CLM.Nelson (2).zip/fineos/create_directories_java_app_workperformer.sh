#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Application Server Setup - FINEOS 8.9"
echo "------------------------------------------------------------------------------"

[[ -z "${TARGET_ENV}" ]]  && echo -e "TARGET_ENV is blank. Setting to 'akeso-dev'." && TARGET_ENV=akeso-dev
echo "TARGET_ENV='${TARGET_ENV}"

[[ -z "${JBOSS_USER}" ]]  && echo -e "JBOSS_USER is blank. Setting to 'jboss'." && JBOSS_USER=jboss
echo "JBOSS_USER='${JBOSS_USER}"

[[ -z "${FINEOS_USER}" ]]  && echo -e "FINEOS_USER is blank. Setting to '${JBOSS_USER}'." && FINEOS_USER=$JBOSS_USER
echo "FINEOS_USER='${FINEOS_USER}"

[[ -z "${FINEOS_USER_GROUP}" ]]  && echo -e "FINEOS_USER_GROUP is blank. Setting to '${JBOSS_USER}'." && FINEOS_USER_GROUP=$JBOSS_USER
echo "FINEOS_USER_GROUP='${FINEOS_USER_GROUP}"

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Create Java App Directories if they don't already exist"
echo "------------------------------------------------------------------------------"
sudo mkdir -p /opt/fineos/java-apps/$TARGET_ENV/workperformer

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Set Directory Permissions"
echo "Update permissions if not running FINEOS applications under the root account"
echo "------------------------------------------------------------------------------"
sudo chown -R $FINEOS_USER:$FINEOS_USER_GROUP /opt/fineos
sudo chmod -R 755 /opt/fineos
sudo chmod -R g+s /opt/fineos
sudo setfacl -R -d -m g:$FINEOS_USER_GROUP:rwx /opt/fineos

echo "FINISHED"
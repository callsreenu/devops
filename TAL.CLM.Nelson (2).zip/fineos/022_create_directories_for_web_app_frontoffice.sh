#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Create external directories for the web application: FRONTOFFICE"
echo "------------------------------------------------------------------------------"
source fineos/functions.sh
source jboss/functions.sh

APP_HOME="web-apps/${TARGET_ENV}/frontoffice"

echo 
echo "------------------------------------------------------------------------------"
echo "Create ENV+APP-specific FINEOS folders exist..."
echo "------------------------------------------------------------------------------"
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/docstore/temp
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/export/environmentmigration
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/import/environmentmigration
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/import/bank
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/import/medical
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/import/occupation
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/logs
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/rulesclasses
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/savedselection
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/templates
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/gc-logs
sudo mkdir -p ${FINEOS_BASE}/${APP_HOME}/heap-dumps
updateFineosOwnership

echo
echo "FINISHED"

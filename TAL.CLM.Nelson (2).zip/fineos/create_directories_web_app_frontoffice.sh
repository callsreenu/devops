#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Install JBoss EAP version 7.3"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

[[ "X" -eq "X${TARGET_ENV}" ]]  && echo "TARGET_ENV is blank. Setting to 'akeso-dev'." && export TARGET_ENV='akeso-dev';
echo "TARGET_ENV='${TARGET_ENV}'"

[[ -z "${JBOSS_USER}" ]]  && echo "JBOSS_USER is blank. Setting to 'jboss'." && export JBOSS_USER='jboss';
echo "JBOSS_USER='${JBOSS_USER}'"

[[ -z "${FINEOS_USER}" ]]  && echo "FINEOS_USER is blank. Setting to '${JBOSS_USER}'." && export FINEOS_USER="${JBOSS_USER}";
echo "FINEOS_USER='${FINEOS_USER}'"
#
[[ -z "${FINEOS_USER_GROUP}" ]]  && echo -e "FINEOS_USER_GROUP is blank. Setting to '${JBOSS_USER}'." && export FINEOS_USER_GROUP="${JBOSS_USER}";
echo "FINEOS_USER_GROUP='${FINEOS_USER_GROUP}'"
#
echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Create Web App Directories if they don't already exist"
echo "------------------------------------------------------------------------------"
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/docstore/temp
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/export/environmentmigration
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/import/environmentmigration
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/import/bank
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/import/medical
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/import/occupation
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/logs
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/rulesclasses
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/savedselection
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/templates
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/gc-logs
sudo mkdir -p /opt/fineos/web-apps/$TARGET_ENV/frontoffice/heap-dumps
#
echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Set Directory Permissions"
echo "Update permissions if not running FINEOS applications under the root account"
echo "------------------------------------------------------------------------------"
sudo chown -R ${FINEOS_USER}:${FINEOS_USER_GROUP} /opt/fineos
sudo chmod -R 755 /opt/fineos
sudo chmod -R g+s /opt/fineos
sudo setfacl -R -d -m g:"${FINEOS_USER_GROUP}":rwx /opt/fineos

echo "FINISHED"

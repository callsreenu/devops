#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Apply FINEOS-specific configuration to Secure JBoss Profile"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: 4.1.2 Disable JSP Tag Pooling through the Management CLI"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    /subsystem=undertow/servlet-container=default/setting=jsp:write-attribute(name=tag-pooling, value=false)
    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: 4.5 Static Resource Caching "
echo "(a.k.a. Enable Caching on secures pages)"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    /subsystem=undertow/servlet-container=default:write-attribute(name="disable-caching-for-secured-pages",value="false")
    /subsystem=undertow/configuration=filter/response-header=custom-max-age:add(header-name="Cache-Control",header-value="max-age=36000,public")
    /subsystem=undertow/server=default-server/host=default-host/filter-ref=custom-max-age:add(predicate="path-suffix('.js')or path-suffix ('.css') or path-suffix ('.jpg') or path-suffix ('.jpeg') or path-suffix ('.png') or path-suffix ('.gif')")

    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: 4.8.2 Microsoft SQL Server JDBC Driver Creation"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    if (outcome == success) of  /subsystem=datasources/jdbc-driver=MSSQLDriver:read-resource
        echo "Microsoft SQL Server JDBC Driver already installed."
    else
        /subsystem=datasources/jdbc-driver=MSSQLDriver:add(driver-name=MSSQLDriver,driver-module-name=com.microsoft,driver-xa-datasource-class-name=com.microsoft.sqlserver.jdbc.SQLServerXADataSource)
        reload --admin-only=true
    end-if
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: 4.9.2.2 Microsoft SQL Server Datasource Creation"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT

    if (outcome != success) of /subsystem=datasources/data-source=FINEOSAPP_MSSQL:read-resource
        data-source add \
        --name=FINEOSAPP_MSSQL \
        --jndi-name=java:/fineosappref \
        --driver-name=MSSQLDriver \
        --user-name=${DB_USER_NAME_APP} \
        --password=${DB_USER_PASS_APP} \
        --connection-url="jdbc:sqlserver://${DB_SERVER}:${DB_SERVER_PORT};DatabaseName=${APP_DB_NAME};encrypt=false;trustServerCertificate=false;" \
        --validate-on-match=false \
        --background-validation=false \
        --min-pool-size=20 \
        --max-pool-size=30 \
        --initial-pool-size=20 \
        --pool-prefill=true \
        --idle-timeout-minutes=10 \
        --background-validation=false \
        --background-validation-millis=60000 \
        --check-valid-connection-sql="select getdate()" \
        --set-tx-query-timeout=true \
        --query-timeout=300 \
        --jta=false
    end-if

    if (outcome != success) of /subsystem=datasources/data-source=FINEOSSEC_MSSQL:read-resource
        data-source add \
        --name=FINEOSSEC_MSSQL \
        --jndi-name=java:/fineossecref \
        --driver-name=MSSQLDriver \
        --user-name=${DB_USER_NAME_SEC} \
        --password=${DB_USER_PASS_SEC} \
        --connection-url="jdbc:sqlserver://${DB_SERVER}:${DB_SERVER_PORT};DatabaseName=${SEC_DB_NAME};encrypt=false;trustServerCertificate=false;" \
        --validate-on-match=false \
        --background-validation=false \
        --min-pool-size=20 \
        --max-pool-size=30 \
        --initial-pool-size=20 \
        --pool-prefill=true \
        --idle-timeout-minutes=10 \
        --background-validation=false \
        --background-validation-millis=60000 \
        --check-valid-connection-sql="select getdate()" \
        --set-tx-query-timeout=true \
        --query-timeout=300 \
        --jta=false
    end-if


    if (outcome != success) of /subsystem=datasources/data-source=FINEOSANAAPP_MSSQL:read-resource
        data-source add \
        --name=FINEOSANAAPP_MSSQL \
        --jndi-name=java:/fineosanaappref \
        --driver-name=MSSQLDriver \
        --user-name=${DB_USER_NAME_ANAAPP} \
        --password=${DB_USER_PASS_ANAAPP} \
        --connection-url="jdbc:sqlserver://${DB_SERVER}:${DB_SERVER_PORT};DatabaseName=${ANA_APP_DB_NAME};encrypt=false;trustServerCertificate=false;" \
        --validate-on-match=false \
        --background-validation=false \
        --min-pool-size=20 \
        --max-pool-size=30 \
        --initial-pool-size=20 \
        --pool-prefill=true \
        --idle-timeout-minutes=10 \
        --background-validation=false \
        --background-validation-millis=60000 \
        --check-valid-connection-sql="select getdate()" \
        --set-tx-query-timeout=true \
        --query-timeout=300 \
        --jta=false
    end-if

    if (outcome != success) of /subsystem=datasources/data-source=FINEOSANASEC_MSSQL:read-resource
        data-source add \
        --name=FINEOSANASEC_MSSQL \
        --jndi-name=java:/fineosanasecref \
        --driver-name=MSSQLDriver \
        --user-name=${DB_USER_NAME_ANASEC} \
        --password=${DB_USER_PASS_ANASEC} \
        --connection-url="jdbc:sqlserver://${DB_SERVER}:${DB_SERVER_PORT};DatabaseName=${ANA_SEC_DB_NAME};encrypt=false;trustServerCertificate=false;" \
        --validate-on-match=false \
        --background-validation=false \
        --min-pool-size=20 \
        --max-pool-size=30 \
        --initial-pool-size=20 \
        --pool-prefill=true \
        --idle-timeout-minutes=10 \
        --background-validation=false \
        --background-validation-millis=60000 \
        --check-valid-connection-sql="select getdate()" \
        --set-tx-query-timeout=true \
        --query-timeout=300 \
        --jta=false
    end-if


    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: 4.9.2.4 Testing Datasource connections"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    /subsystem=datasources/data-source=FINEOSAPP_MSSQL:test-connection-in-pool
    /subsystem=datasources/data-source=FINEOSSEC_MSSQL:test-connection-in-pool
    /subsystem=datasources/data-source=FINEOSANAAPP_MSSQL:test-connection-in-pool
    /subsystem=datasources/data-source=FINEOSANASEC_MSSQL:test-connection-in-pool

    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: 4.10.1.1 Create the com.sun.tools.javac static module"
echo "------------------------------------------------------------------------------"
echo "Creating symbolic link from tools.jar to custom module."
#ln -s /etc/alternatives/java_sdk/lib/tools.jar $JBOSS_HOME/modules/com/sun/tools/javac/main/tools.jar
SCRIPT=$(cat <<END_OF_SCRIPT
    module add \
    --name=com.sun.tools.javac \
    --resources=/etc/alternatives/java_sdk/lib/tools.jar \
    --dependencies=javax.api

    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"


echo 
echo "Cleanup after executing CLI script."
sudo rm -Rf ${JBOSS_HOME}/standalone/configuration/standalone_xml_history
sudo rm -Rf ${JBOSS_HOME}/standalone/log
sudo rm -Rf ${JBOSS_HOME}/standalone/data

updateJBossOwnership

echo
echo "FINISHED"


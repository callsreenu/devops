#!/usr/bin/env bash
source fineos/functions.sh
echo "------------------------------------------------------------------------------"
echo "TASK: Application Server Setup - FINEOS 8.9"
echo "------------------------------------------------------------------------------"

[[ -z "${TARGET_ENV}" ]]  && echo -e "TARGET_ENV is blank. Setting to 'akeso-dev'." && TARGET_ENV=akeso-dev
echo "TARGET_ENV='${TARGET_ENV}'"

[[ -z "${TARGET_ENV}" ]]  && echo -e "TARGET_ENV is blank. Setting to 'akeso-dev2'." && TARGET_ENV=akeso-dev2
echo "TARGET_ENV='${TARGET_ENV}'"

[[ -z "${TARGET_ENV}" ]]  && echo -e "TARGET_ENV is blank. Setting to 'akeso-sys'." && TARGET_ENV=akeso-sys
echo "TARGET_ENV='${TARGET_ENV}'"

[[ -z "${FINEOS_USER}" ]]  && echo -e "FINEOS_USER is blank. Setting to '${JBOSS_USER}'."
echo "FINEOS_USER='${FINEOS_USER}'"

[[ -z "${FINEOS_USER_GROUP}" ]]  && echo -e "FINEOS_USER_GROUP is blank. Setting to '${JBOSS_USER}'."
echo "FINEOS_USER_GROUP='${FINEOS_USER_GROUP}'"


echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Create Java App Directories if they don't already exist"
echo "Target Env: $TARGET_ENV"
echo "------------------------------------------------------------------------------"
#sudo mkdir -p /opt/fineos/java-apps/$TARGET_ENV/environmentcreator

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: Set Directory Permissions"
echo "Update permissions if not running FINEOS applications under the root account"
echo "------------------------------------------------------------------------------"
sudo chown -R $FINEOS_USER:$FINEOS_USER_GROUP /opt/fineos
sudo chmod -R 755 /opt/fineos
sudo chmod -R g+s /opt/fineos
sudo setfacl -R -d -m g:$FINEOS_USER_GROUP:rwx /opt/fineos

APPLICATION_DISTRO="${ENVIRONMENTCREATOR_DISTRO}"
APPLICATION_NAME=environmentcreator
APP_HOME="java-apps/${TARGET_ENV}/${APPLICATION_NAME}"
echo -e "APP_HOME=${APP_HOME}"

echo "------------------------------------------------------------------------------"
echo "Decompress (unzip) the Application Archive to a APP location"
echo "------------------------------------------------------------------------------"
[[ -d "${FINEOS_BASE}/${APP_HOME}" ]] && sudo rm -Rf "${FINEOS_BASE}/${APP_HOME}"
sudo mkdir -p "${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/" 
sudo unzip -q "${APPLICATION_DISTRO}" -d "${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/" 
sudo cd "${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/"
find ./ -type f -name "*.sh" -exec chmod ug+x '{}' \; > /dev/null 2>&1
sudo ls -lrt
#sudo cp ${BUILD_SOURCESDIRECTORY}/fineos/files/${TARGET_ENV}/java-apps/${APPLICATION_NAME}/fineos.properties ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/classes/
#sudo cp ${BUILD_SOURCESDIRECTORY}/fineos/files/${TARGET_ENV}/java-apps/${APPLICATION_NAME}/environmentcreator.properties ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/config/
#sudo cp ${BUILD_SOURCESDIRECTORY}/fineos/files/${TARGET_ENV}/java-apps/${APPLICATION_NAME}/WorkPerformer_config.xml ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/config/envs/fineosenv/
#RUNNING_ON_PORT=8090
#sudo sed -i 's/RUNNING_ON_PORT=8090/RUNNING_ON_PORT=8090/g' ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/bin/WorkPerformer_STOP.bat
#${FINEOS_BASE}/${APP_HOME}/config/envs/fineosenv/workperformer_start_wrapper.conf 
sudo cd ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/
sudo chmod 755 ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/
sudo cd ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/ && pwd
DB_PASS="${DB_USER_PASS}"
echo "DB_USER_PASS******: ${DB_PASS}"
echo "DB_USER_PASS******: ${DB_USER_PASS}"
#echo "sudo updateFilesForJavaApps '${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}' '${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}'"
#updateFilesForJavaApps "${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}" "${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}" "${APPLICATION_NAME}"

echo "------------------------------------------------------------------------------"
echo "Creating JBoss non-login user '${FINEOS_USER}' with no home folder."
echo "------------------------------------------------------------------------------"
sudo id -u fineos &>/dev/null || sudo useradd -M fineos
sudo usermod -L fineos
#sudo chown fineos:fineos /opt/fineos/ 
sudo chown -R fineos:fineos /opt/fineos/java-apps
pwd
sudo cd ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/
pwd
#sudo echo "FINEOS_USER=${​​FINEOS_USER}​​"
#sudo su -c "./WorkPerformer_START.sh" "${FINEOS_USER}"
sudo chmod 755 ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/*.sh
echo "---------------------------------${TARGET_ENV} - ${DB_SERVER} DETAILS ---------------------------------------------"
echo "DESTINATION_DB: ${DESTINATION_DB}"
echo "DB_SERVER: ${DB_SERVER}"
echo "DB_USER_NAME: ${DB_USER_NAME}"
echo "DB_USER_PASS: ${DB_USER_PASS}"
echo "DB_USER_NAME_APP: ${DB_USER_NAME_APP}" 
echo "DB_USER_PASS_APP: ${DB_USER_PASS_APP}"
echo "DB_USER_NAME_SEC: ${DB_USER_NAME_SEC}"
echo "DB_USER_PASS_SEC: ${DB_USER_PASS_SEC}"
echo "------------------------------------------------------------------------------"
sudo su -c "cd ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/ && ls -lrt && nohup ./createDatabase.sh -PdropDatabase=false -PcreateFromScratch=false -PrestoreFromBackup=false -Pdestinationdb=${DESTINATION_DB} -Pinstance=${DB_SERVER} -PdbUser=${DB_USER_NAME} -PsysPasswd={DB_USER_PASS} -Puser.app=${DB_USER_NAME_APP} -Ppasswd.app=${DB_USER_PASS_APP} -Puser.sec=${DB_USER_NAME_SEC} -Ppasswd.sec=${DB_USER_PASS_SEC} --debug &" "fineos"

# sudo cd ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/
# echo "----------------------------------LIST FILES--------------------------------------------"
# sudo ls -lrt
# echo "------------------------------------------------------------------------------"
# sudo su -c "nohup ./createDatabase.sh -PdropDatabase=false -PcreateFromScratch=false -PrestoreFromBackup=false -Pdestinationdb=${DESTINATION_DB} -Pinstance=${DB_SERVER} -PdbUser=${DB_USER_NAME} -PsysPasswd={DB_USER_PASS} -Puser.app=${DB_USER_NAME_APP} -Ppasswd.app=${DB_USER_PASS_APP} -Puser.sec=${DB_USER_NAME_SEC} -Ppasswd.sec='${DB_USER_PASS_SEC}' --debug &" "fineos"

#sudo su -c "cd ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/ && ls -l && nohup ./createDatabase.sh -Pdestinationdb=${DESTINATION_DB} -PdropDatabase=false -PcreateFromScratch=false -PrestoreFromBackup=false -Pinstance=${DB_SERVER} -PdbUser=${DB_USER_NAME} -PsysPasswd=${DB_USER_PASS} -Ppasswd.app=${DB_USER_PASS} -Ppasswd.sec=${DB_USER_PASS} --debug &" "fineos"
#createDatabase.sh -Pdestinationdb=AKESO_UAT_ -PdropDatabase=false -PcreateFromScratch=false -PrestoreFromBackup=false -Pinstance=db-server.tal.com -Puser.app=AKESO_UAT_APP -Ppasswd.app=Qa_app_pwd -Puser.sec=AKESO_UAT_SEC -Ppasswd.sec=Qa_sec_pwd

#sudo cd ${FINEOS_BASE}/${APP_HOME}/environmentcreator-${ENVIRONMENTCREATOR_VERSION}/bin/
sudo pwd
echo "FINISHED"
# Establish Java Keystores for the Akeso environments

Created by: Gary Marshall
Updated: October 21, 2022

This document describes how to provision an entire JBoss EAP environment in support of the following FINEOS Web Applications:

## Process overview - Generate PKI Assets
JBoss references two java keystores and they must be in JKS (Java Keystore) format:
- The Java keystore identity.jks is used to secure the Management Interfaces including the Web Console and JBoss Management CLI.
- The Java keystore applications.jks is used to secure the Application Realm.

JBoss expects the keystores and CSR in the PKI_HOME folder:
```BASH
/jboss/pki/jboss-eap-7.3/applications.jks
/jboss/pki/jboss-eap-7.3/akeso-dev.internal.tal.com.au.CSR
```
Both keystores are both using the same alias and private key.  For this reason, each of the keystores is created from a copy of the same keystore.

**NOTE**: Should testing reveal that a single keystore can be referenced by both Management and Application realms, such consolidation would be recommended.

## Use OpenSSL to generate the CSR and Signed Certificate.
1. Obtain a signed certificate from the Security team
First, set the following environment variables:
```BASH
TARGET_ENV=akeso-dev
TARGET_HOST=$(hostname)
TARGET_HOST_FQ=$(hostname -f)
TARGET_HOST_IP=10.135.1.129
TARGET_DNS=${TARGET_ENV}.internal.tal.com.au
```

Optionally, verify by printing the environment variables to the colsole:
```BASH
echo "TARGET_ENV=${TARGET_ENV}"
echo "TARGET_HOST=${TARGET_HOST}"
echo "TARGET_HOST_FQ=${TARGET_HOST_FQ}"
echo "TARGET_HOST_IP=${TARGET_HOST_IP}"
echo "TARGET_DNS=${TARGET_DNS}"
```

Generate a private key:
```BASH
openssl genrsa -out "${HOME}/${SUBJECT}.key" 4096
```

Generate a CSR certificate from the private key and share the CSR file with the security team.
```BASH
openssl req -new \
-out "$HOME/${SUBJECT}.csr" \
-key "${HOME}/${SUBJECT}.key" \
-sha256 \
-subj "/C=AU/ST=New South Wales/L=Sydney/O=TAL Limited/OU=Information Technology/CN=${TARGET_HOST_FQ}/emailAddress=nirav.padia@tal.com.au" \
-reqexts SAN -config \
<(cat /etc/pki/tls/openssl.cnf \
<(printf "[SAN]\nsubjectAltName=DNS:${TARGET_DNS},DNS:${TARGET_HOST},DNS:${TARGET_HOST_IP}"))
```

2. Generate a Java Keystore from the Import Signed Certificate
The Security team will provide a signed certificate generated fro mthe CSR.  The certificate will be in .CER format.  However, a .p12 file is required to generate a Java Keystore (.JKS) so the file must be converted.

> Convert CRT file to CER format
> NOTE: If the signed certificate is provided in .CRT format, it will need to be converted to .CER format before continuing to the next step. 

Convert CER file into p12 format:
```BASH
openssl pkcs12 -export \
-in ${TARGET_ENV}.cer \
-inkey ${TARGET_HOST_FQ}.key \
-out ${TARGET_HOST_FQ}.p12 \
-name "${TARGET_ENV}"
```

Generate the JSK file:
```BASH
keytool -v \
-importkeystore \
-srckeystore ${TARGET_HOST}.p12 \
-srcstoretype PKCS12 \
-destkeystore ${TARGET_ENV}.jks 
-deststoretype JKS
```

3. Copy the Java Keystore to the required locations
The Java Keystore can be copied to the required locations using the following commands.

First, ensure the ENVIRONMENT variables are set:
```BASH
TARGET_ENV=akeso-dev
TARGET_HOST=$(hostname)
TARGET_HOST_FQ=$(hostname -f)
TARGET_HOST_IP=10.135.1.129
TARGET_DNS=${TARGET_ENV}.internal.tal.com.au
JBOSS_USER=????
JBOSS_USER_GROUP=????
```

**NOTE**: The JBoss user and group must be obtained to ensure the correct file ownership is applied.
Once the environment variables have been verified, and JBoss processes stopped, issue the following commands from the directory containing the generated keystore.  This will the install 2 required keystore(s) into the JBoss environment:
```BASH
cp ${TARGET_ENV}.jks /jboss/pki/jboss-eap-7.3/
sudo chown -r ${JBOSS_USER}:${JBOSS_USER_GROUP} /jboss
cd /jboss/pki/jboss-eap-7.3/

# Backup the JKS files if they already exist
mv identity.jks identity.jks.BKP
mv applications.jks applications.jks.BKP

# Install (copy) the keystores 
cp ${TARGET_ENV}.jks identity.jks 
cp ${TARGET_ENV}.jks applications.jks
chown -R ${JBOSS_USER}:${JBOSS_USER_GROUP} /jboss/pki/jboss-eap-7.3
```

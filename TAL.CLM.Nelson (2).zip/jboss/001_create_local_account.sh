#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "Creating JBoss non-login user '${JBOSS_USER}' with no home folder."
echo "------------------------------------------------------------------------------"
sudo id -u ${JBOSS_USER:-jboss} &>/dev/null || sudo useradd -M ${JBOSS_USER:-jboss}
# echo "sudo usermod -L ${JBOSS_USER:-jboss}"
# sudo usermod -L ${JBOSS_USER:-jboss}
# Add current user to JBOSS group
echo "sudo gpasswd -a $USER ${JBOSS_USER:-jboss}"
sudo gpasswd -a $USER ${JBOSS_USER:-jboss}

echo
echo "FINISHED"

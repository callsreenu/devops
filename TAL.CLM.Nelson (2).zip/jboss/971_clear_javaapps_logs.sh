#!/usr/bin/env bash
echo "To be Updated - Dummy Script Below"
echo "-----------------------------------------------------------------------------*"
echo "* DEBUG                                       `date` *"
echo "-----------------------------------------------------------------------------*"
echo "*** System Info ***"
echo "ALL..................: "`uname -a`
echo "hostname.............: "`uname -n`
echo "kernal name..........: "`uname -s`
echo "kernel release date..: "`uname -r`
echo "kernel version.......: "`uname -v`
echo "machine hardware.....: "`uname -m`
echo "processor type.......: "`uname -p`
echo "hardware platform....: "`uname -i`
echo "operating system.....: "`uname -o`
echo 
echo "*** Agent Info ***"
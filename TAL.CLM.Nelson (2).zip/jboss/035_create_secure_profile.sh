#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Create Security Hardened Profile"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

echo 
echo "------------------------------------------------------------------------------"
echo "Cleanup after executing CLI script."
echo "------------------------------------------------------------------------------"
sudo rm -Rf ${JBOSS_HOME}/standalone/configuration/standalone_xml_history
sudo rm -Rf ${JBOSS_HOME}/standalone/tmp
sudo rm -Rf ${JBOSS_HOME}/standalone/log
sudo rm -Rf ${JBOSS_HOME}/standalone/data

echo 
echo "------------------------------------------------------------------------------"
echo "Create a Secure profile."
echo "------------------------------------------------------------------------------"
sudo cp -R ${JBOSS_HOME}/standalone ${JBOSS_HOME}/${SECURE_PROFILE}
updateJBossOwnership

# Execute 'zip' command from JBOSS_HOME to supress upstream file paths
pushd ${JBOSS_HOME}
sudo zip -qr ${JBOSS_HOME}/TAL-${JBOSS_VERSION}-secure-profile.zip ${SECURE_PROFILE}
# Return to previous directory location
popd
updateJBossOwnership

# Display contents of zip file
echo "Created file: ${JBOSS_HOME}/${JBOSS_VERSION}-secure-profile.zip"
ls -l ${JBOSS_HOME}/TAL-${JBOSS_VERSION}-secure-profile.zip
unzip -l ${JBOSS_HOME}/TAL-${JBOSS_VERSION}-secure-profile.zip

echo
echo "FINISHED"

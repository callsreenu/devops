#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Check and Clear Logs - Jboss EAP Services"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

echo "INSTANCES_HOME='${INSTANCES_HOME}'"
echo "FINEOS_WEB_APP_BASE='${FINEOS_WEB_APP_BASE}'"
echo "TARGET_ENV='${TARGET_ENV}'"


## Validate pipeline variables
#[[ -e "${INSTANCES_HOME}" ]] && echo "ERROR: Instance Home is empty or not provided." && exit 1;
#[[ -e "${FINEOS_WEB_APP_BASE}" ]] && echo "ERROR: FINEOS_WEB_APP_BASE is empty or not provided." && exit 1;
#[[ -e "${TARGET_ENV}" ]] && echo "ERROR: TARGET_ENV is empty or not provided." && exit 1;

if [[ ! -d "${INSTANCES_HOME}" ]]; then
    echo
    echo -e "ERROR: INSTANCES_HOME folder not found at: '${INSTANCES_HOME}'" 
    echo "Exiting..."
    exit 1
fi

if [[ ! -d "${FINEOS_WEB_APP_BASE}" ]]; then
    echo
    echo -e "ERROR: FINEOS WEB APP BASE folder not found at: '${FINEOS_WEB_APP_BASE}'" 
    echo "Exiting..."
    exit 1
fi


ls -lrt $FINEOS_WEB_APP_BASE/$TARGET_ENV/frontoffice/logs/
sudo rm $FINEOS_WEB_APP_BASE/$TARGET_ENV/frontoffice/logs/*.log*
sudo rm $FINEOS_WEB_APP_BASE/$TARGET_ENV/services/logs/*.log*
sudo rm $FINEOS_WEB_APP_BASE/$TARGET_ENV/analytics/logs/*.log*
sudo rm $INSTANCES_HOME/frontoffice/log/*.log*
sudo rm $INSTANCES_HOME/services/log/*.log*
sudo rm $INSTANCES_HOME/analytics/log/*.log*

ls -ld $FINEOS_WEB_APP_BASE/$TARGET_ENV/frontoffice/logs/
ls -lrt $FINEOS_WEB_APP_BASE/$TARGET_ENV/frontoffice/logs/

ls -ld $FINEOS_WEB_APP_BASE/$TARGET_ENV/services/logs/
ls -lrt $FINEOS_WEB_APP_BASE/$TARGET_ENV/services/logs/

ls -ld $FINEOS_WEB_APP_BASE/$TARGET_ENV/analytics/logs/
ls -lrt $FINEOS_WEB_APP_BASE/$TARGET_ENV/analytics/logs/

ls -ld $INSTANCES_HOME/frontoffice/log/
ls -lrt $INSTANCES_HOME/frontoffice/log/

ls -ld $INSTANCES_HOME/services/log/
ls -lrt $INSTANCES_HOME/services/log/

ls -ld $INSTANCES_HOME/analytics/log/
ls -lrt $INSTANCES_HOME/analytics/log/
#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Start JBoss EAP services"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

echo "INSTANCE_NAME='${INSTANCE_NAME}'"
echo "PORT_OFFSET='${PORT_OFFSET}'"

## Validate pipeline variables

[[ -e "${INSTANCE_NAME}" ]] && echo -e "\nERROR: Instance Name is empty or not provided." && exit 1;
[[ ! -d "${INSTANCES_HOME}" ]] && echo -e "\nERROR: INSTANCES_HOME folder not found at: '${INSTANCES_HOME}'\nExiting..." && exit 1;

[[ -e "${PORT_OFFSET}" ]] && echo "ERROR: Port Offset is empty or not provided." && exit 1;
[[ ! "${PORT_OFFSET}" =~ ^-?[0-9]+$ ]] && echo "ERROR: Port Offset invalid - must be numeric: '${PORT_OFFSET}'"
[[ (( "${PORT_OFFSET}" -lt "0" || "${PORT_OFFSET}" -gt "1000" )) ]] && echo "ERROR: Port Offset out of range (0 - 1000): ${PORT_OFFSET}" && exit 1;

echo
echo "Ensure console-log folder is present at: ${INSTANCES_HOME}/console-logs"
[[ ! -d ${INSTANCES_HOME}/console-logs ]] \
&& sudo mkdir -p ${INSTANCES_HOME}/console-logs \
&& echo "Not found - creating.\n" \
&& updateJBossOwnership

# RHEL 7/8 use 'systemctl' instead of the 'chkconfig' and 'service' commands
echo 
if [[ "${RUN_AS_SERVICE}" == 'true' ]] 
then
    echo "sudo systemctl enable ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service"
    sudo systemctl start ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service
else
    echo "startInstance ${INSTANCE_NAME} ${PORT_OFFSET}"
    startInstance ${INSTANCE_NAME} ${PORT_OFFSET}
fi

echo "Retrieving details of running process..."
ps -aux | grep java | grep "${INSTANCE_NAME}"

echo
echo "FINISHED"

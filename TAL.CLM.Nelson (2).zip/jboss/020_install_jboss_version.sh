#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Install JBoss EAP version 7.3"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

echo
echo "------------------------------------------------------------------------------"
echo "CHECK PKI Assets are in place - if not, throw error"
echo "------------------------------------------------------------------------------"
[[ -z "${PKI_HOME}" ]] && echo -e "\n\n** FATAL: PKI_HOME not set or empty." && exit 1;
[[ ! -d "${PKI_HOME}" ]] && echo -e "\n\n** FATAL: PKI folder not found at: ${PKI_HOME}" && exit 1;
[[ ! -f "${PKI_HOME}/${KEYSTORE}" ]] && echo -e "\n\n** FATAL: Keystore not found at: ${PKI_HOME}/${KEYSTORE}" && exit 1;
[[ ! -f "${PKI_HOME}/${MGMT_KEYSTORE}" ]] && echo -e "\n\n** FATAL: Keystore not found at: ${PKI_HOME}/${MGMT_KEYSTORE}" && exit 1;

echo 
echo "------------------------------------------------------------------------------"
echo "Creating JBoss non-login user '${JBOSS_USER}' with no home folder"
echo "------------------------------------------------------------------------------"
# sudo useradd -M ${JBOSS_USER:-jboss} 
# sudo usermod -L ${JBOSS_USER:-jboss}
# Add current user to JBoss group
sudo gpasswd -a $USER ${JBOSS_USER:-jboss}

echo
echo "------------------------------------------------------------------------------"
echo "Unzip JBoss Archive"
echo "------------------------------------------------------------------------------"
sudo unzip -q "${JBOSS_DISTRO}" -d "${JBOSS_BASE}" 
updateJBossOwnership

echo
echo "------------------------------------------------------------------------------"
echo "Backup the 'standalone' folder prior to applying the patch"
echo "------------------------------------------------------------------------------"
sudo su -c "cp -Rf $JBOSS_HOME/standalone $JBOSS_HOME/standalone_before_patch" ${JBOSS_USER:-jboss}

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Apply patch"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    patch apply ${JBOSS_PATCH}
    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "Cleanup standalone profile"
echo "------------------------------------------------------------------------------"
sudo rm -Rf ${JBOSS_HOME}/standalone/configuration/standalone_xml_history
sudo rm -Rf ${JBOSS_HOME}/standalone/log
sudo rm -Rf ${JBOSS_HOME}/standalone/data

# echo 
# echo "------------------------------------------------------------------------------"
# echo "Ensure that the PKI_ASSETS_FOLDER folder exists..."
# echo "------------------------------------------------------------------------------"
# if [[ -d ${PKI_ASSETS_FOLDER} ]] ; then
#    echo "Found PKI_ASSETS_FOLDER at:${PKI_ASSETS_FOLDER}" 
#    ls -l ${PKI_ASSETS_FOLDER}
# else
#     echo "Creating PKI_ASSETS_FOLDER folder at: '${PKI_ASSETS_FOLDER}'."
#     mkdir -p ${PKI_ASSETS_FOLDER}
# fi

echo 
echo "------------------------------------------------------------------------------"
echo "Ensure that the INSTANCES_HOME folder exists..."
echo "------------------------------------------------------------------------------"
if [[ ! -d "${INSTANCES_HOME}}" ]]; then
    echo "Creating INSTANCES_HOME folder at: '${INSTANCES_HOME}'."
    sudo mkdir -p ${INSTANCES_HOME}
else 
    echo "Found INSTANCES_HOME at: '${INSTANCES_HOME}'."
fi
updateJBossOwnership


echo 
echo "------------------------------------------------------------------------------"
echo "Backup the standalone folder prior to applying the patch"
echo "------------------------------------------------------------------------------"
sudo su -c "cp -Rf $JBOSS_HOME/standalone $JBOSS_HOME/standalone_after_patch" ${JBOSS_USER:-jboss}

echo
echo "FINISHED"

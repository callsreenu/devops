#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Generate Certificate Signing Request (CSR)"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

echo "INSTANCE_NAME='${INSTANCE_NAME}'"

[[ -f "${PKI_STAGING}/${APPS_CSR_FILE}" ]] && echo -e "Target APPS CSR file already exists - deleting" && \
sudo rm -f "${PKI_STAGING}/${APPS_CSR_FILE}";

[[ -f "${PKI_STAGING}/${MGMT_CSR_FILE}" ]] && echo -e "Target MGMT CSR file already exists - deleting" && \
sudo rm -f "${PKI_STAGING}/${MGMT_CSR_FILE}";

echo 
echo "------------------------------------------------------------------------------"
echo "Generate APPS CSR"
echo "------------------------------------------------------------------------------"
if [[ ! -f "${PKI_STAGING}/${APPS_CSR_FILE}" ]] ; then
    sudo keytool -certreq -v \
    -noprompt \
    -alias "${TARGET_ENV}" \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${PKI_STAGING}/${KEYSTORE}" \
    -storepass "${STOREPASS}" \
    -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_STAGING}/${APPS_CSR_FILE}"
    updateJBossOwnership

    echo
    echo "Generate CSR at: '${PKI_STAGING}/${APPS_CSR_FILE}'"
    cat "${PKI_STAGING}/${APPS_CSR_FILE}"
else
    echo "Existing CSR at: '${PKI_STAGING}/${APPS_CSR_FILE}'"
    sudo ls -l "${PKI_STAGING}/${APPS_CSR_FILE}"
fi

echo 
echo "------------------------------------------------------------------------------"
echo "Generate MGMT CSR"
echo "------------------------------------------------------------------------------"
if [[ ! -f "${PKI_STAGING}/${MGMT_CSR_FILE}" ]] ; then
    sudo keytool -import -v \
    -noprompt \
    -alias "${TARGET_ENV}" \
    -trustcacerts \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${PKI_STAGING}/${MGMT_KEYSTORE}" \
    -storepass "${STOREPASS}" \
    -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_STAGING}/${MGMT_CSR_FILE}"
    updateJBossOwnership

    echo
    echo "Generate CSR at: '${PKI_STAGING}/${MGMT_CSR_FILE}'"
    cat "${PKI_STAGING}/${MGMT_CSR_FILE}"
else
    echo "Existing CSR at: '${PKI_STAGING}/${MGMT_CSR_FILE}'"
    sudo ls -l "${PKI_STAGING}/${MGMT_CSR_FILE}"
fi

echo
echo "FINISHED"

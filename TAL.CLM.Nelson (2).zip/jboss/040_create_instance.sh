#!/usr/bin/env bash -x
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Create JBoss Instances"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

echo "INSTANCE_NAME='${INSTANCE_NAME}'"
echo "PORT_OFFSET='${PORT_OFFSET}'"

# mv secure_profile standalone

echo -e "JBOSS_HOME: ${JBOSS_HOME}"

sudo cp ${BUILD_SOURCESDIRECTORY}/jboss/files/module.xml ${JBOSS_HOME}/modules/com/sun/tools/javac/main/

## Validate pipeline variables
[[ -e "${INSTANCE_NAME}" ]] && echo "ERROR: Instance Name is empty or not provided." && exit 1;
[[ -e "${PORT_OFFSET}" ]] && echo "ERROR: Port Offset is empty or not provided." && exit 1;
[[ ! "${PORT_OFFSET}" =~ ^-?[0-9]+$ ]] && echo "ERROR: Port Offset invalid - must be numeric: '${PORT_OFFSET}'"
[[ (( "${PORT_OFFSET}" -lt "0" || "${PORT_OFFSET}" -gt "1000" )) ]] && echo "ERROR: Port Offset out of range (0 - 1000): ${PORT_OFFSET}" && exit 1;

if [[ ! -d "${INSTANCES_HOME}" ]]; then
    echo
    echo -e "ERROR: INSTANCES_HOME folder not found at: '${INSTANCES_HOME}'" 
    echo "Exiting..."
    exit 1
fi

echo
echo "createInstance \"${INSTANCE_NAME}\" \"${PORT_OFFSET}\""
createInstance "${INSTANCE_NAME}" "${PORT_OFFSET}"

echo
echo "FINISHED"

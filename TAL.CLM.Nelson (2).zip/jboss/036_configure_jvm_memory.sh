#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Memory Configuration JVM Jboss - Jboss EAP Services"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

echo "JBOSS_HOME='${JBOSS_HOME}'"
echo "FINEOS_WEB_APP_BASE='${FINEOS_WEB_APP_BASE}'"
echo "TARGET_ENV='${TARGET_ENV}'"
#echo "MAX_METASPACE_SIZE=${MAX_METASPACE_SIZE}"
#echo "METASPACE_SIZE=${METASPACE_SIZE}"
#echo "XMS_SIZE=${XMS_SIZE}"
#echo "XMX_SIZE=${XMX_SIZE}"
#echo "OLD_MAX_METASPACE_SIZE=${OLD_MAX_METASPACE_SIZE}"
#echo "OLD_METASPACE_SIZE=${OLD_METASPACE_SIZE}"
#echo "OLD_XMS_SIZE=${OLD_XMS_SIZE}"
#echo "OLD_XMX_SIZE=${OLD_XMX_SIZE}"



## Validate pipeline variables
#[[ -e "${JBOSS_HOME}" ]] && echo "ERROR: Jboss Home is empty or not provided." && exit 1;
#[[ -e "${FINEOS_WEB_APP_BASE}" ]] && echo "ERROR: FINEOS_WEB_APP_BASE is empty or not provided." && exit 1;
#[[ -e "${TARGET_ENV}" ]] && echo "ERROR: TARGET_ENV is empty or not provided." && exit 1;

if [[ ! -d "${JBOSS_HOME}" ]]; then
    echo
    echo -e "ERROR: JBOSS_HOME folder not found at: '${JBOSS_HOME}'" 
    echo "Exiting..."
    exit 1
fi

#if [[ ! -d "${FINEOS_WEB_APP_BASE}" ]]; then
#    echo
#    echo -e "ERROR: FINEOS WEB APP BASE folder not found at: '${FINEOS_WEB_APP_BASE}'" 
#    echo "Exiting..."
#    exit 1
#fi

# MaxMetaspaceSize:
cd $JBOSS_HOME/bin
grep ":MaxMetaspaceSize=" *
sudo sed -i 's|MaxMetaspaceSize=256m|MaxMetaspaceSize=512m|g' appclient.conf
sudo sed -i 's|MaxMetaspaceSize=256m|MaxMetaspaceSize=512m|g' appclient.conf.bat
sudo sed -i 's|MaxMetaspaceSize=256m|MaxMetaspaceSize=512m|g' appclient.conf.ps1
sudo sed -i 's|MaxMetaspaceSize=256m|MaxMetaspaceSize=512m|g' domain.conf
sudo sed -i 's|MaxMetaspaceSize=256m|MaxMetaspaceSize=512m|g' domain.conf.bat
sudo sed -i 's|MaxMetaspaceSize=256m|MaxMetaspaceSize=512m|g' domain.conf.ps1
sudo sed -i 's|MaxMetaspaceSize=256m|MaxMetaspaceSize=512m|g' standalone.conf
sudo sed -i 's|MaxMetaspaceSize=256m|MaxMetaspaceSize=512m|g' standalone.conf.bat
sudo sed -i 's|MaxMetaspaceSize=256m|MaxMetaspaceSize=512m|g' standalone.conf.ps1

# MetaspaceSize:
grep ":MetaspaceSize=" *
sudo sed -i 's|MetaspaceSize=96M|MetaspaceSize=256M|g' standalone.conf
sudo sed -i 's|MetaspaceSize=96M|MetaspaceSize=256M|g' standalone.conf.bat
sudo sed -i 's|MetaspaceSize=96M|MetaspaceSize=256M|g' standalone.conf.ps1

# Memory
#grep $OLD_XMS_SIZE *
sudo sed -i 's|Xms1303m|Xms2048m|g' standalone.conf
#sudo sed -i 's|${OLD_XMS_SIZE}|${XMS_SIZE}|g' standalone.conf
#sed -i 's|Xms1303m|Xms2048m|g' standalone.conf
#echo "s|${OLD_XMS_SIZE}|${XMS_SIZE}|g"
#echo "sudo sed -i 's|${OLD_XMS_SIZE}|${XMS_SIZE}|g' standalone.conf"
#grep $XMS_SIZE *

#grep $OLD_XMX_SIZE *
sudo sed -i 's|Xmx1303m|Xmx2048m|g' standalone.conf
#grep $XMX_SIZE *

# Configure the Http & Https Listener max parameters to 5000
cd $JBOSS_HOME/standalone/configuration
sudo sed -i -e 's/http-listener name="default" socket-binding="http" redirect-socket="https" enable-http2="true"/http-listener name="default" socket-binding="http" redirect-socket="https" enable-http2="true" max-parameters="5000"/' standalone-full.xml
sudo sed -i -e 's/https-listener name="https" socket-binding="https" security-realm="ApplicationRealm" enable-http2="true"/https-listener name="https" socket-binding="https" security-realm="ApplicationRealm" enable-http2="true" max-parameters="5000"/' standalone-full.xml


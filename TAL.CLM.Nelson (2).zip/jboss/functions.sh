#!/bin/bash -xv

function createInstance {
    INSTANCE_NAME=$1
    PORT_OFFSET=$2

    echo
    echo -e "------------------------------------------------------------------------------"
    echo -e "Create Instance: '${INSTANCE_NAME}'"
    echo -e "------------------------------------------------------------------------------"

    echo
    echo -e "Ensure the target instance folder location does not already exist."
    [[ -e "${INSTANCE_NAME}" ]] && echo "ERROR: Instance Name is empty or not provided." && exit 1;

    if [[ -d "${INSTANCES_HOME}/${INSTANCE_NAME}" ]]; then
      echo -e "WARNING: Instance '${INSTANCE_NAME}' not created."
      echo -e "Instance already exists and is not empty at: '${INSTANCES_HOME}/${INSTANCE_NAME}'"
      exit
    fi

    echo
    echo -e "Checks passed. Creating instance from secure profile..."
	
    ## Remove prior work
	
    # [[ -d ${JBOSS_HOME}/${JBOSS_VERSION}/secure_profile ]] && \
    echo "Removing folder: ${JBOSS_HOME}/${JBOSS_VERSION}/secure_profile"
    sudo rm -Rf ${JBOSS_HOME}/secure_profile
	
    # [[ -d ${JBOSS_HOME}/${JBOSS_VERSION}/standalone ]]     && \
    echo "Removing folder: ${JBOSS_HOME}/${JBOSS_VERSION}/standalone"
    sudo rm -Rf ${JBOSS_HOME}/standalone

	# Extract contents of zip file
	echo "Extracting secure profile archive: ${JBOSS_HOME}/${JBOSS_VERSION}-secure-profile.zip"
    echo "[BEFORE UNZIP] ls -l  ${JBOSS_HOME}/${JBOSS_VERSION}-secure-profile.zip"
    ls -l  ${JBOSS_HOME}

	echo "sudo unzip ${JBOSS_HOME}/${JBOSS_VERSION}-secure-profile.zip -d ${JBOSS_HOME}"
	sudo unzip ${JBOSS_HOME}/TAL-${JBOSS_VERSION}-secure-profile.zip -d ${JBOSS_HOME}/
 
	echo "sudo mv ${JBOSS_HOME}/${JBOSS_VERSION}/secure_profile ${JBOSS_HOME}/${JBOSS_VERSION}/standalone"
    sudo mv ${JBOSS_HOME}/secure_profile ${JBOSS_HOME}/standalone
    updateJBossOwnership

    echo "[AFTER MV] ls -l  ${JBOSS_HOME}"
    ls -l  ${JBOSS_HOME}

    echo "[AFTER MV] ls -l  ${JBOSS_HOME}/${JBOSS_VERSION}"
    ls -l  ${JBOSS_HOME}/${JBOSS_VERSION}

    # Move profile into place
    sudo cp -R ${JBOSS_HOME}/standalone ${INSTANCES_HOME}/${INSTANCE_NAME}
    updateJBossOwnership

    # installKeystoresFromPKIHome ${INSTANCE_NAME}

    openJBossPorts ${INSTANCE_NAME} ${PORT_OFFSET}
    sudo firewall-cmd --list-all

}

function updateJBossOwnership {
    echo -e "Updating file ownership for JBoss directory to '${JBOSS_USER-jboss}:${JBOSS_USER-jboss}'"
    sudo chown -R ${JBOSS_USER-jboss}:${JBOSS_USER-jboss} "${JBOSS_BASE}"
}

function executeAdminCLI {
    SCRIPT=$1
    echo 
    echo "------------------------------------------------------------------------------"
    echo "FUNCTION executeAdminCLI: Execute JBoss CLI script in admin mode"
    echo "------------------------------------------------------------------------------"

    [[ -e "${SCRIPT}" ]] && echo -e "\nERROR: SCRIPT is empty.\n" && return 1;

    sudo su -c "${JBOSS_HOME}/bin/jboss-cli.sh --no-color-output" ${JBOSS_USER-jboss} <<EOF
embed-server --server-config=standalone-full.xml
${SCRIPT}
stop-embedded-server
EOF
    
}

function executeInstanceCLI {
    local INSTANCE_NAME=$1
    local PORT=$2
    local SCRIPT=$3
    local THIS_HOST=`hostname -f`
    # PORT=$(( 8443 + $OFFSET ))

    echo 
    echo "------------------------------------------------------------------------------"
    echo "FUNCTION executeAdminCLI: Execute JBoss CLI script in admin mode"
    echo "------------------------------------------------------------------------------"
    echo "JBOSS_CONFIG_FILE=${JBOSS_CONFIG_FILE}"
    echo "INSTANCE_NAME=${INSTANCE_NAME}"
    echo "THIS_HOST=${THIS_HOST}"
    echo "PORT=${PORT}"
    echo "SCRIPT=${SCRIPT}"
    echo "JBOSS_VERSION=${JBOSS_VERSION}"

    [[ -e "${SCRIPT}" ]] && echo -e "\nERROR: SCRIPT is empty.\n" && return 1;

    # sudo su -c "${JBOSS_HOME}/bin/jboss-cli.sh --no-color-output --user=${JBOSS_ADMIN_USER} --password=${JBOSS_ADMIN_PASSWORD} --connect --controller=remote+https://localhost:${PORT} " ${JBOSS_USER-jboss} <<EOF
    # sudo su -c "${JBOSS_HOME}/bin/jboss-cli.sh --no-color-output --user=${JBOSS_ADMIN_USER} --password=${JBOSS_ADMIN_PASSWORD} --connect --controller=remote+https://0.0.0.0:${PORT} " ${JBOSS_USER-jboss} <<EOF
    echo P | ${JBOSS_HOME}/bin/jboss-cli.sh -Djavax.net.ssl.trustStore=${PKI_HOME}/identity.jks --no-color-output --user=${JBOSS_ADMIN_USER} --password=${JBOSS_ADMIN_PASSWORD} --connect --controller=remote+https://0.0.0.0:${PORT} <<EOF
echo "INSIDE executeInstanceCLI"
${SCRIPT}
reload
EOF
updateJBossOwnership
}

function startInstance {
    INSTANCE_NAME=$1
    PORT_OFFSET=$2
    #  echo -e "Starting jboss service '${INSTANCE_NAME}..."
    #  sudo systemctl start jboss-eap-${INSTANCE_NAME}.service

    ## TO DO: Resolve systemd issues (write custom unit file) to enable JBoss to run and be managedd as a service.
    ## Then, enable the systemctl command and remove the following "nohup" command
    #  echo -e "Starting jboss service '${INSTANCE_NAME} using NOHUP (Temporary approach)"
    #  sudo systemctl start jboss-eap-${INSTANCE_NAME}.service
    
    # TEMPORARY: Run JBoss with "nohup"
    cd ${JBOSS_HOME}
    CMD="nohup bin/standalone.sh -b=0.0.0.0 -bmanagement=0.0.0.0 -c=standalone-full.xml -DXms4G -DXmx4G -DXX:MaxMetaspaceSize=1g -Djboss.server.base.dir=${INSTANCES_HOME}/${INSTANCE_NAME} -Djava.net.preferIPv4Stack=true -Djboss.socket.binding.port-offset=${PORT_OFFSET} > ${INSTANCES_HOME}/console-logs/${INSTANCE_NAME}.log &"
    sudo su -c "${CMD}" ${JBOSS_USER}

    
}

function stopInstance {
    INSTANCE_NAME=$1
    PORT_OFFSET=$2

    echo "Attempting to kill process for instance '${INSTANCE_NAME}' on port-offset '${PORT_OFFSET}'"
    PID=$(pgrep -a java | grep "${JBOSS_BASE}" | grep "/instances/${JBOSS_VERSION}/${INSTANCE_NAME}" | grep "port-offset=${PORT_OFFSET}" | awk '{ print $1 }' )

    if [[ -z "${PID}" ]]
    then
        echo "Instance '${INSTANCE_NAME}' with port offset '${PORT_OFFSET}' not found."
    else
        echo "Found PID: $PID."
        sudo kill -9 $PID
        echo "Killed $PID."
    fi
}

function checkoutKeystoresToPKIHome {
    INSTANCE_NAME=$1

    SOURCE_FOLDER="${INSTANCES_HOME}/${INSTANCE_NAME}/configuration"
    TARGET_FOLDER="${PKI_HOME}/${INSTANCE_NAME}"

    echo
    echo -e "------------------------------------------------------------------------------"
    echo -e "Checkout keystores to PKI Home for instance: '${INSTANCE_NAME}'"
    echo -e "------------------------------------------------------------------------------"
    echo -e "Source folder: '${SOURCE_FOLDER}'"
    echo -e "Target folder: '${TARGET_FOLDER}'"

    echo
    echo -e "Ensure the source and target folders exist."
    if [[ ! -d "${SOURCE_FOLDER}" ]]; then
        echo
        echo -e "WARNING: Source folder not found at: '${SOURCE_FOLDER}'" 
        echo "Creating..."
        sudo mkdir -p "${SOURCE_FOLDER}"
    fi
    if [[ ! -d "${TARGET_FOLDER}" ]]; then
        echo
        echo -e "WARNING: Target folder not found at: '${TARGET_FOLDER}'" 
        echo "Creating..."
        sudo mkdir -p "${TARGET_FOLDER}"
    fi
    updateJBossOwnership

    echo
    echo -e "Checks passed. Checking out keystores..."
    sudo cp -Rf ${SOURCE_FOLDER}/*.jks ${TARGET_FOLDER}/
    echo -e "Checks passed. Moving any CSRs to Home..."
    sudo mv -f ${SOURCE_FOLDER}/*.csr ${TARGET_FOLDER}/
    sudo touch ${TARGET_FOLDER}/.lockfile
    updateJBossOwnership
}

function installKeystoresFromPKIHome {
    INSTANCE_NAME=$1

    SOURCE_FOLDER="${PKI_HOME}"
    TARGET_FOLDER="${INSTANCES_HOME}/${INSTANCE_NAME}/configuration"

    echo
    echo -e "------------------------------------------------------------------------------"
    echo -e "Install keystores from PKI Home for instance: '${INSTANCE_NAME}'"
    echo -e "------------------------------------------------------------------------------"
    echo -e "Source folder: '${SOURCE_FOLDER}'"
    echo -e "Target folder: '${TARGET_FOLDER}'"

    echo
    echo -e "Ensure the source and target folders exist."
    if [[ ! -d "${SOURCE_FOLDER}" ]]; then
        echo
        echo -e "ERROR: Source folder not found at: '${SOURCE_FOLDER}'" 
        echo "Exiting..."
        exit 1
    fi

    if [[ ! -d "${TARGET_FOLDER}" ]]; then
        echo
        echo -e "ERROR: Target folder not found at: '${TARGET_FOLDER}'" 
        echo "Exiting..."
        exit 1
    fi

    echo
    echo -e "Checks passed. Installing keystores..."
    sudo cp -Rf ${SOURCE_FOLDER}/*.jks ${TARGET_FOLDER}/

    updateJBossOwnership
}

function removeInstance {
    INSTANCE_NAME=$1
    PORT_OFFSET=$2

    echo

    [[ -e "${INSTANCE_NAME}" ]] && echo "ERROR: Instance Name is empty or not provided." && exit;

    if [[ ! -d "${INSTANCES_HOME}/${INSTANCE_NAME}" ]]; then
      echo -e "WARNING: Instance '${INSTANCE_NAME}'' not found."
      echo -e "Instance folder '${INSTANCE_NAME}' not found at: '${INSTANCES_HOME}'"
      exit
    else
        echo -e "Creating service: $INSTANCE_NAME (port-offset: $PORT_OFFSET)..."
    fi

    sudo rm -Rf ${INSTANCES_HOME}/${INSTANCE_NAME}

    closeJBossPorts ${INSTANCE_NAME} ${PORT_OFFSET}

    sudo firewall-cmd --list-all
}

function openJBossPorts {
    INSTANCE_NAME=$1
    PORT_OFFSET=$2

    [[ -e ${INSTANCE_NAME} ]] && echo "ERROR: INSTANCE_NAME is empty"
    [[ -e ${PORT_OFFSET} ]] && echo "ERROR: PORT_OFFSET is empty"

    PORT_HTTP=$((8080 + ${PORT_OFFSET}))
    PORT_HTTPS=$((8443 + ${PORT_OFFSET}))
    PORT_MGMT_HTTP=$((9990 + ${PORT_OFFSET}))
    PORT_MGMT_HTTPS=$((9993 + ${PORT_OFFSET}))

    echo -e "Opening ports for instance: '$INSTANCE_NAME' using port-offset of ${PORT_OFFSET}"

    echo "HTTP port ${PORT_HTTP} (8080+100)"
    sudo firewall-cmd --zone=public --permanent --add-port ${PORT_HTTP}/tcp

    echo "HTTP port ${PORT_HTTPS} (8443+100)"
    sudo firewall-cmd --zone=public --permanent --add-port ${PORT_HTTPS}/tcp

    echo "Management HTTP port ${PORT_MGMT_HTTP} (9990+100)"
    sudo firewall-cmd --zone=public --permanent --add-port ${PORT_MGMT_HTTP}/tcp

    echo "Management HTTP port ${PORT_MGMT_HTTPS} (9993+100)"
    sudo firewall-cmd --zone=public --permanent --add-port ${PORT_MGMT_HTTPS}/tcp

    sudo firewall-cmd --reload
    echo 

}

function closeJBossPorts {
    INSTANCE_NAME=$1
    PORT_OFFSET=$2

    [[ -e ${INSTANCE_NAME} ]] && echo "ERROR: INSTANCE_NAME is empty"
    [[ -e ${PORT_OFFSET} ]] && echo "ERROR: PORT_OFFSET is empty"

    PORT_HTTP=$((8080 + ${PORT_OFFSET}))
    PORT_HTTPS=$((8443 + ${PORT_OFFSET}))
    PORT_MGMT_HTTP=$((9990 + ${PORT_OFFSET}))
    PORT_MGMT_HTTPS=$((9993 + ${PORT_OFFSET}))

    echo -e "Closing ports for instance: '$INSTANCE_NAME' using port-offset of ${PORT_OFFSET}"

    sudo firewall-cmd --zone=public --permanent --remove-port ${PORT_HTTP}/tcp
    sudo firewall-cmd --zone=public --permanent --remove-port ${PORT_HTTPS}/tcp
    sudo firewall-cmd --zone=public --permanent --remove-port ${PORT_MGMT_HTTP}/tcp
    sudo firewall-cmd --zone=public --permanent --remove-port ${PORT_MGMT_HTTPS}/tcp

    sudo firewall-cmd --reload
    echo 

}

function isValidPortOffset {
       PORT_OFFSET=$1
}

#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Apply Security Hardening (Legacy)"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

echo 
echo "------------------------------------------------------------------------------"
echo "Backup the 'standalone' folder"
echo "------------------------------------------------------------------------------"
sudo su -c "cp -R ${JBOSS_HOME}/standalone ${JBOSS_HOME}/standalone_patched_unhardened" ${JBOSS_USER:-jboss}

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Disable Management Console"
# echo "(A safety measure that can be enabled when EAP is secured)"
# echo "------------------------------------------------------------------------------"
# SCRIPT=$(cat <<END_OF_SCRIPT
#     /core-service=management/management-interface=http-interface/:write-attribute(name=console-enabled,value=false)
#     reload --admin-only=true
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Disable remote JMX"
# echo "(A safety measure that can be enabled when EAP is secured)"
# echo "------------------------------------------------------------------------------"
# SCRIPT=$(cat <<END_OF_SCRIPT
#     /subsystem=jmx/remoting-connector=jmx/:remove
#     reload --admin-only=true
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Elytron: Disable silent local authentication with the JBoss CLI"
# echo "------------------------------------------------------------------------------"
# SCRIPT=$(cat <<END_OF_SCRIPT
#     if (result.mechanism-name == JBOSS-LOCAL-USER) of /subsystem=elytron/sasl-authentication-factory=management-sasl-authentication:list-get(name=mechanism-configurations,index=0)
#         /subsystem=elytron/sasl-authentication-factory=management-sasl-authentication:list-remove(name=mechanism-configurations,index=0)
#     else
#         echo "Silent local authentication mechanism not detected at index 0."
#     end-if
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Elytron: Enable silent local authentication with the JBoss CLI"
# echo "------------------------------------------------------------------------------"
# SCRIPT=$(cat <<END_OF_SCRIPT
#     #/subsystem=elytron/sasl-authentication-factory=management-sasl-authentication:list-add(name=mechanism-configurations,value={mechanism-name=JBOSS-LOCAL-USER})
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Disable the deployment scanner (Can be enabled in DEV)"
echo "------------------------------------------------------------------------------"
echo 
SCRIPT=$(cat <<END_OF_SCRIPT
    /subsystem=deployment-scanner:remove()
    /extension=org.jboss.as.deployment-scanner:remove()
    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Disable subsystems that are not required"
echo "------------------------------------------------------------------------------"
echo "Remove 'jaxrs', 'resteasy' and 'webservices' subsystems if detected."
SCRIPT=$(cat <<END_OF_SCRIPT
    if (outcome == success) of /subsystem=jaxrs:read-resource
        /subsystem=jaxrs:remove()
    else
        echo "Subsystem 'jaxrs' not detected"
    end-if
    if (outcome == success) of /subsystem=resteasy:read-resource
        /subsystem=resteasy:remove()
    else
        echo "Subsystem 'resteasy' not detected"
    end-if
    if (outcome == success) of /subsystem=webservices:read-resource
        /subsystem=webservices:remove()
    else
        echo "Subsystem 'webservices' not detected"
    end-if
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Configure Identity Provider (IdP)"
echo "------------------------------------------------------------------------------"
echo 
THIS_HOST=`hostname -f`
echo "THIS_HOST=${THIS_HOST}"
SCRIPT=$(cat <<END_OF_SCRIPT

    # 7.2.1 Enabling PicketLink extension
    /extension=org.wildfly.extension.picketlink:add

    # 7.2.2 Configuring the security domain
    /subsystem=security/security-domain=sp:add()
    /subsystem=security/security-domain=sp/authentication=classic:add
    /subsystem=security/security-domain=sp/authentication=classic/login-module=org.picketlink.identity.federation.bindings.jboss.auth.SAML2LoginModule:add(code=org.picketlink.identity.federation.bindings.jboss.auth.SAML2LoginModule,flag=optional)

    # Appendix F: SAML Role Mapping
    # NOTE: This step is only required becasue a SAML token containing 
    #       the role "fineosaccessrole" is not provided.
    /subsystem=security/security-domain=sp/authentication=classic/login-module=RoleMapping:add(code=RoleMapping, flag=optional, module-options=[ "replaceRole"=>"true", "rolesProperties"=>"roles.properties"])
 
    # 7.2.3 Configuring PicketLink subsystem

    ### 7.2.3.1 Add the subsystem 
    /subsystem=picketlink-federation:add

    ### 7.2.3.2 Add a named federation to the subsystem 
    /subsystem=picketlink-federation/federation=FINEOSIdP:add

    ### 7.2.3.3 Add the identity provider information to the subsystem 
    /subsystem=picketlink-federation/federation=FINEOSIdP/identity-provider=ADFS:add( \
    url="https://loginuat.tal.com.au/saml/idp/profile/redirectorpost/sso",\
    security-domain="sp",\
    external="true",\
    encrypt="true",\
    support-signatures="false"\
    )
    /subsystem=picketlink-federation/federation=FINEOSIdP/identity-provider=ADFS/trust-domain="loginuat.tal.com.au":add


    /subsystem=picketlink-federation/federation=FINEOSIdP/identity-provider=ADFS/trust-domain="https://${IDP_HOST}:${IDP_PORT_HTTPS}":add
    /subsystem=picketlink-federation/federation=FINEOSIdP/service-provider=${INSTANCE_NAME}:add( \
    url="https://${IDP_HOST}:${IDP_PORT_HTTPS}", \
    security-domain="sp", \
    post-binding="false", \
    support-signatures="false", \
    strict-post-binding="false" \
    )
    /subsystem=picketlink-federation/federation=FINEOSIdP/service-provider=${INSTANCE_NAME}/handler=SAMLLogout:add(class-name="org.picketlink.identity.federation.web.handlers.saml2.SAML2LogOutHandler")
    /subsystem=picketlink-federation/federation=FINEOSIdP/service-provider=${INSTANCE_NAME}/handler=SAMLSigGen:add(class-name="org.picketlink.identity.federation.web.handlers.saml2.SAML2SignatureGenerationHandler")
    /subsystem=picketlink-federation/federation=FINEOSIdP/service-provider=${INSTANCE_NAME}/handler=SAMLAuth:add(class-name="org.picketlink.identity.federation.web.handlers.saml2.SAML2AuthenticationHandler")

    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"


echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Generate a SAML Role Mapping file 'roles.properties'"
echo "------------------------------------------------------------------------------"
echo 

sudo echo "CN\=${AD_GROUP_FINEOS_ACCESS_ROLE},OU\=Security\ Groups,OU\=Tower,DC\=lan=fineosaccessrole" | sudo tee ${JBOSS_HOME}/standalone/configuration/roles.properties
updateJBossOwnership

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Ensure the Management Interfaces bind to HTTPS"
echo "------------------------------------------------------------------------------"
echo 
SCRIPT=$(cat <<END_OF_SCRIPT
    /core-service=management/management-interface=http-interface:write-attribute(name=secure-socket-binding, value=management-https)
    /core-service=management/management-interface=http-interface:undefine-attribute(name=socket-binding)
    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Create Security Realm named 'ManagementRealmHTTPS'"
echo "------------------------------------------------------------------------------"
sudo su -c "touch ${JBOSS_HOME}/standalone/configuration/https-mgmt-users.properties" ${JBOSS_USER:-jboss}
SCRIPT=$(cat <<END_OF_SCRIPT
    /core-service=management/security-realm=ManagementRealmHTTPS:add
    /core-service=management/security-realm=ManagementRealmHTTPS/authentication=properties:add(path=https-mgmt-users.properties,relative-to=jboss.server.config.dir)
    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "Add Management User."
echo "------------------------------------------------------------------------------"
sudo su -c "${JBOSS_HOME}/bin/add-user.sh -up ${JBOSS_HOME}/standalone/configuration/https-mgmt-users.properties -r ManagementRealmHTTPS -b --user ${JBOSS_ADMIN_USER} --password ${JBOSS_ADMIN_PASSWORD} --role admin" ${JBOSS_USER:-jboss}

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Configure Management Interfaces"
echo "- Configure the management interfaces to use the new security realm."
echo "- Configure the management interfaces to use the keystore."
echo "------------------------------------------------------------------------------"
echo "KEYSTORE.....: '${KEYSTORE}'"
echo "MGMT_KEYSTORE: '${MGMT_KEYSTORE}'"
SCRIPT=$(cat <<END_OF_SCRIPT
    /core-service=management/management-interface=http-interface:write-attribute(name=security-realm,value=ManagementRealmHTTPS)
    /core-service=management/security-realm=ManagementRealmHTTPS/server-identity=ssl:add(keystore-path=${PKI_HOME}/${MGMT_KEYSTORE}, keystore-password=${STOREPASS}, alias=${TARGET_ENV})
    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Add Security Realm 'HTTPSRealm'"
echo "------------------------------------------------------------------------------"
echo 
SCRIPT=$(cat <<END_OF_SCRIPT
    batch
    /core-service=management/security-realm=ApplicationRealm/server-identity=ssl:remove()
    /core-service=management/security-realm=ApplicationRealm/server-identity=ssl:add(keystore-path=${PKI_HOME}/${KEYSTORE}, keystore-password=${STOREPASS}, alias=${TARGET_ENV})
    /core-service=management/security-realm=ApplicationRealm/server-identity=ssl:undefine-attribute(name=generate-self-signed-certificate-host)
    /core-service=management/security-realm=ApplicationRealm/server-identity=ssl:write-attribute(name=enabled-protocols,value=["TLSv1.2"])

#    /core-service=management/security-realm=HTTPSRealm/server-identity=ssl:remove()
#    /core-service=management/security-realm=HTTPSRealm:add
#    /core-service=management/security-realm=HTTPSRealm/server-identity=ssl:add(keystore-path=${KEYSTORE}, keystore-relative-to=jboss.server.config.dir, keystore-password=${STOREPASS}, alias=${TARGET_ENV})
#    /core-service=management/security-realm=HTTPSRealm/server-identity=ssl:undefine-attribute(name=generate-self-signed-certificate-host)
#    /core-service=management/security-realm=HTTPSRealm/server-identity=ssl:write-attribute(name=enabled-protocols,value=["TLSv1.2"])
#    /subsystem=undertow/server=default-server/https-listener=https:write-attribute(name=security-realm, value=HTTPSRealm)
    run-batch
    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "Cleanup after executing CLI script."
sudo rm -Rf ${JBOSS_HOME}/standalone/configuration/standalone_xml_history
sudo rm -Rf ${JBOSS_HOME}/standalone/log
sudo rm -Rf ${JBOSS_HOME}/standalone/data

updateJBossOwnership

echo
echo "FINISHED"

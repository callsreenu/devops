#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Configure JBoss EAP services"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}
JBOSS_GROUP=${JBOSS_GROUP:-jboss}
INSTANCE_NAME=${INSTANCE_NAME}

## Service control Variables ########
PIDFOLDER=/var/run/jboss-eap
STARTUP_WAIT_SECS=300
SHUTDOWN_WAIT=120


function createSystemService {
    INSTANCE_NAME=$1
    PORT_OFFSET=$2
    echo
    echo -e "Creating service: ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME} (port-offset: $PORT_OFFSET)..."

    # Service Config File
    DEFAULT_CONFIG_FILE=${JBOSS_HOME}/bin/init.d/jboss-eap.conf
    INSTANCE_CONFIG_FILE=${JBOSS_HOME}/bin/init.d/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.conf

   # Service Control script
    DEFAULT_SVC_CTL_FILE=${JBOSS_HOME}/bin/init.d/jboss-eap-rhel.sh
    INSTANCE_SVC_CTL_FILE=${JBOSS_HOME}/bin/init.d/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.sh

    echo
    echo "Create Service Config file for '${INSTANCE_NAME}'"
    sudo cp -f "${DEFAULT_CONFIG_FILE}" "${INSTANCE_CONFIG_FILE}"

    [[ -z "${JAVA_HOME}" ]] && export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which javac))))
    echo "JAVA_HOME=${JAVA_HOME}"

    echo
    echo "Create service config file for '${INSTANCE_NAME}'"
    sudo cp -f ${DEFAULT_CONFIG_FILE} ${INSTANCE_CONFIG_FILE}
    sudo sed -i "s|^# default location: /etc/default/jboss-eap|# default location: /etc/default/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}|g" $INSTANCE_CONFIG_FILE  ;
    sudo sed -i "s|^# JAVA_HOME=.*|JAVA_HOME=\"/usr/lib/jvm/java-openjdk\"|g" $INSTANCE_CONFIG_FILE  ;
    sudo sed -i "s|^# JBOSS_HOME=.*|JBOSS_HOME=${JBOSS_HOME}|g" $INSTANCE_CONFIG_FILE  ;
    sudo sed -i "s|^# JBOSS_USER=.*|JBOSS_USER=${JBOSS_USER}|g" $INSTANCE_CONFIG_FILE  ;
    sudo sed -i "s|^# JBOSS_MODE=.*|JBOSS_MODE=standalone|g" $INSTANCE_CONFIG_FILE  ;
    sudo sed -i "s|^# JBOSS_CONFIG=.*|JBOSS_CONFIG=standalone-full.xml|g" $INSTANCE_CONFIG_FILE  ;
    sudo sed -i "s|^# STARTUP_WAIT=.*|STARTUP_WAIT=${STARTUP_WAIT_SECS}|g" $INSTANCE_CONFIG_FILE  ;
    sudo sed -i "s|^# SHUTDOWN_WAIT=.*|SHUTDOWN_WAIT=${SHUTDOWN_WAIT_SECS}|g" $INSTANCE_CONFIG_FILE  ;
    sudo sed -i "s|^# JBOSS_CONSOLE_LOG=.*|JBOSS_CONSOLE_LOG=${INSTANCES_HOME}/console-logs/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.log|g" $INSTANCE_CONFIG_FILE  ;
    sudo sed -i "s|^# JBOSS_OPTS=.*|JBOSS_OPTS=\"-Djboss.node.name=${TARGET_ENV}-${INSTANCE_NAME} -Xms4G -Xmx4G -Djboss.server.base.dir=${INSTANCES_HOME}/${INSTANCE_NAME}/ -b 0.0.0.0 -bmanagement 0.0.0.0  -Djboss.socket.binding.port-offset=${PORT_OFFSET}\"|g" $INSTANCE_CONFIG_FILE  ;

    # cat $INSTANCE_CONFIG_FILE


    ########################################
    # SystemD Unit file
    ########################################
    # NOTE: Deliberately NOT indenting the content with
    # TABs characters that may be converted to EVIL spaces.

    cat << EOF > ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service
[Unit]
Description=JBoss EAP 7.3 (${INSTANCE_NAME}) Systemctl script
After=NetworkManager.service
[Service]
LogLevelMax=6
LogLevel=6
Type=forking
ExecStart=${INSTANCE_SVC_CTL_FILE} start
ExecStop=${INSTANCE_SVC_CTL_FILE} stop
ExecReload=${INSTANCE_SVC_CTL_FILE} restart
PIDFile=/var/run/jboss-eap/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.pid
[Install]
WantedBy=multi-user.target
EOF
    # cat ${JBOSS_HOME}/bin/init.d/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service

    # Copy  Unit File 
    sudo cp -f ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service ${JBOSS_HOME}/bin/init.d/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service
    updateJBossOwnership
    sudo cp -f ${JBOSS_HOME}/bin/init.d/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service /etc/systemd/system/

    # Create Service Control script for this INSTANCE_NAME and make it executable
    echo
    echo "Create service control script for '${INSTANCE_NAME}' and make it executable"
    sudo cp "${DEFAULT_SVC_CTL_FILE}" "${INSTANCE_SVC_CTL_FILE}"
    sudo chmod +x ${INSTANCE_SVC_CTL_FILE}

    sudo sed -i "s|^# processname:.*|# processname: ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}|g" $INSTANCE_SVC_CTL_FILE  ;
    sudo sed -i "s|^# pidfile:.*|# pidfile: /var/run/jboss-eap/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.pid|g" $INSTANCE_SVC_CTL_FILE  ;
    sudo sed -i "s|^# config:.*|# config: /etc/default/jboss-eap-${INSTANCE_NAME}.conf|g" $INSTANCE_SVC_CTL_FILE  ;
    sudo sed -i "s|JBOSS_NAME='jboss-eap'|JBOSS_NAME='${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}'|g" $INSTANCE_SVC_CTL_FILE  ;
    sudo sed -i "s|JBOSS_CONF=.*|JBOSS_CONF='${INSTANCE_CONFIG_FILE}'|g" $INSTANCE_SVC_CTL_FILE  ;
    sudo sed -i "s|JBOSS_PIDFILE=.*|JBOSS_PIDFILE='/var/run/jboss-eap/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.pid'|g" $INSTANCE_SVC_CTL_FILE  ;
    sudo sed -i "s|JBOSS_BASE_DIR=.*|JBOSS_BASE_DIR='${INSTANCES_HOME}/${INSTANCE_NAME}'|g" $INSTANCE_SVC_CTL_FILE  ;

    # cat  ${INSTANCE_SVC_CTL_FILE}

    # Make service control file eecutable
    echo -e "chmod +x ${INSTANCE_SVC_CTL_FILE}"


    # Copy Service Config File to runtime location (/etc/default)
    sudo cp "${INSTANCE_CONFIG_FILE}" /etc/default

    # Change the security context for the service control file (to fix an SELinux issue)
    echo -e "sudo chcon -t bin_t ${INSTANCE_SVC_CTL_FILE}"
    sudo chcon -t bin_t ${INSTANCE_SVC_CTL_FILE}

    # RHEL 7/8 use 'systemctl' instead of the 'chkconfig' and 'service' commands
    echo 
    echo "sudo systemctl disable ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service"
    sudo systemctl disable ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service

    # RHEL 7/8 use 'systemctl' instead of the 'chkconfig' and 'service' commands
    echo 
    echo "sudo systemctl enable ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service"
    sudo systemctl enable ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service

    echo 
    echo "sudo systemctl status ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service"
    sudo systemctl status ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.service
    echo 

    # However RHEL 8 supports chkconfig and automaticlly generates systemd Unit Files
    #echo -e "sudo chkconfig --add /etc/init.d/jboss-eap-${INSTANCE_NAME}.sh"
    #sudo chkconfig --add /etc/init.d/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.sh
    #echo -e "sudo chkconfig ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.sh on"
    #sudo chkconfig ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}.sh on

}

# Ensure the PIDFILE folder is created and owned by the JBoss user
[[ ! -d "$PIDFOLDER}" ]] && sudo mkdir -p "$PIDFOLDER}"
sudo chown -R ${JBOSS_USER}:${JBOSS_USER} "$PIDFOLDER}"

createSystemService frontoffice 100
createSystemService fineosservices 250
createSystemService analytics 300

sudo systemctl daemon-reload

echo
echo -e "Contents of: /etc/default/jboss"
ls -l /etc/default/jboss*

echo
echo -e "Contents of: /etc/systemd/system/jboss"
ls -l /etc/default/jboss*

echo
echo -e "Contents of: /etc/init.d/jboss"
ls -l /etc/init.d/jboss*

echo
echo "FINISHED"


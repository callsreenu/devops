#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Install Red Hat OpenJDK8"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

sudo -S yum -y -q install zip
sudo -S yum -y -q install java-1.8.0-openjdk-devel



# Confirm java / javac available
echo
echo "Confirm: java -version:"
java -version

echo
echo "Confirm: javac -version:"
javac -version

echo
echo "Seting JAVA_HOME"
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which javac))))
echo "JAVA_HOME=$JAVA_HOME"
echo
echo "FINISHED"

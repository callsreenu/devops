#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Import Certificates to APP and/or MGMT keystores"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

echo "INSTANCE_NAME='${INSTANCE_NAME}'"

[[ ! -f "${PKI_HOME}/${APPS_CERT_FILE}" ]] && \
echo -e "Nothing to import" && exit 1;

[[ ! -f "${PKI_HOME}/${MGMT_CERT_FILE}" ]] && \
echo -e "Nothing to import" && exit 1;

echo 
echo "------------------------------------------------------------------------------"
echo "Import certificate to APPS keystore"
echo "------------------------------------------------------------------------------"
if [[ -f "${PKI_HOME}/${APPS_CERT_FILE}" ]] then
do
    sudo keytool -import -v \
    -noprompt \
    -alias "${ALIAS}" \
    -trustcacerts \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${JBOSS_HOME}/standalone/configuration/${KEYSTORE}" \
    -storepass "${STOREPASS}" \
    -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_HOME}/${APPS_CERT_FILE}"
    updateJBossOwnership

    echo
    echo "Imported certificate at: ${APPS_CERT_FILE}"
    cat "${MGMT_CERT_FILE}"

done

echo 
echo "------------------------------------------------------------------------------"
echo "Import certificate to MGMT keystore"
echo "------------------------------------------------------------------------------"
if [[ -f "${PKI_HOME}/${MGMT_CERT_FILE}" ]] then
do
    sudo keytool -import -v \
    -noprompt \
    -alias "${ALIAS}" \
    -trustcacerts \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${JBOSS_HOME}/standalone/configuration/${MGMT_KEYSTORE}" \
    -storepass "${STOREPASS}" \
    -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_HOME}/${MGMT_CERT_FILE}"
    updateJBossOwnership

    echo
    echo "Imported certificate at: ${MGMT_CERT_FILE}"
    cat "${MGMT_CERT_FILE}"

done

echo
echo "FINISHED"

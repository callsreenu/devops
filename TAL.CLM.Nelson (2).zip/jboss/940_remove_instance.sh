#!/usr/bin/env bash
echo ""
echo "------------------------------------------------------------------------------"
echo "TASK: Remove JBoss Instance"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

echo "INSTANCE_NAME='${INSTANCE_NAME}'"
echo "PORT_OFFSET='${PORT_OFFSET}'"

## Validate pipeline variables
[[ -e "${INSTANCE_NAME}" ]] && echo "ERROR: Instance Name is empty or not provided." && exit 1;
[[ -e "${PORT_OFFSET}" ]] && echo "ERROR: Port Offset is empty or not provided." && exit 1;
[[ ! ${PORT_OFFSET} =~ ^-?[0-9]+$ ]] && echo "ERROR: Port Offset invalid - must be numeric: ${PORT_OFFSET}"
[[ ! (( ${PORT_OFFSET} -ge 0 && ${PORT_OFFSET} -le 1000 )) ]] && echo "ERROR: Port Offset out of range (0 - 1000): ${PORT_OFFSET}" && exit 1;

if [[ ! -d "${INSTANCES_HOME}" ]]; then
    echo
    echo -e "ERROR: INSTANCES_HOME folder not found at: '${INSTANCES_HOME}'" 
    echo "Exiting..."
    exit 1
fi

removeInstance "${INSTANCE_NAME}" "${PORT_OFFSET}"

echo
echo "FINISHED"

#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Install Keystores from PKI Home"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

echo "INSTANCE_NAME='${INSTANCE_NAME}'"

[[ -e "${INSTANCE_NAME}" ]] && echo "ERROR: Instance Name is empty or not provided." && exit 1;

checkoutKeystoreToPKIStaging "${INSTANCE_NAME}"

echo
echo "FINISHED"

#!/usr/bin/env bash

echo "------------------------------------------------------------------------------"
echo "TARGET_ENV: ${TARGET_ENV}"
echo "------------------------------------------------------------------------------"

FILE=/distribution/CERT/${TARGET_ENV}.jks
CERT=${TARGET_ENV}.jks
PKI_PATH=/jboss/pki/jboss-eap-7.3
PKI_PATH_FILE=/jboss/pki/jboss-eap-7.3/${TARGET_ENV}.jks

if [ -f "$FILE" ]; then
        echo "Certificate is Available"
        sudo cp $FILE $PKI_PATH/
        sudo mv $PKI_PATH/identity.jks $PKI_PATH/identity-old.jks && sudo mv $PKI_PATH/applications.jks $PKI_PATH/applications-old.jks
        sudo cp $PKI_PATH/$CERT $PKI_PATH/identity.jks && sudo cp $PKI_PATH/$CERT $PKI_PATH/applications.jks
        sudo chown jboss:jboss $PKI_PATH/identity.jks && sudo chown jboss:jboss $PKI_PATH/applications.jks
        sudo rm -rf $PKI_PATH/$CERT
else
        echo "Certificate is not present, Kindly copy the certificate under the /distribution/CERT/ directory"
fi
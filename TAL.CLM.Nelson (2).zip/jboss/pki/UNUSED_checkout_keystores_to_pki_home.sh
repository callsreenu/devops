#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Checkout Keystores to PKI Home"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

echo "INSTANCE_NAME='${INSTANCE_NAME}'"

[[ -e "${INSTANCE_NAME}" ]] && echo "ERROR: Instance Name is empty or not provided." && exit 1;

if [[ ! -d "${INSTANCES_HOME}/${INSTANCE_NAME}" ]]; then
    echo
    echo -e "ERROR: Source folder not found at: '${INSTANCES_HOME}/${INSTANCE_NAME}'" 
    echo "Exiting..."
    exit 1
fi

checkoutKeystoresToPKIHome "${INSTANCE_NAME}"

echo
echo "FINISHED"

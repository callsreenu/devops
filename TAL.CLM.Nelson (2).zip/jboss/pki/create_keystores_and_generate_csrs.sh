#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Generate Keystore(s) and Certificate Signing Request(s) (CSR)"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

# echo -e "INSTANCE_NAME : ${INSTANCE_NAME}"

echo
echo "------------------------------------------------------------------------------"
echo "Create PKI asset folder"
echo "------------------------------------------------------------------------------"
[[ ! -d "${PKI_HOME}" ]] && sudo mkdir -p "${PKI_HOME}"
updateJBossOwnership

echo 
echo "------------------------------------------------------------------------------"
echo "Application Realm: Generate a keystore"
echo "------------------------------------------------------------------------------"
[[ ! -d "${PKI_HOME}/identity.jks" ]] && sudo keytool -genkeypair -v \
-noprompt \
-alias "${TARGET_ENV}" \
-storetype "${STORETYPE}" \
-keypass "${KEYPASS}" \
-keystore "${PKI_HOME}/applications.jks" \
-storepass "${STOREPASS}" \
-dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
-keyalg RSA -keysize 2048 \
-validity 730 
updateJBossOwnership

echo 
echo "------------------------------------------------------------------------------"
echo "Application Realm: Generate a CSR"
echo "------------------------------------------------------------------------------"
sudo keytool -certreq -v \
-noprompt \
-alias "${TARGET_ENV}" \
-storetype "${STORETYPE}" \
-keypass "${KEYPASS}" \
-keystore "${PKI_HOME}/applications.jks" \
-storepass "${STOREPASS}" \
-dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
-file "${PKI_HOME}/${APPS_CSR_FILE}"
updateJBossOwnership

echo
echo "------------------------------------------------------------------------------"
echo "Application Realm: Generated CSR at: ${APPS_CSR_FILE}"
echo "------------------------------------------------------------------------------"
cat "${APPS_CSR_FILE}"

echo 
echo "------------------------------------------------------------------------------"
echo "Management Realm: Generate a keystore"
echo "------------------------------------------------------------------------------"
[[ ! -d "${PKI_HOME}/identity.jks" ]] && sudo keytool -genkeypair -v \
-noprompt \
-alias "${TARGET_ENV}" \
-storetype "${STORETYPE}" \
-keypass "${KEYPASS}" \
-keystore "${PKI_HOME}/identity.jks" \
-storepass "${STOREPASS}" \
-dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
-keyalg RSA -keysize 2048 \
-validity 730 
updateJBossOwnership

echo 
echo "------------------------------------------------------------------------------"
echo "Management Realm: Generate a CSR"
echo "------------------------------------------------------------------------------"
sudo keytool -certreq -v \
-noprompt \
-alias "${TARGET_ENV}" \
-storetype "${STORETYPE}" \
-keypass "${KEYPASS}" \
-keystore "${PKI_HOME}/identity.jks" \
-storepass "${STOREPASS}" \
-dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
-file "${PKI_HOME}/${MGMT_CSR_FILE}"
updateJBossOwnership

echo
echo "------------------------------------------------------------------------------"
echo "Management Realm: Generated CSR at: ${MGMT_CSR_FILE}"
echo "------------------------------------------------------------------------------"
cat "${MGMT_CSR_FILE}"

echo
echo "FINISHED"


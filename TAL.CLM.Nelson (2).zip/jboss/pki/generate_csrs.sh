#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Generate Certificate Signing Requests (CSRs)"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

echo "INSTANCE_NAME=${INSTANCE_NAME}"
echo "INSTANCE_NAME='${INSTANCE_NAME}'"
echo "TARGET_ENV='${TARGET_ENV}'"
echo "INCLUDE_APPS='${INCLUDE_APPS}'"
echo "INCLUDE_MGMT='${INCLUDE_MGMT}'"

[[ -f "${PKI_HOME}/${APPS_CSR_FILE}" ]] && echo -e "Target APPS CSR file already exists - deleting" && \
sudo rm -f "${PKI_HOME}/${APPS_CSR_FILE}";

[[ -f "${PKI_HOME}/${MGMT_CSR_FILE}" ]] && echo -e "Target MGMT CSR file already exists - deleting" && \
sudo rm -f "${PKI_HOME}/${MGMT_CSR_FILE}";

echo 
echo "------------------------------------------------------------------------------"
echo "Generate APPS CSR"
echo "------------------------------------------------------------------------------"
if [[ ! -f "${PKI_HOME}/${APPS_CSR_FILE}" ]] ; then
    sudo keytool -certreq -v \
    -noprompt \
    -alias "${TARGET_ENV}" \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${PKI_HOME}/${KEYSTORE}" \
    -storepass "${STOREPASS}" \
    -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_HOME}/${APPS_CSR_FILE}"
    updateJBossOwnership

    echo
    echo "Generate CSR at: '${PKI_HOME}/${APPS_CSR_FILE}'"
    cat "${PKI_HOME}/${APPS_CSR_FILE}"
else
    echo "Existing CSR at: '${PKI_HOME}/${APPS_CSR_FILE}'"
    sudo ls -l "${PKI_HOME}/${APPS_CSR_FILE}"
fi

echo 
echo "------------------------------------------------------------------------------"
echo "Generate MGMT CSR"
echo "------------------------------------------------------------------------------"
if [[ ! -f "${PKI_HOME}/${MGMT_CSR_FILE}" ]] ; then
    sudo keytool -certreq -v \
    -noprompt \
    -alias "${TARGET_ENV}" \
    -trustcacerts \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${PKI_HOME}/${MGMT_KEYSTORE}" \
    -storepass "${STOREPASS}" \
    -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_HOME}/${MGMT_CSR_FILE}"
    updateJBossOwnership

    echo
    echo "Generate CSR at: '${PKI_HOME}/${MGMT_CSR_FILE}'"
    cat "${PKI_HOME}/${MGMT_CSR_FILE}"
else
    echo "Existing CSR at: '${PKI_HOME}/${MGMT_CSR_FILE}'"
    sudo ls -l "${PKI_HOME}/${MGMT_CSR_FILE}"
fi

echo
echo "FINISHED"

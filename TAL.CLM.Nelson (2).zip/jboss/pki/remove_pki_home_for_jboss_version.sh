#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Remove PKI Staging for JBoss Version (ALL instances)"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

echo
echo "------------------------------------------------------------------------------"
echo "Remove PKI_HOME folder"
echo "------------------------------------------------------------------------------"
echo -e "PKI_HOME folder '${PKI_HOME}'"
echo -e "PKI_HOME folder '${JBOSS_BASE}/pki/${JBOSS_VERSION}'"

echo "Removing PKI_HOME folder: ${JBOSS_BASE}/pki/${JBOSS_VERSION}" 
sudo rm -Rf "${JBOSS_BASE}/pki/${JBOSS_VERSION}"

echo 
echo "FINISHED"

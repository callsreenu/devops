#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Import Certificates to APP and/or MGMT keystores"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

echo -e "RootCA certificate '${PKI_HOME}/${ROOT_CA_CERT_FILE}' to import";
echo -e "IntermediateCA certificate '${INTERMEDIATE_CA_CERT_FILE}' to import";
echo -e "Certificate to import: '${PKI_HOME}/${APPS_CERT_FILE}'";
echo -e "Certificate to import: '${PKI_HOME}/${MGMT_CERT_FILE}'";
echo -e "KEYPASS: '${KEYPASS}'";
echo -e "STOREPASS: '${STOREPASS}'";


[[ ! -f "${PKI_HOME}/${ROOT_CA_CERT_FILE}" ]] \
&& echo -e "No RootCA certificate '${PKI_HOME}/${ROOT_CA_CERT_FILE}' to import";

[[ ! -f "${PKI_HOME}/${INTERMEDIATE_CA_CERT_FILE}" ]] \
&& echo -e "No IntermediateCA certificate '${INTERMEDIATE_CA_CERT_FILE}' to import";

[[ ! -f "${PKI_HOME}/${APPS_CERT_FILE}" ]] \
&& echo -e "Nothing to import ('${PKI_HOME}/${APPS_CERT_FILE}')"

[[ ! -f "${PKI_HOME}/${MGMT_CERT_FILE}" ]] \
&& echo -e "Nothing to import ('${PKI_HOME}/${MGMT_CERT_FILE}')"

echo 
echo "------------------------------------------------------------------------------"
echo "Import RootCA certificate to APPS keystore"
echo "------------------------------------------------------------------------------"
if [[ -f "${PKI_HOME}/${ROOT_CA_CERT_FILE}" ]] 
then
    sudo keytool -import -v \
    -noprompt \
    -alias root\
    -trustcacerts \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${PKI_HOME}/${KEYSTORE}" \
    -storepass "${STOREPASS}" \
    -file "${PKI_HOME}/${ROOT_CA_CERT_FILE}"
    # -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    updateJBossOwnership

    echo
    echo "Imported RootCA certificate at: ${PKI_HOME}/${ROOT_CA_CERT_FILE}"
    cat "${PKI_HOME}/${ROOT_CA_CERT_FILE}"

fi

echo 
echo "------------------------------------------------------------------------------"
echo "Import IntermediateCA certificate to APPS keystore"
echo "------------------------------------------------------------------------------"
if [[ -f "${PKI_HOME}/${INTERMEDIATE_CA_CERT_FILE}" ]] 
then

    echo "101"

    sudo keytool -importcert -v \
    -noprompt \
    -alias intermediate \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${PKI_HOME}/${KEYSTORE}" \
    -storepass "${STOREPASS}" \
    -file "${PKI_HOME}/${INTERMEDIATE_CA_CERT_FILE}"

    echo "102"
    
    updateJBossOwnership

    echo "103"
    
    echo
    echo "Imported IntermediateCA certificate at: ${PKI_HOME}/${INTERMEDIATE_CA_CERT_FILE}"
    cat "${PKI_HOME}/${INTERMEDIATE_CA_CERT_FILE}"
    echo "4"
fi


echo 
echo "------------------------------------------------------------------------------"
echo "Import certificate to APPS keystore"
echo "------------------------------------------------------------------------------"
if [[ -f "${PKI_HOME}/${APPS_CERT_FILE}" ]] 
then
    sudo keytool -import -v \
    -noprompt \
    -alias "${ALIAS}" \
    -trustcacerts \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${PKI_HOME}/${KEYSTORE}" \
    -storepass "${STOREPASS}" \
    -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_HOME}/${APPS_CERT_FILE}"
    updateJBossOwnership

    echo
    echo "Imported certificate at: ${PKI_HOME}/${APPS_CERT_FILE}"
    cat "${PKI_HOME}/${APPS_CERT_FILE}"

fi

echo "400"

echo 
echo "------------------------------------------------------------------------------"
echo "Import IntermediateCA certificate to MGMT keystore"
echo "------------------------------------------------------------------------------"
if [[ -f "${PKI_HOME}/${INTERMEDIATE_CA_CERT_FILE}" ]] 
then
    sudo keytool -importcert -v \
    -noprompt \
    -alias intermediate \
    # -trustcacerts \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${PKI_HOME}/${MGMT_KEYSTORE}" \
    -storepass "${STOREPASS}" \
    # -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_HOME}/${INTERMEDIATE_CA_CERT_FILE}"
    updateJBossOwnership

    echo
    echo "Imported IntermediateCA certificate at: ${PKI_HOME}/${INTERMEDIATE_CA_CERT_FILE}"
    cat "${PKI_HOME}/${INTERMEDIATE_CA_CERT_FILE}"

# fi

echo "500"

echo 
echo "------------------------------------------------------------------------------"
echo "Import RootCA certificate to MGMT keystore"
echo "------------------------------------------------------------------------------"
if [[ -f "${PKI_HOME}/${ROOT_CA_CERT_FILE}" ]] 
then
    sudo keytool -import -v \
    -noprompt \
    -alias root\
    -trustcacerts \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${PKI_HOME}/${MGMT_KEYSTORE}" \
    -storepass "${STOREPASS}" \
    # -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_HOME}/${ROOT_CA_CERT_FILE}"
    updateJBossOwnership

    echo
    echo "Imported RootCA certificate at: ${PKI_HOME}/${ROOT_CA_CERT_FILE}"
    cat "${PKI_HOME}/${ROOT_CA_CERT_FILE}"

fi

echo "600"

echo 
echo "------------------------------------------------------------------------------"
echo "Import certificate to MGMT keystore"
echo "------------------------------------------------------------------------------"
if [[ -f "${PKI_HOME}/${MGMT_CERT_FILE}" ]] 
then
    sudo keytool -import -v \
    -noprompt \
    -alias "${ALIAS}" \
    -trustcacerts \
    -storetype jks \
    -keypass "${KEYPASS}" \
    -keystore "${PKI_HOME}/${MGMT_KEYSTORE}" \
    -storepass "${STOREPASS}" \
    -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_HOME}/${MGMT_CERT_FILE}"
    updateJBossOwnership

    echo
    echo "Imported certificate at: ${PKI_HOME}/${MGMT_CERT_FILE}"
    cat "${PKI_HOME}/${MGMT_CERT_FILE}"

fi

echo
echo "FINISHED"

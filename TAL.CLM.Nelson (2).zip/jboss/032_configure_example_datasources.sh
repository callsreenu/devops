#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Configure Example Datasources"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

echo 
echo "------------------------------------------------------------------------------"
echo "Add example XA and non-XA datasources to the exercise the JDBC driver."
echo "------------------------------------------------------------------------------"
echo 
SCRIPT=$(cat <<END_OF_SCRIPT

    if (outcome != success) of /subsystem=datasources/data-source=MSSQLXADS:read-resource
        xa-data-source add \
        --name=MSSQLXADS \
        --jndi-name=java:/MSSQLXADS \
        --driver-name=MSSQLDriver \
        --user-name=${DB_USER_NAME_SEC} \
        --password=${DB_USER_PASS_SEC} \
        --validate-on-match=false \
        --background-validation=false \
        --valid-connection-checker-class-name=org.jboss.jca.adapters.jdbc.extensions.mssql.MSSQLValidConnectionChecker \
        --exception-sorter-class-name=org.jboss.jca.adapters.jdbc.extensions.mssql.MSSQLExceptionSorter \
        --pool-use-strict-min=true \
        --statistics-enabled=true \
        --same-rm-override=false \
        --xa-datasource-properties={"ServerName"=>"${DB_SERVER}","DatabaseName"=>"${SEC_DB_NAME}","SelectMethod"=>"cursor","Encrypt"=>"true","TrustServerCertificate"=>"true"}
    end-if

    if (outcome != success) of /subsystem=datasources/data-source=MSSQLDS:read-resource
        data-source add \
        --name=MSSQLDS \
        --jndi-name=java:/MSSQLDS \
        --driver-name=MSSQLDriver \
        --user-name=${DB_USER_NAME_APP} \
        --password=${DB_USER_PASS_APP} \
        --connection-url="jdbc:sqlserver://${DB_SERVER}:${DB_SERVER_PORT};databaseName=${APP_DB_NAME};encrypt=true;trustServerCertificate=true;" \
        --validate-on-match=false \
        --background-validation=false \
        --exception-sorter-class-name=org.jboss.jca.adapters.jdbc.extensions.mssql.MSSQLExceptionSorter
    end-if

    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "FINEOS: 4.9.2.4 Testing Datasource connections"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    /subsystem=datasources/data-source=MSSQLDS:test-connection-in-pool
    /subsystem=datasources/data-source=MSSQLXADS:test-connection-in-pool
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "Query installed JDBC drivers and DataSources"
echo "------------------------------------------------------------------------------"
echo 
SCRIPT=$(cat <<END_OF_SCRIPT
    /subsystem=datasources:read-children-resources(child-type=jdbc-driver)
    /subsystem=datasources:read-resource
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "Cleanup after executing CLI script."
sudo rm -Rf ${JBOSS_HOME}/standalone/configuration/standalone_xml_history
sudo rm -Rf ${JBOSS_HOME}/standalone/log
sudo rm -Rf ${JBOSS_HOME}/standalone/data

echo
echo "FINISHED"

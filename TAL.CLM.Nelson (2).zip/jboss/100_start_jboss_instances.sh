#!/usr/bin/env bash
echo
echo "------------------------------------------------------------------------------"
echo "TASK: Start JBoss EAP services"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

# Ensure the console logs folder is present
if [ ! -d ${INSTANCES_HOME}/console-logs ]; then
  sudo mkdir -p ${INSTANCES_HOME}/console-logs;
  echo -e "Created folder '${INSTANCES_HOME}/console-logs'\n"
  updateJBossOwnership
fi

if [[ "${RUN_AS_SERVICE}" == 'true' ]] 
then
  sudo systemctl start ${TARGET_ENV}-${JBOSS_VERSION}-frontoffice.service
  sudo systemctl start ${TARGET_ENV}-${JBOSS_VERSION}-fineosservices.service
  sudo systemctl start ${TARGET_ENV}-${JBOSS_VERSION}-analytics.service
else
  startInstance frontoffice 100
  startInstance fineosservices 250
  startInstance analytics 300
fi

ls -l ${INSTANCES_HOME}/console-logs/

echo
echo "FINISHED"

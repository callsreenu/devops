#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Configure JDBC Drivers"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Remove unwanted, H2 JDBC driver and datasource"
# echo "------------------------------------------------------------------------------"
# echo 
# SCRIPT=$(cat <<END_OF_SCRIPT
#     if (outcome == success) of /subsystem=datasources/data-source=ExampleDS:read-resource
#         # Removing 'ExampleDS' datasource
#         /subsystem=datasources/data-source=ExampleDS:remove
#     else
#         # Datasource 'ExampleDS' not found
#     end-if

#     echo 
#     if (outcome == success) of /subsystem=datasources/jdbc-driver=h2:read-resource
#         # Removing H2 JDBC Driver
#         /subsystem=datasources/jdbc-driver=h2:remove
#     else
#         # H2 JDBC driver not found
#     end-if
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: MS SQL Server JDBC driver - Install, register and configure"
echo "- Adding SQL Server JDBC Driver as a core module"
echo "- Register the JDBC driver"
echo "------------------------------------------------------------------------------"
echo 
SCRIPT=$(cat <<END_OF_SCRIPT
    module add \
    --name=com.microsoft \
    --resources=${MSSQL_JDBC_DRIVER_JAR} \
    --dependencies=javax.api,javax.transaction.api,javax.xml.bind.api,javaee.api,sun.jdk,ibm.jdk

    # Register the JDBC driver
    if (outcome != success) of /subsystem=datasources/jdbc-driver=MSSQLDriver:read-resource
        /subsystem=datasources/jdbc-driver=MSSQLDriver:add(driver-name=MSSQLDriver,driver-module-name=com.microsoft,driver-xa-datasource-class-name=com.microsoft.sqlserver.jdbc.SQLServerXADataSource)
    end-if

END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "Query installed JDBC drivers and DataSources"
echo "------------------------------------------------------------------------------"
echo 
SCRIPT=$(cat <<END_OF_SCRIPT
    /subsystem=datasources:read-children-resources(child-type=jdbc-driver)
    /subsystem=datasources:read-resource
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "Cleanup after executing CLI script."
sudo rm -Rf ${JBOSS_HOME}/standalone/configuration/standalone_xml_history
sudo rm -Rf ${JBOSS_HOME}/standalone/log
sudo rm -Rf ${JBOSS_HOME}/standalone/data

echo
echo "FINISHED"

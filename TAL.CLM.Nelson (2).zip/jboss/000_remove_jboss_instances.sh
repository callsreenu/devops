#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Remove JBoss Instances"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

echo 
echo "------------------------------------------------------------------------------"
echo "KEY VARIABLES"
echo "------------------------------------------------------------------------------"
echo -e "JBOSS_BASE: ${JBOSS_BASE}"
echo -e "JBOSS_HOME: ${JBOSS_HOME}"
echo -e "JBOSS_VERSION: ${JBOSS_VERSION}"
echo -e "INSTANCES_HOME: ${INSTANCES_HOME}"
echo -e "FINEOS_BASE: ${FINEOS_BASE}"
echo -e "FINEOS_VERSION: ${FINEOS_VERSION}"
echo -e "INCLUDE_FRONTOFFICE: '${INCLUDE_FRONTOFFICE}'"
echo -e "INCLUDE_SERVICES: '${INCLUDE_SERVICES}'"
echo -e "INCLUDE_ANALYTICS: '${INCLUDE_ANALYTICS}'"

echo
echo "------------------------------------------------------------------------------"
echo "Confirm JBOSS_BASE variable is not empty.  Must have a value '${JBOSS_BASE}'"
echo "------------------------------------------------------------------------------"
[[ -z "${JBOSS_BASE}" ]] \
&& echo "ERROR: JBOSS_BASE is empty or undefuned.  Exiting..." \
&& exit 1;

# echo
# echo "------------------------------------------------------------------------------"
# echo -e "Remove secure profile archive if it already exists"
# echo "------------------------------------------------------------------------------"
# echo sudo rm -Rf "${JBOSS_HOME}/TAL-${JBOSS_VERSION}-secure-profile.zip"
# sudo rm -Rf "${JBOSS_HOME}/TAL-${JBOSS_VERSION}-secure-profile.zip"

echo
echo "------------------------------------------------------------------------------"
echo -e "Remove FRONTOFFICE folder '${INSTANCES_HOME}/frontoffice'"
echo "------------------------------------------------------------------------------"
if [[ "${INCLUDE_FRONTOFFICE}" == "True" ]] 
then
    INSTANCE_NAME=frontoffice
    PORT_OFFSET=$PORT_OFFSET_FRONTOFFICE

    echo "Removing service for instance ${INSTANCE_NAME}"
    echo "Attempting to kill process "
    stopInstance "${INSTANCE_NAME}" "${PORT_OFFSET}"

    sudo systemctl stop ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}
    sudo rm -f /etc/default/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}*
    sudo rm -f /etc/systemd/system/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}*
    [[ -d "${JBOSS_BASE}/instances/${JBOSS_VERSION}/${INSTANCE_NAME}" ]] \
    && sudo rm -Rf "${JBOSS_BASE}/instances/${JBOSS_VERSION}/${INSTANCE_NAME}" \
    closeJBossPorts ${INSTANCE_NAME} $PORT_OFFSET
fi

echo
echo "------------------------------------------------------------------------------"
echo -e "Remove SERVICES folder '${INSTANCES_HOME}/services'"
echo "------------------------------------------------------------------------------"
if [[ "${INCLUDE_SERVICES}" == "True" ]] 
then
    INSTANCE_NAME=services
    PORT_OFFSET=$PORT_OFFSET_SERVICES

    echo "Removing service for instance ${INSTANCE_NAME}"
    echo "Attempting to kill process "
    stopInstance "${INSTANCE_NAME}" "${PORT_OFFSET}"

    sudo systemctl stop ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}
    sudo rm -f /etc/default/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}*
    sudo rm -f /etc/systemd/system/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}*
    [[ -d "${JBOSS_BASE}/instances/${JBOSS_VERSION}/${INSTANCE_NAME}" ]] \
    && sudo rm -Rf "${JBOSS_BASE}/instances/${JBOSS_VERSION}/${INSTANCE_NAME}" \
    closeJBossPorts ${INSTANCE_NAME} $PORT_OFFSET
fi

echo
echo "------------------------------------------------------------------------------"
echo -e "Remove ANALYTICS folder '${INSTANCES_HOME}/analytics'"
echo "------------------------------------------------------------------------------"
if [[ "${INCLUDE_ANALYTICS}" == "True" ]] 
then
    INSTANCE_NAME=analytics
    PORT_OFFSET=$PORT_OFFSET_ANALYTICS

    echo "Removing service for instance ${INSTANCE_NAME}"
    echo "Attempting to kill process "
    stopInstance "${INSTANCE_NAME}" "${PORT_OFFSET}"

    sudo systemctl stop ${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}
    sudo rm -f /etc/default/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}*
    sudo rm -f /etc/systemd/system/${TARGET_ENV}-${JBOSS_VERSION}-${INSTANCE_NAME}*
    [[ -d "${JBOSS_BASE}/instances/${JBOSS_VERSION}/${INSTANCE_NAME}" ]] \
    && sudo rm -Rf "${JBOSS_BASE}/instances/${JBOSS_VERSION}/${INSTANCE_NAME}" \
    closeJBossPorts ${INSTANCE_NAME} $PORT_OFFSET
fi

echo 
echo "------------------------------------------------------------------------------"
echo "Remove service artifacts"
echo "------------------------------------------------------------------------------"
# sudo rm -Rf /etc/systemd/system/jboss-eap-*
# sudo rm -Rf /etc/init.d/jboss-eap-*
# sudo rm -Rf /etc/default/jboss-eap-*

updateJBossOwnership

echo
echo "------------------------------------------------------------------------------"
echo "Close JBoss Ports"
echo "------------------------------------------------------------------------------"


echo 
sudo firewall-cmd --list-all

echo 
echo "FINISHED"

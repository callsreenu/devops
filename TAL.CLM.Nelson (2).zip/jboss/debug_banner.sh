#!/usr/bin/env bash
echo 
echo "-----------------------------------------------------------------------------*"
echo "* DEBUG                                       `date` *"
echo "-----------------------------------------------------------------------------*"
echo "*** System Info ***"
echo "ALL..................: "`uname -a`
echo "hostname.............: "`uname -n`
echo "kernal name..........: "`uname -s`
echo "kernel release date..: "`uname -r`
echo "kernel version.......: "`uname -v`
echo "machine hardware.....: "`uname -m`
echo "processor type.......: "`uname -p`
echo "hardware platform....: "`uname -i`
echo "operating system.....: "`uname -o`
echo 
echo "*** Agent Info ***"
echo "AGENT_WORKFOLDER.....: ${AGENT_WORKFOLDER}"
echo "AGENT_BUILDDIRECTORY.: ${AGENT_BUILDDIRECTORY}"
echo "SYSTEM_HOSTTYPE......: ${SYSTEM_HOSTTYPE}"
echo ""
echo "*** User Info ***"
echo "Current user.........: "`whoami`
echo "Current folder.......: "`pwd`
echo "-----------------------------------------------------------------------------*"
echo "* END OF DEBUG                                                               *"
echo "-----------------------------------------------------------------------------*"
echo 

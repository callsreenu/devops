#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Remove JBoss Version"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

echo 
echo "------------------------------------------------------------------------------"
echo "KEY VARIABLES"
echo "------------------------------------------------------------------------------"
echo -e "JBOSS_BASE: ${JBOSS_BASE}"
echo -e "JBOSS_HOME: ${JBOSS_HOME}"
echo -e "JBOSS_VERSION: ${JBOSS_VERSION}"
echo -e "INSTANCES_HOME: ${INSTANCES_HOME}"
echo -e "FINEOS_BASE: ${FINEOS_BASE}"
echo -e "FINEOS_VERSION: ${FINEOS_VERSION}"

echo 
echo "------------------------------------------------------------------------------"
echo "CRUDE - once running as a service, use systemctl commands"
echo "------------------------------------------------------------------------------"
echo "Attempting to kill FRONTOFFICE process " && stopInstance "frontoffice" "${PORT_OFFSET_FRONTOFFICE}"
echo "Attempting to kill SERVICES process " && stopInstance "services" "${PORT_OFFSET_SERVICES}"
echo "Attempting to kill ANALYTICS process " && stopInstance "analytics" "${PORT_OFFSET_ANALYTICS}"

echo
echo "------------------------------------------------------------------------------"
echo "Confirm JBOSS_BASE variable is not empty.  Must have a value '${JBOSS_BASE}'"
echo "------------------------------------------------------------------------------"
[[ -z "${JBOSS_BASE}" ]] \
&& echo "ERROR: JBOSS_BASE is empty or undefuned.  Exiting..." \
&& exit 1;

echo
echo "------------------------------------------------------------------------------"
echo -e "Remove INSTANCES_HOME folder '${INSTANCES_HOME}'"
echo "------------------------------------------------------------------------------"
[[ "${INCLUDE_FRONTOFFICE}" == "True" ]] \
&& [[ -d "${JBOSS_BASE}/instances/${JBOSS_VERSION}" ]] \
&& sudo rm -Rf "${JBOSS_BASE}/instances/${JBOSS_VERSION}"

echo
echo "------------------------------------------------------------------------------"
echo -e "Remove JBOSS_HOME folder '${JBOSS_BASE}/${JBOSS_VERSION}'"
echo "------------------------------------------------------------------------------"
[[ -d "${JBOSS_BASE}/${JBOSS_VERSION}" ]] \
&& sudo rm -Rf "${JBOSS_BASE}/${JBOSS_VERSION}"

echo 
echo "------------------------------------------------------------------------------"
echo "Remove service artifacts"
echo "------------------------------------------------------------------------------"
sudo rm -Rf /etc/systemd/system/jboss-eap-*
sudo rm -Rf /etc/init.d/jboss-eap-*
sudo rm -Rf /etc/default/jboss-eap-*

echo
echo "------------------------------------------------------------------------------"
echo "Pass ownership of '/jboss' folder BACK to '${JBOSS_USER}'."
echo "------------------------------------------------------------------------------"
updateJBossOwnership

# echo
# echo "------------------------------------------------------------------------------"
# echo -e "Remove JBoss non-login user '${JBOSS_USER}' if no other versions present."
# echo "------------------------------------------------------------------------------"
# sudo gpasswd -d $USER ${JBOSS_USER}
# sudo userdel -f ${JBOSS_USER} 

echo
echo "------------------------------------------------------------------------------"
echo "Close JBoss Ports"
echo "------------------------------------------------------------------------------"
closeJBossPorts frontoffice $PORT_OFFSET_FRONTOFFICE
closeJBossPorts fineosservices $PORT_OFFSET_SERVICES
closeJBossPorts analytics $PORT_OFFSET_ANALYTICS
echo 
sudo firewall-cmd --list-all

echo 
echo "FINISHED"

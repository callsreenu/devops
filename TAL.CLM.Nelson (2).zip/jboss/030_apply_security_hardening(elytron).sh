#!/usr/bin/env bash
echo 
echo "------------------------------------------------------------------------------"
echo "TASK: Apply Security Hardening (Elytron)"
echo "------------------------------------------------------------------------------"
source jboss/functions.sh

JBOSS_USER=${JBOSS_USER:-jboss}
echo 
echo "------------------------------------------------------------------------------"
echo "Backup the 'standalone' folder"
echo "------------------------------------------------------------------------------"
sudo su -c "cp -R ${JBOSS_HOME}/standalone ${JBOSS_HOME}/standalone_patched_unhardened" ${JBOSS_USER:-jboss}

echo "------------------------------------------------------------------------------"
echo "Add a bootstrap Management User."
echo "------------------------------------------------------------------------------"
sudo su -c "touch ${JBOSS_HOME}/standalone/configuration/https-mgmt-users.properties" ${JBOSS_USER:-jboss}

echo "ADD Management User"
sudo su -c "${JBOSS_HOME}/bin/add-user.sh -up ${JBOSS_HOME}/standalone/configuration/https-mgmt-users.properties -r ManagementRealmHTTPS -b --user ${JBOSS_ADMIN_USER} --password ${JBOSS_ADMIN_PASSWORD} --role admin" ${JBOSS_USER:-jboss}

echo 
echo "=============================================================================="
echo "TASK : Replace the legacy security sub-system"
echo "=============================================================================="

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Enable Elytron Security Across the Server"
echo "------------------------------------------------------------------------------"
sudo su -c "${JBOSS_HOME}/bin/jboss-cli.sh --no-color-output --file=${JBOSS_HOME}/docs/examples/enable-elytron.cli" ${JBOSS_USER-jboss} 
#updateJBossOwnership
    
echo 
echo "=============================================================================="
echo "TASK : General security hardening"
echo "=============================================================================="
echo 

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Disable Management Console"
# echo "(A safety measure that can be enabled when EAP is secured)"
# echo "------------------------------------------------------------------------------"
# SCRIPT=$(cat <<END_OF_SCRIPT
#     /core-service=management/management-interface=http-interface/:write-attribute(name=console-enabled,value=false)
#     reload --admin-only=true
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Disable remote JMX"
# echo "(A safety measure that can be enabled when EAP is secured)"
# echo "------------------------------------------------------------------------------"
# SCRIPT=$(cat <<END_OF_SCRIPT
#     /subsystem=jmx/remoting-connector=jmx/:remove
#     reload --admin-only=true
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Elytron: Disable silent authentication with the JBoss CLI console"
# echo "------------------------------------------------------------------------------"
# SCRIPT=$(cat <<END_OF_SCRIPT
#     if (result.mechanism-name == JBOSS-LOCAL-USER) of /subsystem=elytron/sasl-authentication-factory=management-sasl-authentication:list-get(name=mechanism-configurations,index=0)
#         /subsystem=elytron/sasl-authentication-factory=management-sasl-authentication:list-remove(name=mechanism-configurations,index=0)
#     else
#         echo "Silent local authentication mechanism not detected at index 0."
#     end-if
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Elytron: Enable silent authentication with the JBoss CLI console"
# echo "------------------------------------------------------------------------------"
# SCRIPT=$(cat <<END_OF_SCRIPT
#     /subsystem=elytron/sasl-authentication-factory=management-sasl-authentication:list-add(name=mechanism-configurations,value={mechanism-name=JBOSS-LOCAL-USER})
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Disable the deployment scanner (Can be enabled in DEV)"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    /subsystem=deployment-scanner:remove()
    /extension=org.jboss.as.deployment-scanner:remove()
    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "=============================================================================="
echo "TASK : Create PKI assets: keystore(s), CSRs, Certs"
echo "=============================================================================="

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Disable the self-signed certificate creation"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
if (outcome == success ) of /core-service=management/security-realm=ApplicationRealm/server-identity=ssl:read-attribute(name=generate-self-signed-certificate-host)
    /core-service=management/security-realm=ApplicationRealm/server-identity=ssl:undefine-attribute(name=generate-self-signed-certificate-host)
    reload --admin-only=true
end-if
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo
echo "------------------------------------------------------------------------------"
echo "Create PKI asset folder"
echo "------------------------------------------------------------------------------"
mkdir -p "${PKI_ASSETS_FOLDER}"

echo
echo "------------------------------------------------------------------------------"
echo "Generate a credentials store"
echo "------------------------------------------------------------------------------"
# sudo keytool -genkeypair -v \
# -noprompt \
# -alias "${ALIAS:-jboss}-credential-store" \
# -storetype "${STORETYPE}" \
# -keypass "${KEYPASS}" \
# -keystore "${JBOSS_HOME}/standalone/configuration/${CREDSTORE}" \
# -storepass "${CREDSTOREPASS}" \
# -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
# -keyalg RSA -keysize 2048 \
# -validity 730 
# updateJBossOwnership

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Configure credential store and insert known credentials"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    echo "Creating credential store"
     /subsystem=elytron/credential-store=credentialStore:add(relative-to=jboss.server.config.dir, location=${CREDSTORE}, create=true,credential-reference={clear-text=${CREDSTOREPASS}})

    echo "Storing keystore password in credential store"
    /subsystem=elytron/credential-store=credentialStore:add-alias(alias=keystorepass,secret-value=${KEYSTOREPASS})

    echo "Storing key password in credential store"
    /subsystem=elytron/credential-store=credentialStore:add-alias(alias=keypass,secret-value=${KEYPASS})

    echo "List of entries in the credential store"
    /subsystem=elytron/credential-store=credentialStore:read-aliases()

END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo
echo "------------------------------------------------------------------------------"
echo "Generate a keystore for Applications"
echo "------------------------------------------------------------------------------"
sudo keytool -genkeypair -v \
-noprompt \
-alias "${ALIAS:-jboss}-keystore" \
-storetype jks \
-keypass "${KEYPASS}" \
-keystore "${JBOSS_HOME}/standalone/configuration/application.keystore" \
-storepass "${STOREPASS}" \
-dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
-keyalg RSA -keysize 2048 \
-validity 730 
updateJBossOwnership

echo
echo "------------------------------------------------------------------------------"
echo "Generate a keystore for Management Interfaces"
echo "------------------------------------------------------------------------------"
sudo keytool -genkeypair -v \
-noprompt \
-alias "${ALIAS:-jboss}-mgmt-keystore" \
-storetype "${STORETYPE}" \
-keypass "${KEYPASS}" \
-keystore "${JBOSS_HOME}/standalone/configuration/${KEYSTORE}" \
-storepass "${KEYSTOREPASS}" \
-dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
-keyalg RSA -keysize 2048 \
-validity 730 
updateJBossOwnership


echo "Checking for existence of signed certificate to import"
if [[ -f "${PKI_ASSETS_FOLDER}/${CERT_FILE}" ]] ; then
    echo -e "Found certificate at: '${PKI_ASSETS_FOLDER}/${CERT_FILE}'"

    echo -e "Importing certificate into ${KEYSTORE}"
    sudo keytool -import -v \
    -noprompt \
    -alias "${ALIAS}" \
    -trustcacerts \
    -keystore "${JBOSS_HOME}/standalone/configuration/${KEYSTORE}" \
    -storepass "${KEYSTOREPASS}" \
    -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_ASSETS_FOLDER}/${CERT_FILE}" 
    echo -e "Imported certificate."

    echo -e "Importing certificate into application.keystore"
    sudo keytool -import -v \
    -noprompt \
    -alias "${ALIAS}" \
    -trustcacerts \
    -keystore "${JBOSS_HOME}/standalone/configuration/application.keystore" \
    -storepass "${KEYSTOREPASS}" \
    -dname "CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}" \
    -file "${PKI_ASSETS_FOLDER}/${CERT_FILE}" 
    echo -e "Imported certificate."

elif [[ ! -f "${PKI_ASSETS_FOLDER}/${CSR_FILE}" ]] ; then
    echo -e "Certificate not found."
    echo -e "Generating certificate signing request (CSR) at: ${CSR_FILE}"
    sudo keytool -certreq -v \
    -noprompt \
    -alias "${ALIAS}" \
    -storetype "${STORETYPE}" \
    -keypass "${KEYPASS}" \
    -keystore "${JBOSS_HOME}/standalone/configuration/${KEYSTORE}" \
    -storepass "${KEYSTOREPASS}" \
    -dname CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C} \
    -file "${PKI_ASSETS_FOLDER}/${CSR_FILE}"
fi
updateJBossOwnership

echo 
echo "=============================================================================="
echo "TASK : Configure One-way SSL/TLS"
echo "=============================================================================="

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Configure an existing key-store"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT

#    /subsystem=elytron/key-store=httpsKS:add(path=${KEYSTORE},relative-to=jboss.server.config.dir, credential-reference={clear-text=${KEYSTOREPASS}},type=${STORETYPE})
    /subsystem=elytron/key-store=httpsKS:add(path=httpsKS.jks,relative-to=jboss.server.config.dir, credential-reference={clear-text=keystorepassword1},type=JKS)
    # Use a credential store.
    /subsystem=elytron/key-store=httpsKS:write-attribute(name=credential-reference,value={store=credentialStore,alias=keystorepass})

#   /subsystem=elytron/key-manager=httpsKM:add(key-store=httpsKS,algorithm="SunX509",credential-reference={clear-text=${KEYSTOREPASS}})
#    /subsystem=elytron/key-manager=httpsKM:add(key-store=httpsKS,credential-reference={store=credentialStore,alias=keystorepass})
    /subsystem=elytron/key-manager=httpsKM:add(key-store=httpsKS,credential-reference={store=credentialStore,alias=keystorepass})
    /subsystem=elytron/server-ssl-context=httpsSSC:add(key-manager=httpsKM,protocols=["TLSv1.2"])

    reload --admin-only=true

END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Create and configure a new key-store"
# echo "------------------------------------------------------------------------------"
# echo 
# SCRIPT=$(cat <<END_OF_SCRIPT
#    /subsystem=elytron/key-store=httpsKS:generate-key-pair(alias=${ALIAS:-jboss}-keystore,algorithm=RSA,key-size=2048,validity=730,credential-reference={clear-text=${KEYSTOREPASS}},distinguished-name="CN=${DNAME_CN},OU=${DNAME_OU},O=${DNAME_O},L=${DNAME_L},ST=${DNAME_ST},C=${DNAME_C}")
#    /subsystem=elytron/key-store=httpsKS:store()
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

# echo 
# echo "------------------------------------------------------------------------------"
# echo "CLI: Create a key-manager and a ssl-server-context that references it"
# echo "------------------------------------------------------------------------------"
# SCRIPT=$(cat <<END_OF_SCRIPT
#     /subsystem=elytron/key-manager=httpsKM:add(key-store=httpsKS,credential-reference={store=credentialStore,alias=keystorepass})
# #   /subsystem=elytron/key-manager=httpsKM:add(key-store=httpsKS,algorithm="SunX509",credential-reference={clear-text=${KEYSTOREPASS}})
#     /subsystem=elytron/server-ssl-context=httpsSSC:add(key-manager=httpsKM,protocols=["TLSv1.2"])
# END_OF_SCRIPT
# ) && executeAdminCLI "${SCRIPT}"

echo 
echo "=============================================================================="
echo "TASK : Enable One-way SSL/TLS for Management Interfaces"
echo "=============================================================================="

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Enable HTTPS on the management interface."
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    /core-service=management/management-interface=http-interface:write-attribute(name=ssl-context, value=httpsSSC)
    /core-service=management/management-interface=http-interface:write-attribute(name=secure-socket-binding, value=management-https)
    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"

echo 
echo "=============================================================================="
echo "TASK : Enable One-way SSL/TLS for Applications"
echo "=============================================================================="

echo 
echo "------------------------------------------------------------------------------"
echo "CLI: Remove the reference to the legacy security realm, and update "
echo "     the https-listener to use the ssl-context from Elytron"
echo "------------------------------------------------------------------------------"
SCRIPT=$(cat <<END_OF_SCRIPT
    batch
        /subsystem=undertow/server=default-server/https-listener=https:undefine-attribute(name=security-realm)
        /subsystem=undertow/server=default-server/https-listener=https:write-attribute(name=ssl-context, value=httpsSSC)
    run-batch
    reload --admin-only=true
END_OF_SCRIPT
) && executeAdminCLI "${SCRIPT}"


echo 
echo "------------------------------------------------------------------------------"
echo "Cleanup after executing CLI script."
echo "------------------------------------------------------------------------------"
sudo rm -Rf ${JBOSS_HOME}/standalone/configuration/standalone_xml_history
sudo rm -Rf ${JBOSS_HOME}/standalone/log
sudo rm -Rf ${JBOSS_HOME}/standalone/data

updateJBossOwnership

echo
echo "FINISHED"

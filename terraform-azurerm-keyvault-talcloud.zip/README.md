# Introduction
Module written to match TAL's compliance and governance standards.
<br>This module is intended to be used in TALs corporate Cloud environment.
<br> This module allows for the creation of an <b> Azure Key Vault </b> in AustraliaEast and AustraliaSoutheast regions only with firewall enabled.
<br> By default the keyvault will be attached to AzureFirewall subnet, ASEv2 Subnet and private-aks subnet
<br>There are mandatory and default inputs defined for this module.
###  Note:
 Currently you cannot add a secret to the keyvault via terraform, cloud team are working on this currently
# Getting Started
Steps below are easy to follow and replicate in your Terraform code.
<br>Module intended to run with Terraform 0.13 and above


# Build and Test
<b>Sample Code to test the module</b>

# Example
<pre>
<code>

module "azkv" {
  source                          = "app.terraform.io/TAL/keyvault-talcloud/azurerm"
  version                         = "0.0.1"
  appprefixname                   = "tal"
  region                          = "mel"
  environment                     = "dev1"
  location                        = "australiasoutheast"
  rgname                          = "rg-name"
  kv_soft_delete_retention_days   = 14
  kv_sku                          = "premium"
  tags                            = local.common_tags
  external_ipaddresses            = []    ### ADDING WHITE LISTED IP ADDRESS TO KEYVAULT
  virtual_subnet_ids              = [] ## Pass in addtional subnets (You can exclude this if you are not passing in any values)
}


</code>
</pre>

<br> Properties not exposed by Output variables have to be queried using the <b>data</b> source
# Policies
##### Name: Key vaults should have purge protection enabled<br>  Description: Malicious deletion of a key vault can lead to permanent data loss. A malicious insider in your organization can potentially delete and purge key vaults. Purge protection protects you from insider attacks by enforcing a mandatory retention period for soft deleted key vaults. No one inside your organization or Microsoft will be able to purge your key vaults during the soft delete retention period.
##### Name: Key vaults should have soft delete enabled<br>  Description: Deleting a key vault without soft delete enabled permanently deletes all secrets, keys, and certificates stored in the key vault. Accidental deletion of a key vault can lead to permanent data loss. Soft delete allows you to recover an accidentally deleted key vault for a configurable retention period.
##### Name: Deploy - Configure diagnostic settings for Azure Key Vault to Log Analytics workspace<br>  Description: Deploys the diagnostic settings for Azure Key Vault to stream resource logs to a Log Analytics workspace when any Key Vault which is missing this diagnostic settings is created or updated.
##### Name: Resource logs in Azure Key Vault Managed HSM should be enabled<br>  Description: To recreate activity trails for investigation purposes when a security incident occurs or when your network is compromised, you may want to audit by enabling resource logs on Managed HSMs. Please follow the instructions here: https://docs.microsoft.com/azure/key-vault/managed-hsm/logging.
##### Name: Deploy - Configure diagnostic settings to an Event Hub to be enabled on Azure Key Vault Managed HSM<br>  Description: Deploys the diagnostic settings for Azure Key Vault Managed HSM to stream to a regional Event Hub when any Azure Key Vault Managed HSM which is missing this diagnostic settings is created or updated.
##### Name: Azure Key Vault Managed HSM should have purge protection enabled<br>  Description: Malicious deletion of an Azure Key Vault Managed HSM can lead to permanent data loss. A malicious insider in your organization can potentially delete and purge Azure Key Vault Managed HSM. Purge protection protects you from insider attacks by enforcing a mandatory retention period for soft deleted Azure Key Vault Managed HSM. No one inside your organization or Microsoft will be able to purge your Azure Key Vault Managed HSM during the soft delete retention period.
##### Name: Resource logs in Key Vault should be enabled<br>  Description: Audit enabling of resource logs. This enables you to recreate activity trails to use for investigation purposes when a security incident occurs or when your network is compromised
##### Name: Deploy Diagnostic Settings for Key Vault to Event Hub<br>  Description: Deploys the diagnostic settings for Key Vault to stream to a regional Event Hub when any Key Vault which is missing this diagnostic settings is created or updated.
##### Name: Certificates should use allowed key types<br>  Description: Manage your organizational compliance requirements by restricting the key types allowed for certificates.
##### Name: Certificates should have the specified lifetime action triggers<br>  Description: Manage your organizational compliance requirements by specifying whether a certificate lifetime action is triggered at a specific percentage of its lifetime or at a certain number of days prior to its expiration.
##### Name: Key Vault keys should have an expiration date<br>  Description: Cryptographic keys should have a defined expiration date and not be permanent. Keys that are valid forever provide a potential attacker with more time to compromise the key. It is a recommended security practice to set expiration dates on cryptographic keys.
##### Name: Secrets should have the specified maximum validity period<br>  Description: Manage your organizational compliance requirements by specifying the maximum amount of time in days that a secret can be valid within your key vault.
##### Name: Keys should have the specified maximum validity period<br>  Description: Manage your organizational compliance requirements by specifying the maximum amount of time in days that a key can be valid within your key vault.
##### Name: Keys should be backed by a hardware security module (HSM)<br>  Description: An HSM is a hardware security module that stores keys. An HSM provides a physical layer of protection for cryptographic keys. The cryptographic key cannot leave a physical HSM which provides a greater level of security than a software key.
##### Name: Keys should have more than the specified number of days before expiration<br>  Description: If a key is too close to expiration, an organizational delay to rotate the key may result in an outage. Keys should be rotated at a specified number of days prior to expiration to provide sufficient time to react to a failure.
##### Name: Secrets should have content type set<br>  Description: A content type tag helps identify whether a secret is a password, connection string, etc. Different secrets have different rotation requirements. Content type tag should be set on secrets.
##### Name: Keys should be the specified cryptographic type RSA or EC<br>  Description: Some applications require the use of keys backed by a specific cryptographic type. Enforce a particular cryptographic key type, RSA or EC, in your environment.
##### Name: Keys using RSA cryptography should have a specified minimum key size<br>  Description: Set the minimum allowed key size for use with your key vaults. Use of RSA keys with small key sizes is not a secure practice and doesn't meet many industry certification requirements.
##### Name: Certificates should be issued by the specified integrated certificate authority<br>  Description: Manage your organizational compliance requirements by specifying the Azure integrated certificate authorities that can issue certificates in your key vault such as Digicert or GlobalSign.
##### Name: Key Vault secrets should have an expiration date<br>  Description: Secrets should have a defined expiration date and not be permanent. Secrets that are valid forever provide a potential attacker with more time to compromise them. It is a recommended security practice to set expiration dates on secrets.
##### Name: Certificates should be issued by the specified non-integrated certificate authority<br>  Description: Manage your organizational compliance requirements by specifying the custom or internal certificate authorities that can issue certificates in your key vault.
##### Name: Secrets should have more than the specified number of days before expiration<br>  Description: If a secret is too close to expiration, an organizational delay to rotate the secret may result in an outage. Secrets should be rotated at a specified number of days prior to expiration to provide sufficient time to react to a failure.
##### Name: Certificates using elliptic curve cryptography should have allowed curve names<br>  Description: Manage the allowed elliptic curve names for ECC Certificates stored in key vault. More information can be found at https://aka.ms/akvpolicy.
##### Name: Keys should not be active for longer than the specified number of days<br>  Description: Specify the number of days that a key should be active. Keys that are used for an extended period of time increase the probability that an attacker could compromise the key. As a good security practice, make sure that your keys have not been active longer than two years.
##### Name: Certificates using RSA cryptography should have the specified minimum key size<br>  Description: Manage your organizational compliance requirements by specifying a minimum key size for RSA certificates stored in your key vault.
##### Name: Secrets should not be active for longer than the specified number of days<br>  Description: If your secrets were created with an activation date set in the future, you must ensure that your secrets have not been active for longer than the specified duration.
##### Name: Keys using elliptic curve cryptography should have the specified curve names<br>  Description: Keys backed by elliptic curve cryptography can have different curve names. Some applications are only compatible with specific elliptic curve keys. Enforce the types of elliptic curve keys that are allowed to be created in your environment.
##### Name: TAL Custom - Deny Keyvault without TAL approved IP addresses<br>  Description: Policy to stop assignment of non-approved ip addresses
##### Name: TAL Custom - Deny Keyvaults without Firewall and Virtual Networks<br>  Description: 
##### Name: TAL-Custom-TF-CIS-8.4-Key vaults should have purge protection enabled<br>  Description: Malicious deletion of a key vault can lead to permanent data loss. A malicious insider in your organization can potentially delete and purge key vaults. Purge protection protects you from insider attacks by enforcing a mandatory retention period for soft deleted key vaults. No one inside your organization or Microsoft will be able to purge your key vaults during the soft delete retention period.


# Introduction 
`./terraform` folder has IaC
Put your source code in the `./code` or other folders please.

# Getting Started
Fork the repo to get started
Update the terraform workspace name in the `providers.tf` file

# Build and Test

# Contribute
Open source within TAL
